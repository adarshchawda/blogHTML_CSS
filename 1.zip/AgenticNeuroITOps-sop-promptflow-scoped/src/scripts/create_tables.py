"""Create or verify database tables for the NeuroITOps application.

This script imports the SQLAlchemy `Base` and `engine` from
`src.sop_models` and calls `Base.metadata.create_all(engine)` to
create any missing tables. It also performs a simple connectivity
check (SELECT 1) using a session.

Usage (PowerShell):
  python .\src\scripts\create_tables.py
"""

from sqlalchemy import text

from src import sop_models


def main():
    Base = sop_models.Base
    engine = sop_models.engine
    SessionLocal = sop_models.SessionLocal

    # Print a short confirmation of the DB target (do not print password)
    try:
        print("DB target:", sop_models.SQLALCHEMY_DATABASE_URL.split('@')[-1])
    except Exception:
        print("DB target: (could not parse URL)")

    try:
        print("Creating/verifying tables...")
        Base.metadata.create_all(engine)

        # Quick connectivity check
        session = SessionLocal()
        try:
            session.execute(text("SELECT 1"))
            print("Database connectivity: OK")
        finally:
            session.close()

        print("Tables created / verified successfully.")
    except Exception as e:
        print("Error while creating tables or checking connectivity:")
        print(str(e))
        raise


if __name__ == '__main__':
    main()
