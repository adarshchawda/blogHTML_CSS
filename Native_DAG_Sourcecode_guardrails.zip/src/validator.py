import os
import json
import logging
import asyncio
import concurrent.futures
from typing import Dict, Optional
from dotenv import load_dotenv
import openai

logger = logging.getLogger(__name__)


class SOPValidator:
    def __init__(self, config_dir: str = None):
        load_dotenv()
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        self.llm_config = None
        self._configure_llm()

    def _configure_llm(self):
        """Configure LLM from environment variables."""
        try:
            from .load_env import load_env_from_keyvault
        except ImportError:
            from load_env import load_env_from_keyvault

        load_env_from_keyvault()

        llm_provider = os.getenv("LLM_PROVIDER", "azure").lower()

        if llm_provider in ["azure", "azure_openai"]:
            api_key   = os.getenv("AZURE_OPENAI_API_KEY")
            endpoint  = os.getenv("AZURE_OPENAI_ENDPOINT")
            deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
            api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01")

            if not all([api_key, endpoint, deployment]):
                raise ValueError("Missing required Azure OpenAI environment variables")

            self.llm_config = {
                "provider":    "azure",
                "model":       deployment,
                "api_key":     api_key,
                "endpoint":    endpoint,
                "api_version": api_version,
                "temperature": float(os.getenv("TEMPERATURE", "0.7")),
                "timeout":     int(os.getenv("TIMEOUT", "60")),
            }

        elif llm_provider == "openai":
            api_key = os.getenv("OPENAI_API_KEY")
            model   = os.getenv("OPENAI_MODEL", "gpt-4")

            if not api_key:
                raise ValueError("Missing OPENAI_API_KEY environment variable")

            self.llm_config = {
                "provider":    "openai",
                "model":       model,
                "api_key":     api_key,
                "temperature": float(os.getenv("TEMPERATURE", "0.7")),
                "timeout":     int(os.getenv("TIMEOUT", "60")),
            }

        else:
            raise ValueError(f"Unsupported LLM provider: {llm_provider}")

        self.system_message = (
            "You are a SOP (Standard Operating Procedure) Validator.\n"
            "Your task is to evaluate SOP documents based on predefined criteria.\n\n"
            "Validation Criteria:\n"
            "1. Clarity and Understandability\n"
            "2. Completeness and Coverage\n"
            "3. Accuracy and Correctness\n"
            "4. Structure and Organization\n"
            "5. Compliance with Standards\n"
            "6. Practicality and Feasibility\n"
            "7. Risk Management\n"
            "8. Documentation Quality\n"
            "9. Version\n"
            "10. Review and Approval Process\n\n"
            "For each SOP, provide:\n"
            "- Overall rating (1-10)\n"
            "- Detailed score for each criterion (1-10)\n"
            "- Specific feedback for improvement\n\n"
            "Please format your response in JSON format with the following structure:\n"
            "{\n  \"overall_rating\": <int>,\n  \"criteria_scores\": {\n    \"Clarity\": <int>,\n    \"Completeness\": <int>,\n    \"Accuracy\": <int>,\n    \"Structure\": <int>,\n    \"Compliance\": <int>,\n    \"Practicality\": <int>,\n    \"Risk\": <int>,\n    \"Documentation\": <int>,\n    \"Version\": <int>,\n    \"Review\": <int>\n  },\n  \"feedback\": \"<detailed feedback>\"\n}"
        )

        self.logger.info(
            "SOPValidator configured — provider=%s model=%s",
            llm_provider, self.llm_config.get("model")
        )

    def _build_openai_client(self):
        """Build the correct openai client (v1.x API)."""
        if self.llm_config["provider"] == "azure":
            return openai.AzureOpenAI(
                api_key=self.llm_config["api_key"],
                azure_endpoint=self.llm_config["endpoint"],
                api_version=self.llm_config["api_version"],
            )
        return openai.OpenAI(api_key=self.llm_config["api_key"])

    def _extract_json(self, text: str) -> Optional[dict]:
        """Extract JSON from LLM response, stripping markdown fences if present."""
        try:
            s = text.strip()
            # Strip ```json ... ``` fences
            if s.startswith("```"):
                lines = s.split("\n")
                lines = lines[1:] if lines[0].startswith("```") else lines
                lines = lines[:-1] if lines and lines[-1].strip() == "```" else lines
                s = "\n".join(lines).strip()

            try:
                parsed = json.loads(s)
            except Exception:
                start, end = s.find("{"), s.rfind("}")
                if start != -1 and end > start:
                    parsed = json.loads(s[start:end + 1])
                else:
                    return None

            # Safety clamp — fix overall_rating if LLM returns sum instead of average
            if parsed and "overall_rating" in parsed:
                raw_rating = parsed["overall_rating"]
                if isinstance(raw_rating, (int, float)) and raw_rating > 10:
                    scores = parsed.get("criteria_scores", {})
                    if scores:
                        avg = round(sum(scores.values()) / len(scores))
                        parsed["overall_rating"] = max(1, min(10, avg))
                        self.logger.warning(
                            "overall_rating was %s (out of range) — corrected to average %s",
                            raw_rating, parsed["overall_rating"]
                        )
            return parsed
        except Exception:
            pass
        return None

    async def _validate_sop_async(self, sop_content: str) -> Dict:
        """Core async validation — direct Azure OpenAI / OpenAI call."""
        try:
            validation_request = f"""Please evaluate the following SOP document:
                
            {sop_content}
                
            Please provide your evaluation in the specified JSON format.
            """

            messages = [
                {"role": "system", "content": self.system_message},
                {"role": "user",   "content": validation_request},
            ]

            def _sync_call():
                client = self._build_openai_client()
                resp = client.chat.completions.create(
                    model=self.llm_config["model"],
                    messages=messages,
                    temperature=self.llm_config["temperature"],
                )
                return resp.choices[0].message.content

            loop = asyncio.get_running_loop()
            text = await loop.run_in_executor(None, _sync_call)

            parsed = self._extract_json(text or "")
            if parsed and "overall_rating" in parsed:
                return parsed

            return {"error": "No valid JSON from LLM", "raw_response": text}

        except Exception as e:
            self.logger.error("Validation error: %s", str(e), exc_info=True)
            return {"error": f"Validation failed: {str(e)}"}

    def validate_sop(self, sop_content: str) -> Dict:
        """Sync public API — safe to call from any context."""
        def _run():
            loop = asyncio.new_event_loop()
            try:
                asyncio.set_event_loop(loop)
                return loop.run_until_complete(self._validate_sop_async(sop_content))
            finally:
                loop.close()

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
            return ex.submit(_run).result()

    async def validate_sop_async(self, sop_content: str) -> Dict:
        """Async public API."""
        return await self._validate_sop_async(sop_content)


def main():
    validator = SOPValidator()
    example_sop = """
    Title: Email Management Procedure
    Purpose: Standardized process for managing company emails.
    Scope: All employees using company email accounts.
    Responsibilities:
    - Check emails daily
    - Managers respond within 2 business days
    """
    result = validator.validate_sop(example_sop)
    if "error" in result:
        print(f"Error: {result['error']}")
    else:
        print(f"Overall Rating: {result['overall_rating']}/10")
        for k, v in result["criteria_scores"].items():
            print(f"  {k}: {v}/10")
        print(f"\nFeedback: {result['feedback']}")


if __name__ == "__main__":
    main()