# src/guardrails/mapping_repository.py
# SOURCE: AWS (adapted) — from pii_mapping_repository.py, using the app's DB session
import uuid
import logging
from datetime import datetime, timezone, timedelta
from typing import List, Dict

try:
    from sop_models import SessionLocal, PIIMapping
except ImportError:
    from ..sop_models import SessionLocal, PIIMapping

from src.guardrails.config import default_config

logger = logging.getLogger(__name__)


class PIIMappingRepository:
    """CRUD for reversible PII mappings, backed by the app's Postgres DB."""

    def store_mappings(self, request_id: str, mappings: List[Dict]) -> None:
        """Persist a batch of {placeholder, original_value, entity_type} dicts."""
        if not mappings:
            return
        session = SessionLocal()
        try:
            expires = datetime.now(timezone.utc) + timedelta(
                days=default_config.retention_days)
            for m in mappings:
                session.add(PIIMapping(
                    id=str(uuid.uuid4()),
                    request_id=request_id,
                    placeholder=m["placeholder"],
                    original_value=m["original_value"],
                    entity_type=m["entity_type"],
                    expires_at=expires,
                ))
            session.commit()
            logger.info("Stored %d PII mappings for request %s",
                        len(mappings), request_id)
        except Exception:
            session.rollback()
            logger.exception("Failed storing PII mappings for %s", request_id)
        finally:
            session.close()

    def get_mappings(self, request_id: str) -> Dict[str, str]:
        """Return {placeholder: original_value} for one request."""
        session = SessionLocal()
        try:
            rows = (session.query(PIIMapping)
                    .filter(PIIMapping.request_id == request_id).all())
            return {r.placeholder: r.original_value for r in rows}
        except Exception:
            logger.exception("Failed fetching PII mappings for %s", request_id)
            return {}
        finally:
            session.close()

    def mark_used_or_delete(self, request_id: str) -> None:
        """After a successful remap, delete (or flag) the request's mappings."""
        session = SessionLocal()
        try:
            q = session.query(PIIMapping).filter(
                PIIMapping.request_id == request_id)
            if default_config.auto_delete_after_remap:
                q.delete()
            else:
                for r in q.all():
                    r.used = True
            session.commit()
        except Exception:
            session.rollback()
            logger.exception("Failed cleanup for %s", request_id)
        finally:
            session.close()

    def cleanup_expired(self) -> int:
        """Delete mappings past their retention window. Returns count removed."""
        session = SessionLocal()
        try:
            now = datetime.now(timezone.utc)
            n = (session.query(PIIMapping)
                 .filter(PIIMapping.expires_at < now).delete())
            session.commit()
            return n
        except Exception:
            session.rollback()
            logger.exception("Cleanup of expired mappings failed")
            return 0
        finally:
            session.close()
