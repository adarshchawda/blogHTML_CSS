# src/guardrails/secure_logging.py
# SOURCE: AWS (ported as-is) — from utils/secure_logging.py
import re
import logging

# Field names whose values should be masked wherever they appear
_SENSITIVE_KEYS = [
    "password", "passwd", "pwd", "secret", "token", "api_key", "apikey",
    "authorization", "auth", "cookie", "ssn", "credit_card", "access_key",
    "secret_key", "connectionstring", "connection_string",
]
# Value-shaped patterns that look like secrets even without a giveaway key name
_SECRET_PATTERNS = [
    re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"),  # JWT
    re.compile(r"\b[A-Za-z0-9+/]{40,}={0,2}\b"),                                    # long base64
    re.compile(r"(?i)(" + "|".join(_SENSITIVE_KEYS) + r")\s*[=:]\s*\S+"),           # key=value
]
_MASK = "***REDACTED***"


class SecureLoggingFilter(logging.Filter):
    """Masks secret-looking content in every log record before it is emitted."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
            for pat in _SECRET_PATTERNS:
                msg = pat.sub(_MASK, msg)
            record.msg = msg
            record.args = ()
        except Exception:
            pass  # never let logging itself raise
        return True


def install_secure_logging() -> None:
    """Attach the filter to the root logger so it covers all modules."""
    root = logging.getLogger()
    if not any(isinstance(f, SecureLoggingFilter) for f in root.filters):
        root.addFilter(SecureLoggingFilter())
    for handler in root.handlers:
        if not any(isinstance(f, SecureLoggingFilter) for f in handler.filters):
            handler.addFilter(SecureLoggingFilter())
