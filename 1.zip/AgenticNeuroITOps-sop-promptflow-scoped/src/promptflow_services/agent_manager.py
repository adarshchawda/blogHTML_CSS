import os
import json
import logging
import asyncio
from typing import List, Dict, Any, Optional
import subprocess, tempfile, re, time, glob, sys
from azure.identity import ManagedIdentityCredential
from azure.storage.blob import BlobClient


from ..promptflow_client import call_promptflow

logger = logging.getLogger(__name__)


class PromptflowManager:
    """Simple Promptflow-backed manager that provides a minimal compatible
    interface for SOP generation used by `sop_service.generate_sop`.
    """
    def __init__(self, config_dir: Optional[str] = None):
        self.llm_config = None
        self.config_dir = config_dir

    def set_llm(self, provider: str, api_key: str, model: str, **kwargs):
        # Store configuration for later use. Promptflow invocation will
        # run the flow which should encapsulate the model choice.
        self.llm_config = {
            "provider": provider,
            "api_key": api_key,
            "model": model,
            **kwargs
        }
        return self.llm_config

    def generate_sop(self, tickets: List[Dict], cluster_name: str, scope_payload=None) -> str:
        # Synchronous wrapper for async generation
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                return asyncio.run(self._generate_sop_async(tickets, cluster_name, scope_payload))
            else:
                return loop.run_until_complete(
                    self._generate_sop_async(tickets, cluster_name, scope_payload)
                )
        except RuntimeError:
            return asyncio.run(self._generate_sop_async(tickets, cluster_name, scope_payload))

    async def _generate_sop_async(self, tickets: List[Dict], cluster_name: str,
                                  scope_payload: Optional[Dict[str, Any]] = None) -> str:
        # The flow declares a single `tickets` input of type string, so the
        # partition context is embedded inside that payload rather than added
        # as a new flow input. This keeps the SOP text specific to the
        # partition without requiring the flow to be redeployed.
        if scope_payload and scope_payload.get('scoped'):
            payload = {
                'partition_scope': scope_payload,
                'instruction': (
                    'These tickets all belong to the partition '
                    f"{scope_payload.get('partition_descriptor')}. Write the SOP "
                    'for that partition only. Do not generalise to other '
                    'lines of business, hosts, services or environments, and '
                    'state the partition explicitly in the SOP title and scope '
                    'section.'
                ),
                'cluster_name': cluster_name,
                'tickets': tickets,
            }
        else:
            payload = {'cluster_name': cluster_name, 'tickets': tickets}

        inputs = {
            "tickets": json.dumps(payload, ensure_ascii=False, default=str)
        }

        # Write to a temporary input file inside the promptflow_services directory
        tmp_dir = os.path.dirname(__file__)
        tmp_file = tempfile.NamedTemporaryFile(mode='w', delete=False, dir=tmp_dir, suffix='.json', encoding='utf-8')
        try:
            
            json.dump(inputs, tmp_file)
            tmp_file.flush()
            input_path = tmp_file.name
        finally:
            tmp_file.close()

        # Allow overriding flow name via environment for flexibility
        flow_name = os.getenv("PROMPTFLOW_FLOW_NAME", "SOP_v3")


        # Ensure user-assigned managed identity client id is exposed as AZURE_CLIENT_ID
        # so DefaultAzureCredential and the pfazure subprocess can pick it up.
        mi_client = os.getenv("MANAGED_IDENTITY_CLIENT_ID") or os.getenv("AZURE_MANAGED_IDENTITY_CLIENT_ID")
        if mi_client:
            os.environ.setdefault("AZURE_CLIENT_ID", mi_client)
            logger.debug("Exported AZURE_CLIENT_ID for subprocess from managed identity: %s", mi_client)

        # Use the temporary input file path when invoking promptflow as a module
        # If Azure workspace info is available via env vars, pass them so pfazure
        # can target the correct workspace when running inside Functions.
        workspace_args = []
        sub_id = os.getenv("AZURE_SUBSCRIPTION_ID","79d2aabe-ccd1-41f5-b679-f1b25c4ea265")
        rg = os.getenv("AZURE_RESOURCE_GROUP","RG-AIA-DE-Engg")
        ws = os.getenv("AZURE_WORKSPACE","ml-llm-experence-dev")
        if sub_id:
            workspace_args += ["--subscription", sub_id]
        if rg:
            workspace_args += ["--resource-group", rg]
        if ws:
            workspace_args += ["--workspace-name", ws]

        candidates = [
            [sys.executable, "-m", "promptflow.azure._cli.entry", "run", "create", "--flow", flow_name, "--data", input_path] + workspace_args,
            [sys.executable, "-c", (
                "from promptflow.azure._cli.entry import main; import sys; "
                + f"sys.argv={json.dumps(['pfazure','run','create','--flow', flow_name, '--data', input_path] + workspace_args)}; main()"
            )],
            # final fallback to the pfazure console script if installed
            ["pfazure", "run", "create", "--flow", flow_name, "--data", input_path] + workspace_args,
        ]

        result = None
        last_exc = None
        for cmd in candidates:
            try:
                logger.info("Trying promptflow invocation: %s", " ".join(cmd))
                result = subprocess.run(cmd, capture_output=True, text=True)
                logger.debug("Invocation returncode=%s stdout=%s stderr=%s", result.returncode, result.stdout, result.stderr)
                # if the command ran (even with non-zero rc) we break and handle rc
                break
            except FileNotFoundError as e:
                # command not available, try next candidate
                logger.debug("Invocation candidate not found: %s", cmd[0])
                last_exc = e
                continue
            except Exception as e:
                last_exc = e
                logger.exception("Error invoking promptflow candidate %s", cmd)
                continue

        if result is None and last_exc:
            raise last_exc
        # Remove the temporary input file so it doesn't clutter the repo
        try:
            os.remove(input_path)
            logger.debug("Removed temporary input file: %s", input_path)
        except Exception:
            logger.debug("Could not remove temporary input file: %s", input_path)
        logger.debug("promptflow run returncode=%s stdout=%s stderr=%s", result.returncode, result.stdout, result.stderr)

        # If the subprocess failed, surface the error immediately to help debugging
        if result.returncode != 0:
            logger.error(
                "Promptflow run command failed (rc=%s). stdout=%s stderr=%s",
                result.returncode,
                result.stdout,
                result.stderr,
            )
            raise RuntimeError(f"Promptflow run failed (rc={result.returncode}): {result.stderr or result.stdout}")

        match = re.search(r'"name":\s*"([^\"]+)"', result.stdout)
        run_name = None
        if match:
            run_name = match.group(1)
            print(run_name)
        else:
            try:
                parsed = json.loads(result.stdout)
                if isinstance(parsed, dict) and "name" in parsed:
                    run_name = parsed["name"]
                    print(run_name)
            except Exception:
                pass


        # Prefer explicit user-assigned managed identity if configured
        mi_client = os.getenv("MANAGED_IDENTITY_CLIENT_ID") or os.getenv("AZURE_MANAGED_IDENTITY_CLIENT_ID") or os.getenv("AZURE_CLIENT_ID")
        if mi_client:
            credential = ManagedIdentityCredential(client_id=mi_client)
        else:
            credential = ManagedIdentityCredential()
        account_url = os.getenv("PROMPTFLOW_BLOB_ACCOUNT_URL")
        # accept either PROMPTFLOW_BLOB_CONTAINER_NAME or PROMPTFLOW_BLOB_CONTAINER
        container = os.getenv("PROMPTFLOW_BLOB_CONTAINER_NAME") or os.getenv("PROMPTFLOW_BLOB_CONTAINER")

        # Remote blob path (may fail if workspace MI or storage permissions are not configured)
        blob = BlobClient(
            account_url=account_url,
            container_name=container,
            blob_name=f"promptflow/PromptFlowArtifacts/{run_name}/flow_outputs/output.jsonl",
            credential=credential
        )

        # Local fallback paths to check
        local_candidates = [
            f"./run_output/{run_name}/flow_outputs/output.jsonl",
            f"./run_output/{run_name}/instance_results.jsonl",
            "./run_output/instance_results.jsonl",
        ]



        def extract_output_from_lines(lines):
            for i, line in enumerate(lines):
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    # not JSON, skip
                    continue
                # top-level 'output'
                if isinstance(obj, dict) and "output" in obj:
                    return obj["output"]
                # sometimes nested under 'outputs' or 'result'
                if isinstance(obj, dict) and "outputs" in obj and isinstance(obj["outputs"], dict) and "output" in obj["outputs"]:
                    return obj["outputs"]["output"]
                if isinstance(obj, dict) and "result" in obj:
                    # if result is a dict with output
                    if isinstance(obj["result"], dict) and "output" in obj["result"]:
                        return obj["result"]["output"]
                    else:
                        return obj["result"]
            return None


        data_text = None

        # Poll for the run outputs (remote blob first, then local candidates and glob fallbacks).
        # Poll budget. Kept comfortably under the Azure Functions HTTP limit
        # (230s at the load balancer) so the request is not killed mid-poll.
        MAX_RETRIES = int(os.getenv('PROMPTFLOW_POLL_ATTEMPTS', '40'))
        SLEEP_SECONDS = int(os.getenv('PROMPTFLOW_POLL_INTERVAL', '5'))

        # extended local candidates to include run_output_1 and accommodate different folder layouts
        extended_local = local_candidates + [
            f"./run_output_1/{run_name}/flow_outputs/output.jsonl",
            f"./run_output_1/{run_name}/instance_results.jsonl",
        ]

        def _run_failed():
            """Ask pfazure whether the run already terminated in failure.

            Without this the loop would keep polling for a blob that will
            never be written, burning the entire budget on a run that is
            already dead.
            """
            if not run_name:
                return False
            try:
                probe = subprocess.run(
                    [sys.executable, "-m", "promptflow.azure._cli.entry",
                     "run", "show", "--name", run_name] + workspace_args,
                    capture_output=True, text=True, timeout=60,
                )
                return '"status": "Failed"' in (probe.stdout or '')
            except Exception:
                return False

        for attempt in range(MAX_RETRIES):
            if attempt and attempt % 4 == 0 and _run_failed():
                raise RuntimeError(
                    f"Promptflow run '{run_name}' reported status Failed. "
                    f"Open the run in Azure ML for the node-level error."
                )
            # try remote blob if a run_name exists
            if run_name:
                try:
                    # prefer existence check if available
                    try:
                        exists = blob.exists()
                    except Exception:
                        exists = None
                    if exists is True or exists is None:
                        # if exists is None we'll try download and catch failures
                        blob_data = blob.download_blob().readall()
                        data_text = blob_data.decode()
                        print("Loaded remote blob on attempt", attempt + 1)
                        break
                except Exception:
                    # remote not ready yet
                    pass

            # check explicit local candidate paths
            for p in extended_local:
                try:
                    if p and os.path.exists(p) and os.path.getsize(p) > 0:
                        with open(p, "r", encoding="utf-8") as f:
                            data_text = f.read()
                        print(f"Loaded local file: {p}")
                        break
                except Exception:
                    continue
            if data_text:
                break

            # glob search to handle variant folder names (recursive)
            if run_name:
                pattern = f"./run_output*/{run_name}*/**/*.jsonl"
            else:
                pattern = "./run_output*/**/flow_outputs/*.jsonl"
            matches = glob.glob(pattern, recursive=True)
            for m in matches:
                try:
                    if os.path.getsize(m) > 0:
                        with open(m, "r", encoding="utf-8") as f:
                            data_text = f.read()
                        print(f"Loaded local glob file: {m}")
                        break
                except Exception:
                    continue
            if data_text:
                break

            print(f"Attempt {attempt+1}/{MAX_RETRIES}: output not yet available; sleeping {SLEEP_SECONDS}s")
            # await, not time.sleep: this coroutine runs on the Function's
            # event loop and a blocking sleep would stall every other request.
            await asyncio.sleep(SLEEP_SECONDS)

        if data_text is None:
            # RuntimeError, never SystemExit. SystemExit derives from
            # BaseException, so it slips past every `except Exception` between
            # here and the FastAPI route -- killing the ServiceNow attach with
            # nothing written to the log. RuntimeError is caught, logged, and
            # contained, so the rest of the batch still completes.
            blob_path = f"promptflow/PromptFlowArtifacts/{run_name}/flow_outputs/output.jsonl"
            raise RuntimeError(
                f"Promptflow run '{run_name}' produced no output after "
                f"{MAX_RETRIES * SLEEP_SECONDS}s of polling. Checked "
                f"{account_url}/{container}/{blob_path} . "
                f"Inspect it with: pfazure run show --name {run_name}"
            )

        lines = data_text.splitlines()
        output_value = extract_output_from_lines(lines)
        if output_value is None:
            print("Could not find an 'output' field in the available run data. Available first-line JSON keys:")
            # try to print keys from first parsable JSON line
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        print(list(obj.keys()))
                    else:
                        print(type(obj))
                    break
                except Exception:
                    continue
            raise RuntimeError(
                f"Promptflow run '{run_name}' returned data with no 'output' "
                f"field. The flow ran but sop_writer produced nothing."
            )

        return output_value

