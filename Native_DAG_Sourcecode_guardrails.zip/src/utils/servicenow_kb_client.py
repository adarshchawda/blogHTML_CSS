"""
Direct MCP Server Client for ServiceNow KB Integration
Connects directly to MCP server using JSON-RPC 2.0 format matching the frontend approach
"""

import os
import uuid
import json
import time
import logging
import requests
from typing import Dict, Any, Optional

# Configure logging
logger = logging.getLogger(__name__)

# MCP Server settings - Using same approach as frontend and ServiceNow routes
MCP_SERVER_URL = os.environ.get('MCP_SERVER_URL', 'http://localhost:51526')

# Ensure URL has no trailing slash
if MCP_SERVER_URL.endswith('/'):
    MCP_SERVER_URL = MCP_SERVER_URL[:-1]

# Simplify to match frontend approach - always use /mcp endpoint for JSON-RPC
MCP_RPC_ENDPOINT = MCP_SERVER_URL + "/mcp" if not MCP_SERVER_URL.endswith('/mcp') else MCP_SERVER_URL

# Debug info to help troubleshoot connection issues
logger.info("ServiceNow KB Client - MCP SERVER CONFIGURATION:")
logger.info("MCP_SERVER_URL: %s", MCP_SERVER_URL)
logger.info("MCP_RPC_ENDPOINT: %s", MCP_RPC_ENDPOINT)

def call_mcp_method(method_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Call an MCP server method directly using JSON-RPC 2.0
    
    Args:
        method_name: Name of the method to call
        params: Parameters for the method
    
    Returns:
        Dictionary with the response
    """
    try:
        # Create message ID
        message_id = str(int(time.time() * 1000))
        
        # Create JSON-RPC 2.0 payload
        payload = {
            "jsonrpc": "2.0",
            "id": message_id,
            "method": method_name,
            "params": params
        }
        
        logger.info(f"Calling MCP method '{method_name}' with params: {params}")
        
        # Make the request
        response = requests.post(
            MCP_RPC_ENDPOINT,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=60  # 60 second timeout for long operations
        )
        
        # Check for HTTP errors
        response.raise_for_status()
        
        # Parse the response
        result = response.json()
        logger.info(f"MCP response for '{method_name}': {result}")
        
        # Handle JSON-RPC error format - could be string or object
        if 'error' in result:
            error = result.get('error')
            if isinstance(error, dict):
                error_message = error.get('message', 'Unknown error from MCP server')
            else:
                # Error could be a string
                error_message = str(error)
                
            logger.error(f"Error from MCP method '{method_name}': {error_message}")
            return {'status': 'error', 'message': error_message, 'error': error_message}
        
        # Return the result field from JSON-RPC response
        return result.get('result', result)
        
    except requests.exceptions.RequestException as e:
        error_message = f"Failed to call MCP method '{method_name}': {str(e)}"
        logger.error(error_message)
        return {
            "status": "error",
            "message": error_message,
            "error": str(e)
        }
    except Exception as e:
        error_message = f"Unexpected error calling MCP method '{method_name}': {str(e)}"
        logger.error(error_message)
        return {
            "status": "error",
            "message": error_message,
            "error": str(e)
        }

# ---------------------------------------------------------------------------
# SOP GEN Status (u_sop_gen_status) intermediate-status updates
# ---------------------------------------------------------------------------
# ServiceNow incident custom dropdown. Stored choice values (confirmed from the
# incident form): Yet to start = "1" (default) | In Progress = "2" | Completed = "3".
#
# The write reuses the SAME MCP path the KB create/link calls use (call_mcp_method
# -> update_servicenow_record_tool with a generic update_data dict), so no new
# plumbing and no MCP-server change. All writes are best-effort: a status-update
# failure is logged and swallowed so it can never break SOP generation/linking.
SOP_GEN_STATUS_COLUMN = os.environ.get("SOP_GEN_STATUS_COLUMN", "u_sop_gen_status")
SOP_STATUS_YET_TO_START = os.environ.get("SOP_STATUS_YET_TO_START", "1")
SOP_STATUS_IN_PROGRESS = os.environ.get("SOP_STATUS_IN_PROGRESS", "2")
SOP_STATUS_COMPLETED = os.environ.get("SOP_STATUS_COMPLETED", "3")

_SOP_STATUS_LABELS = {
    SOP_STATUS_YET_TO_START: "Yet to start",
    SOP_STATUS_IN_PROGRESS: "In Progress",
    SOP_STATUS_COMPLETED: "Completed",
}


def _record_sop_ticket_status(incident_id: str, status_label: str) -> None:
    """Mirror a status transition into the local sop_ticket_status tracking table.

    Delegates to sop_models.upsert_sop_ticket_status (one row per ticket, updated in
    place). Imported lazily so importing this client never triggers a DB connection,
    and fully best-effort: any error is logged and swallowed.
    """
    if not incident_id or not status_label:
        return
    try:
        try:
            from sop_models import upsert_sop_ticket_status
        except ImportError:
            from ..sop_models import upsert_sop_ticket_status
        upsert_sop_ticket_status(incident_id, status_label)
    except Exception as e:  # tracking must never break the flow
        logger.error("sop_ticket_status tracking failed for %s: %s", incident_id, str(e))


def update_sop_gen_status(incident_id: str, status_value: str) -> Dict[str, Any]:
    """Update u_sop_gen_status for a single incident via the MCP server.

    Best-effort: returns the MCP response on success, or an error dict on failure,
    but never raises - callers treat this as fire-and-forget.

    Args:
        incident_id: the ServiceNow incident number (e.g. "INC0164453").
        status_value: one of "1" (Yet to start) / "2" (In Progress) / "3" (Completed).
    """
    if not incident_id:
        return {"status": "error", "message": "no incident_id provided"}
    try:
        params = {
            "number": incident_id,
            "update_data": {SOP_GEN_STATUS_COLUMN: status_value},
        }
        result = call_mcp_method("update_servicenow_record_tool", params)
        label = _SOP_STATUS_LABELS.get(status_value, status_value)
        if isinstance(result, dict) and result.get("status") == "error":
            logger.error(
                "Failed to set %s='%s' (%s) for incident %s: %s",
                SOP_GEN_STATUS_COLUMN, status_value, label, incident_id, result.get("message"),
            )
        else:
            logger.info(
                "u_sop_gen_status set to '%s' (%s) for incident %s",
                status_value, label, incident_id,
            )
        # Mirror this transition into the local SOP status-tracking table so the
        # ticket's lifecycle (initial/current status + timestamps) is visible without
        # querying ServiceNow. Best-effort: a tracking failure must never affect the
        # ServiceNow write or the flow, so it is logged and swallowed here.
        _record_sop_ticket_status(incident_id, label)
        return result
    except Exception as e:  # never let a status write break the flow
        logger.error("Exception setting u_sop_gen_status for %s: %s", incident_id, str(e))
        return {"status": "error", "message": str(e)}


async def update_sop_gen_status_async(incident_id: str, status_value: str) -> Dict[str, Any]:
    """Async wrapper: runs the blocking MCP status write in a thread so it can be
    awaited / gathered alongside the flow's other async ServiceNow calls."""
    import asyncio
    return await asyncio.to_thread(update_sop_gen_status, incident_id, status_value)


async def update_many_sop_gen_status_async(incident_ids, status_value: str):
    """Update the same status for many incidents concurrently (parallel writes).

    Uses asyncio.gather so all incident updates for a batch fan out at once,
    reusing the flow's existing event loop. Returns the list of results.
    """
    import asyncio
    tasks = [update_sop_gen_status_async(inc, status_value) for inc in incident_ids if inc]
    if not tasks:
        return []
    return await asyncio.gather(*tasks, return_exceptions=True)


def create_kb_article(title: str, content: str, incident_id: Optional[str] = None, u_validator_output: Optional[Any] = None, validator_output: Optional[Any] = None) -> Dict[str, Any]:
    """
    Create a ServiceNow Knowledge Base article using the MCP server
    
    Args:
        title: Article title
        content: Article content in HTML format
        servicenow_connection_id: ServiceNow connection ID to use
        incident_id: Optional incident ID to link the article to
    
    Returns:
        Dictionary with the response containing article details
    """
    # Prepare parameters
    params = {
        "sop_title": title,     # Using parameter names matching the server handler
        "sop_content": content
    }

    # Add incident ID if provided
    if incident_id:
        params["incident_ids"] = [incident_id]  # Server expects a list

    # Helper to extract JSON from text (reuse logic from link_kb_article)
    def _extract_json_from_text(text: str) -> Optional[dict]:
        try:
            s = text.strip()
            if s.startswith('```'):
                parts = s.split('\n')
                if parts[0].startswith('```'):
                    parts = parts[1:]
                if parts and parts[-1].strip().endswith('```'):
                    parts = parts[:-1]
                s = '\n'.join(parts).strip()
            try:
                return json.loads(s)
            except Exception:
                start = s.find('{')
                end = s.rfind('}')
                if start != -1 and end != -1 and end > start:
                    candidate = s[start:end+1]
                    try:
                        return json.loads(candidate)
                    except Exception:
                        return None
                return None
        except Exception:
            return None

    # Accept either `u_validator_output` or legacy `validator_output` keyword
    if validator_output is not None and u_validator_output is None:
        u_validator_output = validator_output

    normalized_str = None
    if u_validator_output is not None:
        try:
            if isinstance(u_validator_output, dict):
                normalized = {
                    'overall_rating': u_validator_output.get('overall_rating'),
                    'criteria_scores': u_validator_output.get('criteria_scores'),
                    'feedback': u_validator_output.get('feedback')
                }
                if not any(normalized.values()):
                    normalized_str = json.dumps(u_validator_output)
                else:
                    normalized_str = json.dumps(normalized)
            elif isinstance(u_validator_output, str):
                parsed = _extract_json_from_text(u_validator_output)
                if parsed and isinstance(parsed, dict):
                    normalized = {
                        'overall_rating': parsed.get('overall_rating'),
                        'criteria_scores': parsed.get('criteria_scores'),
                        'feedback': parsed.get('feedback')
                    }
                    if not any(normalized.values()):
                        normalized_str = json.dumps(parsed)
                    else:
                        normalized_str = json.dumps(normalized)
                else:
                    normalized_str = json.dumps({'feedback': u_validator_output})
            else:
                normalized_str = json.dumps({'feedback': str(u_validator_output)})
        except Exception as e:
            normalized_str = json.dumps({'error': str(e)})

    if normalized_str is not None:
        # ALWAYS send as string
        params["validator_output"] = normalized_str
        params["u_validator_output"] = normalized_str

    # Call the MCP method with the correct name
    return call_mcp_method("create_kb_article", params)

def link_kb_article(article_id: str, incident_id: Optional[str] = None, u_validator_output: Optional[Any] = None, validator_output: Optional[Any] = None) -> Dict[str, Any]:
    """
    Link a Knowledge Base article to a ServiceNow incident using the MCP server
    
    Args:
        article_id: Knowledge Base article ID
        incident_id: ServiceNow incident ID
        servicenow_connection_id: ServiceNow connection ID to use
    
    Returns:
        Dictionary with the response
    """
    # There's no direct method for linking KB articles to incidents in the MCP server
    # Instead, we use the create_kb_article method with an incident_ids parameter
    # as that's how the MCP server handles both creation and linking
    
    # Prepare parameters - MCP expects a list for incident_ids
    inc_ids = [incident_id] if incident_id else []
    def _extract_json_from_text(text: str) -> Optional[dict]:
        # Remove surrounding markdown code fences if present
        try:
            s = text.strip()
            # remove ```json or ``` markers
            if s.startswith('```'):
                # drop first line if it's ``` or ```json
                parts = s.split('\n')
                # remove starting ```... line
                if parts[0].startswith('```'):
                    parts = parts[1:]
                # remove trailing ``` if present
                if parts and parts[-1].strip().endswith('```'):
                    parts = parts[:-1]
                s = '\n'.join(parts).strip()

            # Try to load as JSON directly
            try:
                return json.loads(s)
            except Exception:
                # Fallback: extract first {...} block
                start = s.find('{')
                end = s.rfind('}')
                if start != -1 and end != -1 and end > start:
                    candidate = s[start:end+1]
                    try:
                        return json.loads(candidate)
                    except Exception:
                        return None
                return None
        except Exception:
            return None

    # Accept either `u_validator_output` or legacy `validator_output` keyword
    if validator_output is not None and u_validator_output is None:
        u_validator_output = validator_output

    # Normalize/prepare a single serialized `u_validator_output` string to send
    normalized_str = None
    if u_validator_output is not None:
        try:
            # Determine normalized representation
            if isinstance(u_validator_output, dict):
                normalized = {
                    'overall_rating': u_validator_output.get('overall_rating'),
                    'criteria_scores': u_validator_output.get('criteria_scores'),
                    'feedback': u_validator_output.get('feedback')
                }
                if not any(normalized.values()):
                    # Preserve original dict if it contains other diagnostic keys
                    normalized_str = json.dumps(u_validator_output)
                else:
                    normalized_str = json.dumps(normalized)

            elif isinstance(u_validator_output, str):
                parsed = _extract_json_from_text(u_validator_output)
                if parsed and isinstance(parsed, dict):
                    normalized = {
                        'overall_rating': parsed.get('overall_rating'),
                        'criteria_scores': parsed.get('criteria_scores'),
                        'feedback': parsed.get('feedback')
                    }
                    if not any(normalized.values()):
                        normalized_str = json.dumps(parsed)
                    else:
                        normalized_str = json.dumps(normalized)
                else:
                    # Not parseable JSON -> store raw string under feedback
                    normalized_str = json.dumps({'feedback': u_validator_output})

            else:
                # Unknown type -> stringify
                normalized_str = json.dumps({'feedback': str(u_validator_output)})

        except Exception as e:
            normalized_str = json.dumps({'error': str(e)})

    params = {
        "article_id": article_id,        # Pass existing article ID
        "incident_ids": inc_ids,
    }
    # Handler expects `validator_output`; include it only when available.
    # Send a parsed object when normalized_str contains JSON so MCP receives
    # a structured value rather than an escaped JSON string.
    if normalized_str is not None:
        # ALWAYS send as string
        params["validator_output"] = normalized_str
        params["u_validator_output"] = normalized_str
    
    # Call the same MCP method as create_kb_article since linking happens there
    return call_mcp_method("link_kb_article", params)
