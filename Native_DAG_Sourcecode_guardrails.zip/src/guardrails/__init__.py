"""Guardrails package: PII masking, secret redaction, content safety, secure logging, and audit for the Native DAG SOP engine."""
