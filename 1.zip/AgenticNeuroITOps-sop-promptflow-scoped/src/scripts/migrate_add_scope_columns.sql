-- ===========================================================================
-- Scoped (partitioned) clustering -- schema migration
--
-- Run once against the target database before deploying the change.
-- Every statement is idempotent, so re-running this file is harmless.
--
-- All columns are NULLABLE on purpose. Rows written before this migration keep
-- NULL on both scope columns, which is exactly what the unscoped code path
-- filters for -- so clearing SEC_CLUSTER_FIELD is a true rollback.
-- ===========================================================================

BEGIN;

-- pgvector must exist for the clusters.embedding VECTOR column (already the
-- case on an existing install; included so a fresh database also works).
CREATE EXTENSION IF NOT EXISTS vector;

-- ---------------------------------------------------------------------------
-- tickets: which partition did this ticket resolve to?
-- ---------------------------------------------------------------------------
ALTER TABLE tickets  ADD COLUMN IF NOT EXISTS sec_cluster_field VARCHAR(255);
ALTER TABLE tickets  ADD COLUMN IF NOT EXISTS sec_cluster_value VARCHAR(255);

-- ---------------------------------------------------------------------------
-- clusters: THE partition boundary. Every similarity lookup filters on both
-- of these columns, which is what stops a cluster in one partition from being
-- offered as a candidate for a ticket in another.
-- ---------------------------------------------------------------------------
ALTER TABLE clusters ADD COLUMN IF NOT EXISTS sec_cluster_field VARCHAR(255);
ALTER TABLE clusters ADD COLUMN IF NOT EXISTS sec_cluster_value VARCHAR(255);

-- ---------------------------------------------------------------------------
-- sops: acceptance criterion "All SOP records in the DB are tagged with the
-- configured scope-key type and value". Tagging the SOP row directly (rather
-- than only reaching it via clusters.sop_id) means an SOP can be audited or
-- queried by partition on its own.
-- ---------------------------------------------------------------------------
ALTER TABLE sops     ADD COLUMN IF NOT EXISTS sec_cluster_field VARCHAR(255);
ALTER TABLE sops     ADD COLUMN IF NOT EXISTS sec_cluster_value VARCHAR(255);

-- ---------------------------------------------------------------------------
-- Composite indexes. Without these, every incoming ticket full-scans
-- `clusters`. With a composite scope key such as
-- u_hostname,u_env,business_service you will have thousands of partitions,
-- so this matters almost immediately.
-- ---------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS ix_tickets_scope
    ON tickets  (sec_cluster_field, sec_cluster_value);

CREATE INDEX IF NOT EXISTS ix_clusters_scope
    ON clusters (sec_cluster_field, sec_cluster_value);

CREATE INDEX IF NOT EXISTS ix_sops_scope
    ON sops     (sec_cluster_field, sec_cluster_value);

COMMIT;

-- ---------------------------------------------------------------------------
-- Verify: expect six rows.
-- ---------------------------------------------------------------------------
SELECT table_name, column_name
FROM   information_schema.columns
WHERE  column_name LIKE 'sec_cluster%'
ORDER  BY table_name, column_name;
