"""Offline proof of the FULL pipeline: partition -> cluster -> SOP -> ServiceNow.

Test 8 in test_scope_isolation.py proves the clustering boundary holds. This
file proves the rest of the chain: that each partition gets its own SOP, that the
SOP row is tagged with its partition, and that the KB article is actually
attached to each incident.

Everything external is stubbed -- no Postgres, no Key Vault, no Azure OpenAI, no
Promptflow, no ServiceNow -- so this runs anywhere.

What it asserts:

  1. Two partitions with IDENTICAL ticket text produce TWO different SOPs.
  2. Every SOP row is tagged with the scope-key type and value (AC #2).
  3. SOP titles are partition-distinguishable (SOP_RB_... vs SOP_INS_...).
  4. A KB article is created per SOP and attached to that partition's incidents,
     and never to another partition's.
  5. The Promptflow input carries the partition scope, so the generated text is
     partition-specific.
  6. A Promptflow failure in ONE partition does not stop the other partitions
     from generating and attaching their SOPs. (This is the regression that made
     the whole batch silently die before.)

Usage:
    python src/scripts/test_pipeline_end_to_end.py
"""
import asyncio
import json
import os
import sys
import types
import uuid

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ---------------------------------------------------------------------------
# Recorders -- what the pipeline did
# ---------------------------------------------------------------------------
KB_ARTICLES = []      # every create_kb_article call
KB_LINKS = []         # every link_kb_article call
PF_INPUTS = []        # every Promptflow invocation payload
FAIL_PARTITIONS = set()   # partitions whose Promptflow call should blow up


# ---------------------------------------------------------------------------
# Fake ORM
# ---------------------------------------------------------------------------
class _Col:
    def __init__(self, name):
        self.name = name

    def __eq__(self, other):
        return ("eq", self.name, other)

    def isnot(self, other):
        return ("isnot", self.name, other)

    def is_(self, other):
        return ("is", self.name, other)


class Row:
    _cols = ()

    def __init__(self, **kw):
        for c in self._cols:
            setattr(self, c, kw.get(c))
        self.tickets = []

    def __repr__(self):
        return f"<{type(self).__name__} {getattr(self, 'id', '')[:8]}>"


class SOP(Row):
    _cols = ("id", "title", "description", "content", "document_path", "embedding",
             "created_at", "updated_at", "article_id",
             "sec_cluster_field", "sec_cluster_value")
    id = _Col("id"); sec_cluster_field = _Col("sec_cluster_field")
    sec_cluster_value = _Col("sec_cluster_value")


class Cluster(Row):
    _cols = ("id", "name", "description", "justification", "sop_id", "embedding",
             "is_test_cluster", "created_at", "updated_at",
             "sec_cluster_field", "sec_cluster_value")
    id = _Col("id"); embedding = _Col("embedding")
    sec_cluster_field = _Col("sec_cluster_field")
    sec_cluster_value = _Col("sec_cluster_value")


class Ticket(Row):
    _cols = ("id", "external_id", "title", "short_description", "description",
             "status", "priority", "category", "subcategory", "assigned_to",
             "created_at", "updated_at", "embedding", "additional_data",
             "sec_cluster_field", "sec_cluster_value")
    id = _Col("id"); external_id = _Col("external_id")
    sec_cluster_field = _Col("sec_cluster_field")
    sec_cluster_value = _Col("sec_cluster_value")


STORE = {SOP: {}, Cluster: {}, Ticket: {}}


class FakeQuery:
    def __init__(self, model, rows, cols):
        self.model, self.rows, self.cols = model, rows, cols

    def filter(self, *conds):
        rows = self.rows
        for kind, col, val in conds:
            if kind == "eq":
                rows = [r for r in rows if getattr(r, col) == val]
            elif kind == "isnot":
                rows = [r for r in rows if getattr(r, col) is not val]
            elif kind == "is":
                rows = [r for r in rows if getattr(r, col) is val]
        return FakeQuery(self.model, rows, self.cols)

    def filter_by(self, **kw):
        rows = [r for r in self.rows if all(getattr(r, k) == v for k, v in kw.items())]
        return FakeQuery(self.model, rows, self.cols)

    def all(self):
        if self.cols:
            return [tuple(getattr(r, c) for c in self.cols) for r in self.rows]
        return list(self.rows)

    def count(self):
        return len(self.rows)

    def first(self):
        return self.rows[0] if self.rows else None


class FakeSession:
    def query(self, *entities):
        cols, model = [], None
        for e in entities:
            if isinstance(e, _Col):
                cols.append(e.name)
            elif isinstance(e, type):
                model = e
        if model is None:
            # column-only query: infer the owning model
            for m in STORE:
                if all(hasattr(m, c) for c in cols):
                    model = m
                    break
        return FakeQuery(model, list(STORE[model].values()), cols)

    def get(self, model, pk):
        return STORE[model].get(pk)

    def add(self, obj):
        STORE[type(obj)][obj.id] = obj

    def execute(self, *a, **k):
        return None

    def flush(self):
        pass

    def commit(self):
        pass

    def rollback(self):
        pass

    def close(self):
        pass

    def refresh(self, _obj):
        pass

    def expunge(self, _obj):
        pass


_SESSION = FakeSession()


class ScopedSessionLike:
    """Callable like scoped_session, and proxies session methods directly."""

    def __call__(self):
        return _SESSION

    def __getattr__(self, name):
        return getattr(_SESSION, name)


# ---------------------------------------------------------------------------
# Stub modules
# ---------------------------------------------------------------------------
def stub(name, **attrs):
    m = types.ModuleType(name)
    for k, v in attrs.items():
        setattr(m, k, v)
    sys.modules[name] = m
    return m


PKG = "e2e"
stub(PKG)
stub(f"{PKG}.utils")

stub(f"{PKG}.sop_models",
     db=types.SimpleNamespace(session=_SESSION),
     SOP=SOP, Cluster=Cluster, Ticket=Ticket,
     cluster_ticket_mapping=object(),
     db_session=ScopedSessionLike(),
     SessionLocal=lambda: _SESSION,
     init_db=lambda **k: None)


class LLMConfigManager:
    @staticmethod
    def get_config():
        return {"llm_provider": "azure", "api_key": "k", "model": "gpt-4o",
                "embedding_model": "text-embedding-ada-002"}

    @staticmethod
    def set_environment_variables(_c):
        pass


stub(f"{PKG}.utils.llm_config", LLMConfigManager=LLMConfigManager)


def create_kb_article(title, content, incident_id=None, validator_output=None, **kw):
    article_id = f"KB{len(KB_ARTICLES) + 1:04d}"
    KB_ARTICLES.append({"article_id": article_id, "title": title, "content": content})
    return {"status": "success", "article_id": article_id}


def link_kb_article(article_id=None, incident_id=None, validator_output=None, **kw):
    KB_LINKS.append({"article_id": article_id, "incident_id": incident_id})
    return {"status": "success"}


stub(f"{PKG}.utils.servicenow_kb_client",
     create_kb_article=create_kb_article, link_kb_article=link_kb_article)


class PromptflowManager:
    """Records the payload it would send, and can be told to fail per partition."""

    def __init__(self, config_dir=None):
        self.llm_config = None

    def set_llm(self, provider, api_key, model, **kw):
        self.llm_config = {"provider": provider, "model": model}
        return self.llm_config

    async def _generate_sop_async(self, tickets, cluster_name, scope_payload=None):
        PF_INPUTS.append({"cluster_name": cluster_name, "scope": scope_payload,
                          "ticket_count": len(tickets)})
        value = (scope_payload or {}).get("sec_cluster_value")
        if value in FAIL_PARTITIONS:
            # Mirror the real failure mode after the SystemExit fix.
            raise RuntimeError(
                f"Promptflow run produced no output after 200s of polling "
                f"(simulated failure for partition {value})"
            )
        descriptor = (scope_payload or {}).get("partition_descriptor", "unscoped")
        return (f"# {cluster_name} Standard Operating Procedure\n\n"
                f"## 1. Scope\n{descriptor}\n\n## 2. Overview\nGenerated for {descriptor}.\n")


stub(f"{PKG}.promptflow_services")
stub(f"{PKG}.promptflow_services.agent_manager", PromptflowManager=PromptflowManager)
stub(f"{PKG}.load_env", load_env_from_keyvault=lambda: None)

# openai / azure shims so clustering_manager imports
stub("openai", AzureOpenAI=object)

# Minimal sqlalchemy shim -- the fake ORM above does the real work, so only
# the two symbols sop_service imports at module level are needed.
if "sqlalchemy" not in sys.modules:
    class IntegrityError(Exception):
        pass

    def insert(_table):
        class _Stmt:
            def values(self, **kw):
                return self
        return _Stmt()

    stub("sqlalchemy", text=lambda s: s)
    stub("sqlalchemy.exc", IntegrityError=IntegrityError)
    stub("sqlalchemy.sql")
    stub("sqlalchemy.sql.expression", insert=insert)


# ---------------------------------------------------------------------------
# Load the REAL clustering_manager and sop_service against the stubs
# ---------------------------------------------------------------------------
def load_real(path, module_name, rewrites):
    src = open(path, encoding="utf-8").read()
    for old, new in rewrites:
        src = src.replace(old, new)
    mod = types.ModuleType(module_name)
    mod.__dict__["__file__"] = path
    sys.modules[module_name] = mod
    exec(compile(src, path, "exec"), mod.__dict__)  # noqa: S102
    return mod


cm = load_real(
    os.path.join(SRC, "clustering", "clustering_manager.py"),
    f"{PKG}.clustering.clustering_manager",
    [("from ..sop_models import", f"from {PKG}.sop_models import"),
     ("from ..utils.llm_config import", f"from {PKG}.utils.llm_config import"),
     ("from ..scope_config import", "from scope_config import")],
)

# Deterministic embedder keyed on a `signature` field.
SIGS = {"storage_timeout": 0, "cert_expiry": 1, "memory_leak": 2}
DIM = 8


def fake_embeddings(self, tickets, fields):
    out = []
    for t in tickets:
        v = np.zeros(DIM, dtype=np.float32)
        v[SIGS.get(t.get("signature", "storage_timeout"), 0)] = 1.0
        out.append(v)
    return np.array(out, dtype=np.float32)


cm.ClusteringManager.get_embeddings = fake_embeddings
stub(f"{PKG}.clustering")
sys.modules[f"{PKG}.clustering.clustering_manager"] = cm

svc = load_real(
    os.path.join(SRC, "sop_service.py"),
    f"{PKG}.sop_service",
    [("from sop_models import", f"from {PKG}.sop_models import"),
     ("from promptflow_services.agent_manager import", f"from {PKG}.promptflow_services.agent_manager import"),
     ("from .sop_models import", f"from {PKG}.sop_models import"),
     ("from .promptflow_services.agent_manager import", f"from {PKG}.promptflow_services.agent_manager import"),
     ("from .utils.llm_config import", f"from {PKG}.utils.llm_config import"),
     ("from .clustering.clustering_manager import", f"from {PKG}.clustering.clustering_manager import"),
     ("from .utils.servicenow_kb_client import", f"from {PKG}.utils.servicenow_kb_client import"),
     ("from utils.servicenow_kb_client import", f"from {PKG}.utils.servicenow_kb_client import"),
     ("from .scope_config import", "from scope_config import"),
     ("from load_env import", f"from {PKG}.load_env import"),
     ("from .load_env import", f"from {PKG}.load_env import")],
)

# Keep SOP markdown out of the repo during the test.
svc._save_sop_file = lambda sop_id, content: f"/tmp/sops/{sop_id}.md"
svc._is_validator_enabled = lambda: False


# ---------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------
PASS, FAIL = [], []


def check(label, cond, detail=""):
    (PASS if cond else FAIL).append(label)
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}")
    if detail and not cond:
        print(f"         {detail}")


def banner(t):
    print()
    print("=" * 74)
    print(t)
    print("=" * 74)


def reset():
    for m in STORE:
        STORE[m].clear()
    KB_ARTICLES.clear()
    KB_LINKS.clear()
    PF_INPUTS.clear()
    FAIL_PARTITIONS.clear()


KW = {"llm_provider": "azure", "model": "gpt-4o", "api_key": "k",
      "servicenow_integration": True}


# ===========================================================================
banner("TEST 1 -- two partitions, identical text -> two separate SOPs")
reset()
os.environ["SEC_CLUSTER_FIELD"] = "u_application_lob"

tickets = [
    {"id": "s1", "number": "INC6001", "u_application_lob": "Retail Banking",
     "signature": "storage_timeout", "short_description": "app pool hung, disk I/O timeout",
     "description": "d", "resolution_notes": "r"},
    {"id": "s2", "number": "INC6002", "u_application_lob": "Retail Banking",
     "signature": "storage_timeout", "short_description": "app pool hung, disk I/O timeout",
     "description": "d", "resolution_notes": "r"},
    {"id": "s3", "number": "INC6007", "u_application_lob": "Insurance",
     "signature": "storage_timeout", "short_description": "app pool hung, disk I/O timeout",
     "description": "d", "resolution_notes": "r"},
]

result = asyncio.run(svc.process_tickets([dict(t) for t in tickets], **KW))

print(f"    status   : {result.get('status')}")
print(f"    message  : {result.get('message')}")
print(f"    partitions: {result.get('scope', {}).get('partitions')}")
print()
for s in STORE[SOP].values():
    print(f"    SOP {s.id[:8]}  field={s.sec_cluster_field!r}  value={s.sec_cluster_value!r}")
    print(f"        title  : {s.title}")
    print(f"        article: {s.article_id}")

sops = list(STORE[SOP].values())
check("two SOPs generated (one per partition)", len(sops) == 2, f"got {len(sops)}")
check("every SOP row is tagged with the scope-key type",
      all(s.sec_cluster_field == "u_application_lob" for s in sops))
check("every SOP row is tagged with the scope-key value",
      {s.sec_cluster_value for s in sops} == {"Retail Banking", "Insurance"},
      f"got {{s.sec_cluster_value for s in sops}}")
check("SOP titles are partition-distinguishable",
      len({s.title.split('|')[0] for s in sops}) == 2,
      f"titles: {[s.title for s in sops]}")
check("titles use the partition token (SOP_RB / SOP_INS)",
      any("SOP_RB" in s.title for s in sops) and any("SOP_INS" in s.title for s in sops),
      f"titles: {[s.title for s in sops]}")

banner("TEST 2 -- KB article created per SOP and attached to the right incidents")
print(f"    KB articles created: {len(KB_ARTICLES)}")
for a in KB_ARTICLES:
    print(f"      {a['article_id']}  {a['title'][:64]}")
print(f"    KB links: {len(KB_LINKS)}")
for l in KB_LINKS:
    print(f"      {l['article_id']} -> {l['incident_id']}")

check("one KB article per SOP", len(KB_ARTICLES) == 2, f"got {len(KB_ARTICLES)}")
check("every SOP row got its article_id persisted",
      all(s.article_id for s in sops))
check("all three incidents received an attachment",
      {l["incident_id"] for l in KB_LINKS} == {"INC6001", "INC6002", "INC6007"},
      f"got {{l['incident_id'] for l in KB_LINKS}}")

# The RB article must not be linked to the Insurance incident, or vice versa.
rb_sop = next(s for s in sops if s.sec_cluster_value == "Retail Banking")
ins_sop = next(s for s in sops if s.sec_cluster_value == "Insurance")
rb_links = {l["incident_id"] for l in KB_LINKS if l["article_id"] == rb_sop.article_id}
ins_links = {l["incident_id"] for l in KB_LINKS if l["article_id"] == ins_sop.article_id}
print(f"    Retail Banking article -> {sorted(rb_links)}")
print(f"    Insurance      article -> {sorted(ins_links)}")
check("Retail Banking SOP attached only to RB incidents",
      rb_links == {"INC6001", "INC6002"}, f"got {sorted(rb_links)}")
check("Insurance SOP attached only to the Insurance incident",
      ins_links == {"INC6007"}, f"got {sorted(ins_links)}")

banner("TEST 3 -- KB article body states the partition")
for a in KB_ARTICLES:
    first = a["content"].splitlines()[0]
    print(f"      {a['article_id']}: {first}")
check("each KB body carries a partition scope header",
      all("Partition scope" in a["content"] for a in KB_ARTICLES))
check("RB and Insurance bodies differ",
      KB_ARTICLES[0]["content"] != KB_ARTICLES[1]["content"])

banner("TEST 4 -- Promptflow input carries the partition scope")
for i in PF_INPUTS:
    sv = (i["scope"] or {}).get("sec_cluster_value")
    print(f"      cluster={i['cluster_name'][:44]!r:48} scope={sv!r}")
check("every Promptflow call received a scope payload",
      all(i["scope"] and i["scope"].get("scoped") for i in PF_INPUTS))
check("scope values match the partitions",
      {(i["scope"] or {}).get("sec_cluster_value") for i in PF_INPUTS}
      == {"Retail Banking", "Insurance"})

banner("TEST 5 -- arbitrary combo: host + env + service, env var only")
reset()
os.environ["SEC_CLUSTER_FIELD"] = "u_hostname,u_env,business_service"
t5 = [
    {"id": "a", "number": "INC7001", "u_hostname": "H1", "u_env": "PROD",
     "business_service": "Payments", "signature": "cert_expiry",
     "short_description": "TLS cert expired", "description": "d", "resolution_notes": "r"},
    {"id": "b", "number": "INC7002", "u_hostname": "H1", "u_env": "UAT",
     "business_service": "Payments", "signature": "cert_expiry",
     "short_description": "TLS cert expired", "description": "d", "resolution_notes": "r"},
    {"id": "c", "number": "INC7003", "u_hostname": "H1", "u_env": "PROD",
     "business_service": "Payments", "signature": "cert_expiry",
     "short_description": "TLS cert expired", "description": "d", "resolution_notes": "r"},
]
r5 = asyncio.run(svc.process_tickets([dict(t) for t in t5], **KW))
print(f"    partitions: {r5.get('scope', {}).get('partitions')}")
for s in STORE[SOP].values():
    print(f"    SOP value={s.sec_cluster_value!r}  title={s.title[:56]}")
sops5 = list(STORE[SOP].values())
check("2 partitions -> 2 SOPs (PROD and UAT split)", len(sops5) == 2, f"got {len(sops5)}")
check("scope-key type recorded as the 3-field composite",
      all(s.sec_cluster_field == "u_hostname,u_env,business_service" for s in sops5))
check("composite values recorded positionally",
      {s.sec_cluster_value for s in sops5} == {"H1,PROD,Payments", "H1,UAT,Payments"},
      f"got {{s.sec_cluster_value for s in sops5}}")
prod = next(s for s in sops5 if "PROD" in s.sec_cluster_value)
prod_links = {l["incident_id"] for l in KB_LINKS if l["article_id"] == prod.article_id}
check("PROD SOP attached to both PROD incidents, not the UAT one",
      prod_links == {"INC7001", "INC7003"}, f"got {sorted(prod_links)}")

banner("TEST 6 -- one partition's Promptflow failure does NOT block the others")
reset()
os.environ["SEC_CLUSTER_FIELD"] = "u_application_lob"
FAIL_PARTITIONS.add("Insurance")     # Insurance SOP generation will raise

t6 = [
    {"id": "x1", "number": "INC8001", "u_application_lob": "Retail Banking",
     "signature": "storage_timeout", "short_description": "disk timeout",
     "description": "d", "resolution_notes": "r"},
    {"id": "x2", "number": "INC8002", "u_application_lob": "Retail Banking",
     "signature": "storage_timeout", "short_description": "disk timeout",
     "description": "d", "resolution_notes": "r"},
    {"id": "x3", "number": "INC8007", "u_application_lob": "Insurance",
     "signature": "storage_timeout", "short_description": "disk timeout",
     "description": "d", "resolution_notes": "r"},
]
r6 = asyncio.run(svc.process_tickets([dict(t) for t in t6], **KW))
print(f"    status : {r6.get('status')}")
print(f"    SOPs   : {len(STORE[SOP])}")
print(f"    KB links: {[(l['article_id'], l['incident_id']) for l in KB_LINKS]}")

rb_attached = {l["incident_id"] for l in KB_LINKS}
check("the healthy Retail Banking partition still produced an SOP",
      any(s.sec_cluster_value == "Retail Banking" for s in STORE[SOP].values()))
check("Retail Banking incidents still got their KB attachment",
      {"INC8001", "INC8002"}.issubset(rb_attached), f"attached: {sorted(rb_attached)}")
check("the failed Insurance partition produced no SOP",
      not any(s.sec_cluster_value == "Insurance" for s in STORE[SOP].values()))
check("the run did not raise -- it returned a result",
      isinstance(r6, dict) and r6.get("status") in ("success", "partial"))
check("no Insurance incident was given another partition's SOP",
      "INC8007" not in rb_attached, f"attached: {sorted(rb_attached)}")

banner("TEST 7 -- unset SEC_CLUSTER_FIELD reverts to the unscoped path")
reset()
os.environ["SEC_CLUSTER_FIELD"] = ""
t7 = [
    {"id": "u1", "number": "INC9001", "u_application_lob": "Retail Banking",
     "signature": "storage_timeout", "short_description": "disk timeout",
     "description": "d", "resolution_notes": "r"},
    {"id": "u2", "number": "INC9002", "u_application_lob": "Insurance",
     "signature": "storage_timeout", "short_description": "disk timeout",
     "description": "d", "resolution_notes": "r"},
]
r7 = asyncio.run(svc.process_tickets([dict(t) for t in t7], **KW))
sops7 = list(STORE[SOP].values())
print(f"    status: {r7.get('status')}   SOPs: {len(sops7)}   scope block: {'scope' in r7}")
for s in sops7:
    print(f"    SOP field={s.sec_cluster_field!r} value={s.sec_cluster_value!r} title={s.title[:48]}")
check("unscoped mode merges both LOBs into one cluster/SOP", len(sops7) == 1,
      f"got {len(sops7)}")
check("unscoped SOP rows are left untagged (NULL scope)",
      all(s.sec_cluster_field is None and s.sec_cluster_value is None for s in sops7))
check("no 'scope' block in the unscoped response", "scope" not in r7)

# ===========================================================================
print()
print("=" * 74)
print(f"RESULT: {len(PASS)} passed, {len(FAIL)} failed")
print("=" * 74)
if FAIL:
    for f in FAIL:
        print(f"  FAILED: {f}")
    sys.exit(1)
print("Full pipeline verified: partition -> cluster -> SOP -> ServiceNow attach.")
