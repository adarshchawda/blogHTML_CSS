"""
Individual SOP generation step functions.
Prompts are loaded from prompts/*.jinja2 templates (source of truth).
"""
import json
import os
import re
import logging
from typing import List, Dict, Any

try:
    from src.core.llm_client import LLMClient
except ImportError:
    from ..core.llm_client import LLMClient  # type: ignore

logger = logging.getLogger(__name__)


def _load_prompt(name: str, **kwargs) -> str:
    """
    Load, render and return a PromptFlow-style jinja2 template from prompts/.
    Variables are substituted via simple {{var}} replacement.
    Raises FileNotFoundError if the template does not exist.
    """
    base = os.path.join(os.path.dirname(__file__), "..", "..", "prompts")
    path = os.path.join(base, f"{name}.jinja2")
    abs_path = os.path.abspath(path)
    logger.info(f"[PROMPT] Looking for: {abs_path}")
    if not os.path.exists(path):
        logger.error(f"[PROMPT] ❌ MISSING — {name}.jinja2 not found at {abs_path}")
        raise FileNotFoundError(f"Prompt template '{name}.jinja2' not found at {abs_path}")
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()
    # Render Jinja2 variables ({{var}} → value)
    for key, value in kwargs.items():
        raw = raw.replace("{{" + key + "}}", str(value))
    logger.info(f"[PROMPT] ✅ TEMPLATE loaded — {name}.jinja2")
    return raw


def _parse_prompt_messages(rendered: str) -> List[Dict[str, str]]:
    """
    Parse a PromptFlow-style jinja2 string into an OpenAI messages list.

    Expected format in .jinja2 file:
        system:
        <system content>

        user:
        <user content>
    """
    messages = []
    # Split on role headers (system: / user: / assistant:) that appear on their own line
    sections = re.split(r'\n?(system|user|assistant):\s*\n', rendered)
    i = 1
    while i < len(sections) - 1:
        role = sections[i].strip()
        content = sections[i + 1].strip()
        if content:
            messages.append({"role": role, "content": content})
        i += 2
    return messages


def issue_analyzer(tickets: List[Dict[str, Any]], llm_client: LLMClient) -> str:
    """
    Analyze tickets — loads prompts/issue_analyzer.jinja2.
    """
    rendered = _load_prompt("issue_analyzer", tickets=json.dumps(tickets, indent=2))
    messages = _parse_prompt_messages(rendered)
    return llm_client.complete(messages).content


def resolution_analyzer(issue_analysis: str, llm_client: LLMClient) -> str:
    """
    Generate resolution steps — loads prompts/resolution_analyzer.jinja2.
    """
    rendered = _load_prompt("resolution_analyzer", issue_analysis=issue_analysis)
    messages = _parse_prompt_messages(rendered)
    return llm_client.complete(messages).content


def sop_writer(issue_analysis: str, resolution_steps: str, llm_client: LLMClient) -> str:
    """
    Write final SOP — loads prompts/sop_writer.jinja2.
    NO cluster_name parameter — matches original flow.dag.yaml.
    """
    rendered = _load_prompt(
        "sop_writer",
        issue_analysis=issue_analysis,
        resolution_steps=resolution_steps,
    )
    messages = _parse_prompt_messages(rendered)
    return llm_client.complete(messages).content
