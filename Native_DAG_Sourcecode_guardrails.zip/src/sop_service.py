"""
SOP Service - Business logic for SOP generation and ticket processing
"""
import os
import json
import uuid
import logging
import asyncio
from sqlalchemy.exc import IntegrityError
from sqlalchemy.sql.expression import insert
from datetime import datetime, timezone
try:
    from sop_models import db, SOP, Cluster, Ticket, cluster_ticket_mapping, db_session, SessionLocal
except ImportError:
    from .sop_models import db, SOP, Cluster, Ticket, cluster_ticket_mapping, db_session, SessionLocal
from .utils.llm_config import LLMConfigManager
from .clustering.clustering_manager import get_clustering_manager
from .utils.servicenow_kb_client import create_kb_article, link_kb_article as sn_link_kb_article
# Get logger
logger = logging.getLogger(__name__)


# Constants
KEY_NOT_SET = 'Not set'
KEY_SET_HIDDEN = 'Set (hidden)'
env_inilitialized = False

def _load_environment():
    """Load environment variables from Key Vault if not already loaded."""
    try:
        from load_env import load_env_from_keyvault
    except ImportError:
        from .load_env import load_env_from_keyvault

    global env_inilitialized

    if not env_inilitialized:
        load_env_from_keyvault()
        env_inilitialized = True


def _is_validator_enabled():
    """Return True if config.json enables the SOP validator."""
    try:
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
        with open(config_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        return bool(cfg.get('is_validator_enabled', False))
    except Exception:
        # If config cannot be read, default to False to avoid unexpected validator runs
        return False


def _serialize_embeddings(embeddings):
    """Serialize embeddings to JSON string"""
    if embeddings is None:
        return None
    try:
        # Convert numpy arrays to plain lists
        if hasattr(embeddings, 'tolist'):
            emb_list = embeddings.tolist()
        elif isinstance(embeddings, (list, tuple)):
            emb_list = embeddings
        else:
            # Fallback: try to iterate and convert
            emb_list = list(embeddings)
        if len(emb_list) == 0:
            return None
        return json.dumps(emb_list)
    except Exception as e:
        logger.warning("Could not serialize embeddings: %s", str(e))
        return None

def _insert_ticket_mappings(session, ticket_ids, cluster_id):
    """Insert ticket-cluster mappings into database"""
    from sqlalchemy.dialects.postgresql import insert as pg_insert

    mapped = 0
    for ticket_id in ticket_ids:
        if not ticket_id:
            continue
        try:
            ticket = session.query(Ticket).filter_by(id=ticket_id).first()
            if not ticket:
                ticket = session.query(Ticket).filter_by(external_id=ticket_id).first()

            if not ticket:
                logger.warning("Ticket %s not found in database, skipping mapping", ticket_id)
                continue

            # Use ON CONFLICT DO NOTHING so duplicates are silently skipped
            # without rolling back the enclosing transaction/session state.
            stmt = pg_insert(cluster_ticket_mapping).values(
                cluster_id=cluster_id, ticket_id=ticket.id
            ).on_conflict_do_nothing()
            result = session.execute(stmt)
            if result.rowcount:
                mapped += 1
            else:
                logger.warning("Duplicate mapping for ticket %s in cluster %s", ticket_id, cluster_id)
        except Exception as e:
            logger.error("Error creating mapping for ticket %s: %s", ticket_id, str(e))
    return mapped

async def _create_cluster_with_sop(group_tickets, cluster_id, cluster_name, ticket_ids, embeddings, **kwargs):
    """Helper method to create a cluster with SOP and add it to the database
    
    Args:
        group_tickets (list): List of tickets in this cluster
        cluster_id (str): Unique ID for the cluster
        cluster_name (str): Name for the cluster
        ticket_ids (list): List of ticket IDs in this cluster
        embeddings (list): Embedding vector for the cluster centroid
        
    Returns:
        tuple: (sop_id, sop_path, cluster)
    """
    sop_id = None
    sop_path = None

    logger.info("Creating cluster %s with name '%s' with %d tickets", cluster_id, cluster_name, len(ticket_ids))

    try:
        sop = await generate_sop(
            tickets=group_tickets,
            cluster_name=cluster_name,
            clustering_analysis={},  # Default empty analysis
            ticket_ids=ticket_ids,
            **kwargs
        )
        if sop and 'sop_id' in sop:
            sop_id = sop['sop_id']
            sop_path = sop['filepath']
            logger.info("Generated SOP with ID %s", sop_id)
    except Exception as e:
        logger.error("Error generating SOP: %s", str(e), exc_info=True)

    # Convert embeddings to plain list (pgvector expects numeric sequence)
    emb_value = None
    if embeddings is not None:
        try:
            if hasattr(embeddings, 'tolist'):
                emb_value = embeddings.tolist()
            elif isinstance(embeddings, str):
                # Try to parse JSON string
                try:
                    parsed = json.loads(embeddings)
                    emb_value = list(parsed) if parsed is not None else None
                except Exception:
                    emb_value = None
            else:
                emb_value = list(embeddings)
        except Exception:
            emb_value = None

    # Use a raw SessionLocal() session (not the scoped db_session) so that
    # generate_sop()'s own commits on the scoped session don't interfere.
    session = SessionLocal()
    try:
        # If cluster id already exists, reuse it to avoid unique constraint errors
        existing = session.query(Cluster).filter_by(id=cluster_id).first()
        if existing:
            logger.warning("Cluster id %s already exists. Reusing existing cluster record.", cluster_id)
            new_cluster = existing
            if not existing.description:
                existing.description = f"Creating cluster for {len(ticket_ids)} tickets"
                session.flush()
            # Use a direct SQL UPDATE to guarantee sop_id is written to DB,
            # bypassing any ORM session-state/caching issues.
            if sop_id and not existing.sop_id:
                from sqlalchemy import text as _text
                session.execute(
                    _text("UPDATE clusters SET sop_id = :sop_id WHERE id = :cluster_id AND sop_id IS NULL"),
                    {"sop_id": sop_id, "cluster_id": cluster_id}
                )
                session.flush()
                logger.info("Updated sop_id %s on existing cluster %s", sop_id, cluster_id)
        else:
            new_cluster = Cluster(
                id=cluster_id,
                name=cluster_name,
                description=f"Cluster with {len(ticket_ids)} tickets",
                is_test_cluster=False,
                sop_id=sop_id,
                embedding=emb_value
            )
            session.add(new_cluster)
            session.flush()  # Flush to get the ID without committing

        # Insert mappings using extracted helper
        _insert_ticket_mappings(session, ticket_ids, cluster_id)

        # Commit the transaction
        session.commit()
        logger.info("Successfully created cluster %s with %d ticket mappings", cluster_id, len(ticket_ids))

        # Eagerly load any relationships that might be needed later
        if hasattr(new_cluster, 'tickets'):
            _ = new_cluster.tickets  # This will load the tickets into the session

        # Detach the object from the session but keep the loaded attributes
        session.expunge(new_cluster)

        return sop_id, sop_path, new_cluster

    except Exception as e:
        # Rollback in case of error
        session.rollback()
        logger.error("Error creating cluster or mappings: %s", str(e))
        raise
    finally:
        # Close the session
        session.close()


def _save_tickets_to_db(session, tickets):
    """Save ticket data to database."""
    db_tickets = []
    for ticket_data in tickets:
        ticket = Ticket(
            id=str(uuid.uuid4()),
            external_id=ticket_data.get('number'),
            title=ticket_data.get('short_description', ''),
            short_description=ticket_data.get('short_description', ''),
            description=ticket_data.get('description', ''),
            status=ticket_data.get('state', 'New'),
            priority=ticket_data.get('priority', 'Medium'),
            category=ticket_data.get('category'),
            subcategory=ticket_data.get('subcategory'),
            assigned_to=ticket_data.get('assigned_to', ''),
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            additional_data=json.dumps(ticket_data)
        )
        session.add(ticket)
        db_tickets.append(ticket)
    session.commit()
    return db_tickets


def _normalize_clustering_results(cluster_result):
    """Convert matched/new clusters into unified ticket_groups format."""
    ticket_groups_list = []
    
    # Add matched clusters
    for cluster_id, match_info in cluster_result.get('matched_clusters', {}).items():
        cluster = match_info.get('cluster', {})
        actual_id = (
            cluster_id
            or cluster.get('id')
            or match_info.get('cluster_id')
            or match_info.get('id')
        )
        if not actual_id:
            logger.warning("Skipping matched cluster with no resolvable ID: %s", list(match_info.keys()))
            continue
        ticket_groups_list.append({
            'id': actual_id,
            'name': cluster.get('name', f"Cluster {actual_id}"),
            'tickets': match_info.get('tickets', []),
            'embeddings': cluster.get('centroid', ''),
            'is_matched': True,
            'similarity_score': match_info.get('similarity', 0)
        })
    
    # Add new clusters
    for cluster in cluster_result.get('new_clusters', []):
        original_id = cluster.get('id')
        ticket_groups_list.append({
            'id': original_id,
            'name': cluster.get('name', "New Cluster"),
            'tickets': cluster.get('tickets', []),
            'embeddings': cluster.get('centroid', ''),
            'is_matched': False,
            'similarity_score': 0.0,
            'original_id': original_id
        })
    
    logger.info("Normalized %d cluster groups", len(ticket_groups_list))
    return ticket_groups_list


def _separate_cluster_groups(ticket_groups_list):
    """Separate groups into new and matched lists."""
    new_groups = []
    matched_groups = []
    for group in ticket_groups_list:
        if isinstance(group, dict) and group.get('tickets'):
            if group.get('is_matched'):
                matched_groups.append(group)
            else:
                new_groups.append(group)
    logger.info("Separated into %d new and %d matched groups", len(new_groups), len(matched_groups))
    return new_groups, matched_groups


def _extract_ticket_ids_from_group(group):
    """Extract ticket IDs from a group."""
    group_tickets = group.get('tickets', [])
    return [t.get('ticket_id') or t.get('number') for t in group_tickets if isinstance(t, dict)]

async def _process_new_cluster_group(group, matched_cluster_groups, session, results, processed_ticket_ids, kwargs):
    """Process a new cluster group: create SOP and DB record."""
    ticket_ids = _extract_ticket_ids_from_group(group)
    original_id = group.get('id')
    
    matched_group = next((mg for mg in matched_cluster_groups if mg.get('id') == original_id), None)
    if matched_group:
        matched_ids = _extract_ticket_ids_from_group(matched_group)
        ticket_ids = list(set(ticket_ids + matched_ids))
    
    cluster_id = group.get('id') or str(uuid.uuid4())
    cluster_name = group.get('name', f"Cluster {cluster_id[:6]}")
    embeddings = group.get('embeddings')
    group_tickets = group.get('tickets', [])
    
    logger.info("Creating new cluster %s with %d tickets", cluster_id, len(ticket_ids))
    
    try:
        sop_id, sop_path, new_cluster = await _create_cluster_with_sop(
            group_tickets, cluster_id, cluster_name, ticket_ids, embeddings, **kwargs
        )
        
        if new_cluster:
            try:
                for ticket_id in ticket_ids:
                    db_ticket = session.query(Ticket).filter_by(external_id=ticket_id).first()
                    if db_ticket:
                        results.append({
                            'ticket_id': db_ticket.external_id,
                            'ticket_summary': db_ticket.title,
                            'cluster_id': cluster_id,
                            'cluster_name': cluster_name,
                            'sop_document_path': sop_path,
                            'status': 'Created',
                            'sop_id': sop_id,
                            'matched_to_existing_sop': False,
                            'similarity_score': 0.0,
                            'original_id': original_id
                        })
                        new_cluster.tickets.append(db_ticket)
                        processed_ticket_ids.add(db_ticket.external_id)
                session.commit()
            except Exception as e:
                session.rollback()
                logger.error("Error processing tickets in new cluster: %s", str(e))
                raise
            return cluster_id, new_cluster
    except Exception as e:
        logger.error("Error creating new cluster: %s", str(e))
        raise
    
    return None, None

async def _process_matched_cluster_group(group, results, processed_ticket_ids, kwargs):

    """Process a matched cluster group: link to existing cluster."""

    ticket_ids = _extract_ticket_ids_from_group(group)

    matched_cluster_id = group.get('id')

    similarity_score = group.get('similarity_score', 0.0)
    # Coerce similarity_score to a single float for logging and result output
    try:
        if isinstance(similarity_score, (list, tuple)):
            sim_val = float(sum(similarity_score) / len(similarity_score)) if len(similarity_score) > 0 else 0.0
        else:
            sim_val = float(similarity_score)
    except Exception:
        try:
            import numpy as _np
            sim_val = float(_np.mean(similarity_score))
        except Exception:
            sim_val = 0.0

    logger.info("Processing matched cluster %s with similarity %.2f", matched_cluster_id, sim_val)

    # Use a fresh session instance from the PGSession wrapper so we can

    # persist mappings and update SOP records as needed.

    session = db_session()

    try:

        existing_cluster = session.query(Cluster).filter_by(id=matched_cluster_id).first()

        if not existing_cluster:

            logger.warning("Matched cluster %s not found", matched_cluster_id)

            return

        # Force SQLAlchemy to reload this object from DB — the scoped session
        # identity map may hold a stale version (sop_id=None) from a prior request.
        session.refresh(existing_cluster)
 
        remaining_ticket_ids = [tid for tid in ticket_ids if tid not in processed_ticket_ids]

        if not remaining_ticket_ids:

            logger.info("All tickets for matched cluster %s already processed", matched_cluster_id)

            return
 
        cluster_id = existing_cluster.id

        cluster_name = existing_cluster.name

        sop_id = existing_cluster.sop_id

        sop_path = None

        # If there's a linked SOP, ensure we have an article_id before attempting to link.

        article_id = None

        if sop_id:

            sop = session.query(SOP).filter_by(id=sop_id).first()

            if sop:

                sop_path = getattr(sop, 'document_path', None)

                article_id = getattr(sop, 'article_id', None)
 
                # If ServiceNow integration is enabled and we don't have an article id,

                # attempt to create one and persist it to the SOP record.

                if not article_id and kwargs.get('servicenow_integration', False):

                    try:

                        try:

                            from utils.servicenow_kb_client import create_kb_article

                        except ImportError:

                            from .utils.servicenow_kb_client import create_kb_article
 
                        title = getattr(sop, 'title', f"SOP for {cluster_name}")

                        # Ensure we have SOP content available for validation; if the DB
                        # record doesn't contain the text, attempt to load from the
                        # `document_path` file using the helper.
                        sop_content = _retrieve_sop_content(sop)

                        # Run SOP validator and include its output in the ServiceNow KB request
                        validator_result = None
                        if _is_validator_enabled():
                            try:
                                try:
                                    from validator import SOPValidator
                                except ImportError:
                                    from .validator import SOPValidator

                                validator = SOPValidator()
                                validator_result =  await validator.validate_sop_async(sop_content)
                            except Exception as val_err:
                                logger.error("SOP validator error: %s", str(val_err))
                                validator_result = {"error": str(val_err)}

                        kb_result = create_kb_article(title=title, content=sop_content, validator_output=validator_result)

                        if kb_result.get('status') == 'success' and kb_result.get('article_id'):

                            article_id = kb_result.get('article_id')

                            sop.article_id = article_id

                            session.commit()

                            logger.info("Created ServiceNow KB article %s for SOP %s", article_id, sop_id)

                        else:

                            logger.error("Failed to create KB article for SOP %s: %s", sop_id, kb_result)

                    except Exception as kb_err:

                        logger.error("Error creating KB article for SOP %s: %s", sop_id, str(kb_err))
 
                # Only link if we have a valid article_id

                if article_id:

                    # Always retrieve SOP content first
                    content = _retrieve_sop_content(sop)
                    validator_output = None
                    if _is_validator_enabled():
                        try:
                            try:
                                from validator import SOPValidator
                            except ImportError:
                                from .validator import SOPValidator

                            validator = SOPValidator()
                            validator_output = await validator.validate_sop_async(content)

                        except Exception as val_err:
                            logger.error("Validator error during matched cluster linking: %s", str(val_err))
                            validator_output = {"error": str(val_err)}

                    link_kb_article(
                        article_id,
                        remaining_ticket_ids,
                        validator_output=validator_output,
                        **kwargs
                    )
 
        # Persist ticket<->cluster mappings to DB (idempotent)

        mapped = _insert_ticket_mappings(session, remaining_ticket_ids, cluster_id)

        logger.info("Inserted %d mappings for cluster %s", mapped, cluster_id)
 
        # Build result entries for each mapped ticket

        for ticket_id in remaining_ticket_ids:

            db_ticket = session.query(Ticket).filter_by(external_id=ticket_id).first()

            if db_ticket:

                try:

                    if db_ticket not in getattr(existing_cluster, 'tickets', []):

                        existing_cluster.tickets.append(db_ticket)

                except Exception:

                    # Non-fatal: keep going even if in-memory relationship can't be mutated

                    pass
 
                results.append({

                    'ticket_id': db_ticket.external_id,

                    'ticket_summary': db_ticket.title,

                    'cluster_id': cluster_id,

                    'cluster_name': cluster_name,

                    'sop_document_path': sop_path,

                    'status': 'Mapped',

                    'sop_id': sop_id,

                    'matched_to_existing_sop': True,

                    'similarity_score': sim_val

                })

                processed_ticket_ids.add(db_ticket.external_id)
 
        session.commit()

    except Exception as e:

        try:

            session.rollback()

        except Exception:

            pass

        logger.error("Error processing matched cluster %s: %s", matched_cluster_id, str(e), exc_info=True)

        raise

    finally:

        try:

            session.close()

        except Exception:

            pass

async def process_tickets(tickets, **kwargs):
    """Common function to process tickets for clustering and SOP generation.
    
    Refactored with helpers to reduce cognitive complexity.
    """
    
    session = db_session()
    
    try:
        
        # Step 1: Configure clustering manager
        clustering_manager = get_clustering_manager()

        # Step 2: Check for existing tickets
        ticket_count = session.query(Ticket).count()
        if ticket_count == 0:
            if len(tickets) < 2:
                warning_msg = "For Agglomerative Clustering, minimum 2 tickets are required to process."
                logger.warning(warning_msg)
                return {
                    "error": warning_msg,
                    "analysis": {"total_tickets": len(tickets), "matched_to_existing_clusters": 0, "new_clusters_created": 0, "incremental": False},
                    "matched_clusters": {},
                    "new_clusters": [],
                    "warnings": [warning_msg]
                }
            
            logger.info("No records found in tickets table. Saving incoming tickets.")
            db_tickets = _save_tickets_to_db(session, tickets)
            # for ticket in tickets:
            #     service_now_connector.update_record(ticket['number'])
            logger.info("Saved %d tickets to database", len(db_tickets))
            # Call create_initial_clusters (implementing AgglomerativeClustering)
            cluster_result = clustering_manager.create_initial_clusters(tickets)
            
        else:
            logger.info(" Appending new records to tickets table")
            db_tickets = _save_tickets_to_db(session, tickets)
            # for ticket in tickets:
            #     service_now_connector.update_record(ticket['number'])
            logger.info("Saved %d tickets to database", len(db_tickets))
            logger.info("Creating clusters using incremental approach")
            cluster_result = clustering_manager.process_tickets_with_existing_clusters(tickets)

        if not cluster_result or ('matched_clusters' not in cluster_result and 'new_clusters' not in cluster_result):
            return {'status': 'success', 'message': 'No clusters were found.', 'results': []}, 200
        
        # Step 3: Normalize clustering results
        ticket_groups_list = _normalize_clustering_results(cluster_result)

        # Step 4: Separate into new and matched
        new_groups, matched_groups = _separate_cluster_groups(ticket_groups_list)
        
        # Step 5: Process groups
        results = []
        processed_ticket_ids = set()
        
        logger.info("Processing %d new cluster groups", len(new_groups))
        for group in new_groups:
            await _process_new_cluster_group(group, matched_groups, session, results, processed_ticket_ids, kwargs)
        
        logger.info("Processing %d matched cluster groups", len(matched_groups))
        for group in matched_groups:
            await _process_matched_cluster_group(group, results, processed_ticket_ids, kwargs)

        session.close()
        
        # Step 6 Return results
        unique_cluster_ids = len({r['cluster_id'] for r in results if 'cluster_id' in r})
        return {
            'status': 'success',
            'message': f'Processed {len(tickets)} tickets into {unique_cluster_ids} clusters',
            'results': results
        }
        
    except ValueError as ve:
        logger.error("Configuration error: %s", str(ve))
        return {'status': 'error', 'message': str(ve)}, 400
    except ConnectionError as ce:
        logger.error("MCP server connection error: %s", str(ce))
        return {'status': 'error', 'message': 'MCP server is not running or not accessible. Please start the MCP server.', 'results': []}, 503
    except Exception as e:
        logger.error("Error processing tickets: %s", str(e), exc_info=True)
        if 'session' in locals():
            session.rollback()
            session.close()
        return {'status': 'error', 'message': f'Error: {str(e)}', 'results': []}, 500


def link_kb_article(article_id, ticket_ids=None, validator_output=None, **kwargs):
    """link KB Article in service Now"""
    servicenow_integration = kwargs.get('servicenow_integration', False)
    if servicenow_integration:
        try:
            try:
                from utils.servicenow_kb_client import (
                    link_kb_article as sn_link_kb_article,
                    update_sop_gen_status,
                    SOP_STATUS_COMPLETED,
                )
            except ImportError:
                from .utils.servicenow_kb_client import (
                    link_kb_article as sn_link_kb_article,
                    update_sop_gen_status,
                    SOP_STATUS_COMPLETED,
                )
            # Normalize to a list of incident IDs
            ids = []
            if isinstance(ticket_ids, list):
                ids = [tid for tid in ticket_ids if tid]
            elif isinstance(ticket_ids, str) and ticket_ids:
                ids = [ticket_ids]
            # Link for each incident individually
            for inc_id in ids:
                kb_result = sn_link_kb_article(
                    article_id=article_id,
                    incident_id=inc_id,
                    validator_output=validator_output
                )
                if kb_result.get('status') == 'success':
                    logger.info(f"Linked ServiceNow KB article {article_id} to incident {inc_id}")
                    # Matched/existing-SOP path: the KB article is now attached to this
                    # incident, so its SOP is done => mark Completed (3). This is the
                    # counterpart of _link_and_complete() on the newly-created-SOP path,
                    # and it also mirrors the transition into the sop_ticket_status table.
                    update_sop_gen_status(inc_id, SOP_STATUS_COMPLETED)
                else:
                    logger.error(f"Failed to link KB article {article_id} to incident {inc_id}: {kb_result}")

        except Exception as kb_error:
            logger.error(f"Error creating ServiceNow KB article: {str(kb_error)}")
            # Don't fail the SOP generation if KB article creation fails


def _validate_sop_input(tickets):
    """Validate SOP generation input."""
    if not tickets:
        raise ValueError("No tickets provided for SOP generation")
    logger.info("Ticket Info for SOP generation: %d tickets", len(tickets))


def _get_llm_config_for_sop(kwargs):
    """Retrieve and validate LLM configuration for SOP."""
    try:
        from utils.llm_config import LLMConfigManager
    except ImportError:
        from .utils.llm_config import LLMConfigManager
    llm_config = LLMConfigManager.get_config(kwargs)
    provider = llm_config['llm_provider']
    api_key = llm_config['api_key']
    
    if not api_key:
        raise ValueError(f'No API key available for {provider}. Please provide an API key in the LLM settings UI.')
    
    safe_config = {k: v for k, v in llm_config.items() if k != 'api_key'}
    safe_config['api_key'] = KEY_SET_HIDDEN if api_key else KEY_NOT_SET
    logger.info("LLM Configuration: %s", safe_config)
    return llm_config


async def _generate_sop_with_promptflow(promptflow_manager, tickets, cluster_name):
    """Generate SOP content using the Promptflow manager."""
    try:
        if asyncio.iscoroutinefunction(promptflow_manager._generate_sop_async):
            return await promptflow_manager._generate_sop_async(tickets, cluster_name)
        else:
            return promptflow_manager._generate_sop_async(tickets, cluster_name)
    except RuntimeError as e:
        if "asyncio.run() cannot be called from a running event loop" in str(e):
            logger.info("Nested event loop detected, using asyncio.create_task")
            loop = asyncio.get_running_loop()
            task = loop.create_task(promptflow_manager._generate_sop_async(tickets, cluster_name))
            return await asyncio.wait_for(task, timeout=300)
        raise RuntimeError(f"Error generating SOP with Promptflow manager: {str(e)}") from e
    except Exception as e:
        raise RuntimeError(f"Unexpected error generating SOP: {str(e)}") from e


def _save_sop_file(sop_id, sop_content):
    """Save SOP content to file and return filepath."""
    sop_filepath = f"sops/{sop_id}.md"
    os.makedirs(os.path.dirname(sop_filepath), exist_ok=True)
    with open(sop_filepath, 'w', encoding='utf-8') as f:
        f.write(sop_content)
    return sop_filepath


def _persist_sop_to_db(sop_id, sop_title, sop_content, sop_filepath):
    """Create and persist SOP record to database."""
    sop_db = SOP(
        id=sop_id,
        title=sop_title,
        content=sop_content,
        document_path=sop_filepath,
        created_at=datetime.now()
    )
    db_session.add(sop_db)
    db_session.flush()
    return sop_db


def _retrieve_sop_content(sop):
    """Return SOP content from DB record or load from `document_path` file if content is empty.

    This ensures validator has the SOP text even when `SOP.content` was not stored in DB.
    """
    if not sop:
        return ''

    # Prefer stored content if present
    content = getattr(sop, 'content', '') or ''
    if content and content.strip():
        return content

    # Try loading from document_path
    doc_path = getattr(sop, 'document_path', None)
    if not doc_path:
        return content

    try:
        # If relative path, try common locations: repo root and file-relative
        candidates = []
        if os.path.isabs(doc_path):
            candidates.append(doc_path)
        else:
            # file-relative (src/..)
            base = os.path.dirname(__file__)
            candidates.append(os.path.normpath(os.path.join(base, '..', doc_path)))
            # cwd (likely repo root)
            candidates.append(os.path.normpath(os.path.join(os.getcwd(), doc_path)))

        for p in candidates:
            if p and os.path.exists(p):
                try:
                    with open(p, 'r', encoding='utf-8') as f:
                        text = f.read()
                        if text and text.strip():
                            return text
                except Exception as e:
                    logger.warning("Failed to read SOP file %s: %s", p, str(e))
    except Exception as e:
        logger.warning("Error retrieving SOP content for SOP %s: %s", getattr(sop, 'id', 'unknown'), str(e))

    return content


async def _integrate_with_servicenow_kb(sop_db, sop_title, sop_content, ticket_ids, kwargs):
    """Create KB article and link to ServiceNow if integration enabled."""
    if not kwargs.get('servicenow_integration', False):
        return
    
    try:
        try:
            from utils.servicenow_kb_client import create_kb_article, link_kb_article as sn_link_kb_article
        except ImportError:
            from .utils.servicenow_kb_client import create_kb_article, link_kb_article as sn_link_kb_article

        # Run validator and attach output to ServiceNow KB article as `u_validator_output`
        validator_result = None
        if _is_validator_enabled():
            try:
                try:
                    from validator import SOPValidator
                except ImportError:
                    from .validator import SOPValidator

                validator = SOPValidator()
                validator_result = await validator.validate_sop_async(sop_content)
            except Exception as val_err:
                logger.error("SOP validator error: %s", str(val_err))
                validator_result = {"error": str(val_err)}

        # Call blocking HTTP client in thread executor to avoid blocking event loop
        kb_result = await asyncio.to_thread(
            create_kb_article,
            sop_title,
            sop_content,
            None,
            validator_result
        )

        if kb_result.get('status') == 'success' and kb_result.get('article_id'):
            article_id = kb_result.get('article_id')
            logger.info("Created ServiceNow KB article with ID: %s", article_id)
            # Re-query the SOP record in a fresh state to ensure the update is
            # tracked by the session (the object may be expired after the prior commit).
            sop_to_update = db_session.query(SOP).filter_by(id=sop_db.id).first()
            if sop_to_update:
                sop_to_update.article_id = article_id
                db_session.add(sop_to_update)
            else:
                sop_db.article_id = article_id
                db_session.add(sop_db)
            db_session.commit()
            logger.info("Persisted article_id %s to SOP %s in DB", article_id, sop_db.id)
            
            if ticket_ids:
                try:
                    from utils.servicenow_kb_client import update_sop_gen_status, SOP_STATUS_COMPLETED
                except ImportError:
                    from .utils.servicenow_kb_client import update_sop_gen_status, SOP_STATUS_COMPLETED

                async def _link_and_complete(inc_id):
                    """Link the KB article to one incident, then mark it Completed (3).

                    Completed is set ONLY after the link succeeds - this is the DB/flow
                    truth that the incident now has a SOP attached. Each incident runs in
                    its own thread, so linking + completion fan out in parallel.
                    """
                    try:
                        await asyncio.to_thread(
                            sn_link_kb_article,
                            article_id=article_id,
                            incident_id=inc_id,
                            validator_output=validator_result
                        )
                        logger.info("Linked KB article %s to incident %s", article_id, inc_id)
                        # KB attached => this incident's SOP is done => Completed (3).
                        await asyncio.to_thread(
                            update_sop_gen_status, inc_id, SOP_STATUS_COMPLETED
                        )
                    except Exception as link_err:
                        logger.error("Failed to link KB article %s to incident %s: %s", article_id, inc_id, str(link_err))

                # Fan out all incidents for this cluster concurrently.
                await asyncio.gather(*[_link_and_complete(inc) for inc in ticket_ids])
        else:
            logger.error("Failed to create ServiceNow KB article: %s", kb_result)
    except Exception as kb_error:
        logger.error("Error creating/linking ServiceNow KB article: %s", str(kb_error))


async def generate_sop(tickets, cluster_name='Unnamed Cluster', ticket_ids=None, **kwargs):
    """Generate a Standard Operating Procedure (SOP) for a cluster of tickets.
    
    Refactored to reduce cognitive complexity by delegating to focused helper functions.
    """
    try:
        # Step 1: Validate input
        _validate_sop_input(tickets)

        # Step 2: Build native flow engine — replaces PromptflowManager + subprocess
        try:
            from src.flows.sop_flow import build_sop_flow
            from src.core.llm_client import create_llm_client_from_env
        except ImportError:
            from .flows.sop_flow import build_sop_flow
            from .core.llm_client import create_llm_client_from_env

        llm_client = create_llm_client_from_env()
        flow       = build_sop_flow()
        logger.info("Native flow engine ready — deployment: %s", llm_client.config.deployment)

        # Step 3: Generate SOP content via native asyncio DAG (8-22 seconds vs 10 min)
        cluster_id = str(uuid.uuid4())
        logger.info("Starting SOP generation for cluster '%s' with %d tickets", cluster_name, len(tickets))

        # --- GUARDRAIL: Masking Gate -------------------------------------------------
        # Mask sensitive data BEFORE tickets reach the SOP-writing DAG (Azure OpenAI).
        # cluster_id is the request_id that ties this ticket-set's mappings together.
        # Because the 3 DAG steps chain their output, masking once here covers all of
        # them plus the validator — a placeholder simply rides through.
        from src.guardrails.masking_service import MaskingService
        _masker = MaskingService()
        masked_tickets = _masker.mask_tickets(tickets, request_id=cluster_id)
        # ----------------------------------------------------------------------------

        flow_result = await flow.run_async({
            "tickets":      masked_tickets,   # GUARDRAIL: was `tickets`
            "cluster_name": cluster_name,
            "llm_client":   llm_client,
        })
        sop_content = flow_result.outputs.get("sop_writer", "")

        # --- GUARDRAIL: Remap Gate ---------------------------------------------------
        # Restore real values into the finished SOP AFTER the DAG (and validator, which
        # therefore only ever sees masked text) and BEFORE the SOP is saved, persisted,
        # or pushed to ServiceNow — i.e. before the KB-link moment, so the SOP attached
        # to the KB (and the point at which u_sop_gen_status becomes Completed) carries
        # the real values. Redacted secrets stay [REDACTED] (never stored, never back).
        try:
            sop_content = _masker.remap_text(sop_content, request_id=cluster_id)
        except Exception:
            logger.exception("Remap failed; SOP left with placeholders for safety")
        # ----------------------------------------------------------------------------
        
        # Step 4: Generate metadata
        sop_id = str(uuid.uuid4())
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sop_title = f"SOP for {cluster_name} - {timestamp}"
        
        # Step 5: Save to file
        sop_filepath = _save_sop_file(sop_id, sop_content)
        
        # Step 6: Persist to database
        sop_db = _persist_sop_to_db(sop_id, sop_title, sop_content, sop_filepath)
        db_session.commit()
        
        # Step 7: Integrate with ServiceNow KB if configured
        await _integrate_with_servicenow_kb(sop_db, sop_title, sop_content, ticket_ids, kwargs)
        
        logger.info("SOP generated and saved with ID: %s", sop_id)
        return {
            'sop_id': sop_id,
            'sop_title': sop_title,
            'sop_content': sop_content,
            'cluster_id': cluster_id,
            'filepath': sop_filepath
        }
        
    except ValueError as e:
        logger.error("Validation error in SOP generation: %s", str(e))
        raise
    except RuntimeError as e:
        logger.error("Runtime error in SOP generation: %s", str(e))
        raise
    except Exception as e:
        error_message = f"Unexpected error generating SOP: {str(e)}"
        logger.error(error_message, exc_info=True)
        try:
            db_session.rollback()
        except Exception as rollback_err:
            logger.error("Error during rollback: %s", str(rollback_err))
        raise RuntimeError(error_message) from e

def _extract_root_cause_text(field):
    """Extract string text from root cause field (handle dict or string)."""
    if field is None:
        return ''
    
    if isinstance(field, dict):
        try:
            return field.get('display_value', '') or field.get('value', '') or str(field)
        except Exception as e:
            logger.warning("Error extracting root cause text from dict: %s", str(e))
            return str(field)
    
    return str(field) if field else ''


def _filter_records_with_rca(records, min_length=10):
    """Filter records to include only those with meaningful RCA data."""
    filtered = []
    for record in records:
        root_cause = _extract_root_cause_text(record.get('u_root_cause') or record.get('root_cause'))
        if root_cause and len(root_cause.strip()) >= min_length:
            filtered.append(record)
    
    logger.info("Found %d records with RCA data out of %d total", len(filtered), len(records))
    return filtered


