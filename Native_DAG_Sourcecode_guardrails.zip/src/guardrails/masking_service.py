# src/guardrails/masking_service.py
# SOURCE: AWS (adapted) — from pii_masking_service_postgres.py
import re
import logging
from typing import List, Dict, Tuple

from src.guardrails.config import default_config
from src.guardrails.detector import PIIDetector
from src.guardrails.mapping_repository import PIIMappingRepository

logger = logging.getLogger(__name__)

# Ticket fields that get masked before reaching Azure OpenAI
MASKABLE_FIELDS = ["short_description", "description", "work_notes",
                   "comments", "close_notes", "resolution_notes"]


class MaskingService:
    def __init__(self):
        self.detector = PIIDetector()
        self.repo = PIIMappingRepository()
        self.cfg = default_config

    # ---------------- Masking Gate ----------------
    def mask_text(self, text: str, request_id: str) -> Tuple[str, List[Dict]]:
        """Return (masked_text, mappings). Redacted entities are NOT in mappings."""
        if not self.cfg.masking_enabled or not text:
            return text, []
        try:
            entities = self.detector.detect(text)
        except Exception:
            # Fail-closed for the LLM call: if detection breaks, do not emit
            # unmasked text. Caller decides how to handle an empty/blocked result.
            logger.exception("Detection failed for request %s", request_id)
            raise

        mappings, counters = [], {}
        # Replace from the end backwards so offsets stay valid
        for ent in sorted(entities, key=lambda e: e.start, reverse=True):
            etype = ent.entity_type
            # SSN typed in phone shape -> treat as SSN (destroy), same as AWS
            if etype == "PHONE_NUMBER" and re.fullmatch(r"\d{3}-\d{2}-\d{4}", ent.text):
                etype = "US_SSN"

            if etype in self.cfg.masking.redact_entities:
                replacement = self.cfg.masking.redact_replacement   # destroy
            else:
                counters[etype] = counters.get(etype, 0) + 1
                replacement = (f"{self.cfg.masking.placeholder_prefix}"
                               f"{etype}_{counters[etype]}"
                               f"{self.cfg.masking.placeholder_suffix}")
                mappings.append({"placeholder": replacement,
                                 "original_value": ent.text,
                                 "entity_type": etype})
            text = text[:ent.start] + replacement + text[ent.end:]

        if mappings:
            self.repo.store_mappings(request_id, mappings)
        return text, mappings

    def mask_tickets(self, tickets: List[Dict], request_id: str) -> List[Dict]:
        """Mask every maskable field on every ticket (returns masked copies)."""
        out = []
        for t in tickets:
            masked = dict(t)
            for f in MASKABLE_FIELDS:
                if masked.get(f):
                    masked[f], _ = self.mask_text(str(masked[f]), request_id)
            out.append(masked)
        return out

    # ---------------- Remap Gate ----------------
    def remap_text(self, text: str, request_id: str) -> str:
        """Restore real values into finished text. Redacted stays [REDACTED]."""
        if not self.cfg.masking_enabled or not text:
            return text
        mappings = self.repo.get_mappings(request_id)
        if not mappings:
            return text
        for placeholder, original in mappings.items():
            text = text.replace(placeholder, original)
        self.repo.mark_used_or_delete(request_id)
        return text
