variable "resource_group_name" {
  description = "The name of the existing resource group."
  type        = string
}

//variable "ase_name" {
//  description = "The name of the existing App Service Environment v3."
//  type        = string
//}

variable "app_service_plan_name" {
  description = "The name of the existing App Service Plan."
  type        = string
}

variable "function_app_name" {
  description = "The name of the Function App."
  type        = string
}

variable "storage_account_name" {
  description = "The name of the Storage Account for the Function App."
  type        = string
}

variable "subscription_id" {
  description = "Azure subscription id"
  type        = string
  sensitive   = true
}
variable "client_id" {
  description = "Azure User Managed Identity Client ID"
  type        = string
  sensitive   = true
  default     = ""
}

variable "tenant_id" {
  description = "Azure User Managed Identity Tenant ID"
  type        = string
  sensitive   = true
  default     = ""
}

variable "image_tag" {
  description = "Docker image tag (e.g., github.sha)"
  type        = string
  default     = "latest"
}

variable "image_name" {
  description = "Docker image name"
  type        = string
}

variable "registry_url" {
  description = "Docker registry URL"
  type        = string
}

variable "user_assigned_identity_name" {
  description = "The name of the existing user-assigned managed identity"
  type        = string
  #default     = "MI-terraformvm-neuro-ai-enterprise-dev"
}

variable "identity_resource_group_name" {
  description = "The resource group name where the user-assigned managed identity exists"
  type        = string
  #default     = "RG-neuro-ai-enterprise-dev"  # Defaults to the same resource group as the function app if not specified
}

variable "function_allowed_ip_addresses" {
  description = "List of allowed IP addresses for the Function App"
  type        = list(string)
  #default = [ "10.26.0.0/16" ]
}
variable "azure_keyvault_url" {
  description = "Azure KeyVault URL"
  type        = string
}

variable "azure_managed_identity_client_id" {
  description = "Azure Managed Identity Client ID"
  type        = string
}

variable "virtual_network" {
  description = "Azure Virtual Network"
  type        = string
}

variable "virtual_subnet" {
  description = "Azure Virtual Subnet"
  type        = string
}
variable "snow_mcp_url" {
  description = "Snow MCP Server URL"
  type        = string
}

variable "private_endpoint_subnet" {
  description = "Azure Private Endpoint Subnet"
  type        = string
}
variable "application_insights_name" {
  description = "Optional existing Application Insights resource name. If empty, a new Application Insights resource will be created." 
  type        = string
  default     = ""
}
variable "private_dns_zone" {
  description = "Azure Private DNS Zone"
  type        = string
}
variable "private_endpoint_name" {
  description = "Azure Private Endpoint Name"
  type        = string
}
variable "dns_zone_group_name" {
  description = "Azure Private DNS Zone Group Name"
  type        = string
}
