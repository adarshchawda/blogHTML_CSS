"""
SOP generation flow — replaces promptflow flow.dag.yaml
3 nodes: issue_analyzer → resolution_analyzer → sop_writer
Mirrors original flow.dag.yaml exactly (no cluster_name in sop_writer).
"""
try:
    from src.core.flow_engine import Flow, FlowStep
    from src.flows.sop_steps import issue_analyzer, resolution_analyzer, sop_writer
except ImportError:
    from ..core.flow_engine import Flow, FlowStep  # type: ignore
    from .sop_steps import issue_analyzer, resolution_analyzer, sop_writer  # type: ignore


def build_sop_flow() -> Flow:
    """Build the 3-step SOP generation flow — mirrors original flow.dag.yaml."""
    flow = Flow("sop_generation_flow")

    flow.add_step(FlowStep(
        name="issue_analyzer",
        fn=issue_analyzer,
        inputs={"tickets": "${inputs.tickets}"},
    ))

    flow.add_step(FlowStep(
        name="resolution_analyzer",
        fn=resolution_analyzer,
        inputs={"issue_analysis": "${issue_analyzer}"},
        depends_on=["issue_analyzer"],
    ))

    flow.add_step(FlowStep(
        name="sop_writer",
        fn=sop_writer,
        inputs={
            "issue_analysis":   "${issue_analyzer}",
            "resolution_steps": "${resolution_analyzer}",
            # ← NO cluster_name — mirrors original flow.dag.yaml exactly
        },
        depends_on=["issue_analyzer", "resolution_analyzer"],
    ))

    return flow
