"""
Database models for the NeuroITOps backend application.

This module uses SQLAlchemy for ORM and is configured to connect to a
PostgreSQL database. Connection parameters are read from environment
variables (PGHOST, PGUSER, PGPASSWORD, PGPORT, PGDATABASE). Sensible
defaults are provided to match the credentials given by the user.
"""
from datetime import datetime, timezone
import os
import psycopg2
from urllib.parse import quote_plus
from sqlalchemy import create_engine, Column, String, DateTime, Text, ForeignKey, Table, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, scoped_session
from pgvector.sqlalchemy import Vector
from pgvector.psycopg2 import register_vector
try:
    from load_env import load_env_from_keyvault
except ImportError:
    from .load_env import load_env_from_keyvault

load_env_from_keyvault()

def _get_database_url():
    """
    Construct the database URL from environment variables.
    
    This function retrieves sensitive credentials from environment variables
    and constructs the database connection URL. The password is not stored
    in any module-level variable to avoid static analysis security warnings.
    
    Returns:
        str: The SQLAlchemy database URL for PostgreSQL connection.
    """
    # Read Postgres connection settings from environment (with provided defaults)
    host = os.getenv("PGHOST")
    user = os.getenv("PGUSER")
    port = os.getenv("PGPORT")
    #database = os.getenv("PGDATABASE", "neuroitops-db")
    database= "neuroitops-db-dev"
    
    # Retrieve password from environment - not stored as module variable
    password = os.getenv("PGPASSWORD")
    
    # URL-encode credentials for safe use in connection string
    encoded_user = quote_plus(user)
    encoded_password = quote_plus(password)
    
    # Build SQLAlchemy database URL for PostgreSQL with psycopg2 driver
    # and SSL mode required for Azure managed Postgres instances
    return (
        f"postgresql+psycopg2://{encoded_user}:{encoded_password}@{host}:{port}/{database}?sslmode=require"
    )

# Create SQLAlchemy engine and session factory
engine = create_engine(_get_database_url(), pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Register pgvector with psycopg2 (do this once at startup)
raw_conn = engine.raw_connection()
try:
    psycopg2_conn = raw_conn.connection  # unwrap to actual psycopg2 connection
    register_vector(psycopg2_conn)       # pass connection directly
finally:
    raw_conn.close()


# Create a scoped session factory
db_session = scoped_session(SessionLocal)

# Dependency to get DB session
def init_db(create_tables: bool = True):
    """Initialize the database.

    If `create_tables` is True (default) this will call
    `Base.metadata.create_all(engine)` to create any missing tables.
    Returns a tuple `(engine, SessionLocal)` for convenience.
    """
    if create_tables:
        Base.metadata.create_all(engine)
    return engine, SessionLocal
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# For backward compatibility, create a db object that supports both direct queries and session access
class DBSessionWrapper:
    def __init__(self, session_factory):
        self.session_factory = session_factory
        self.session = self.session_factory()
    
    def __getattr__(self, name):
        # Delegate attribute access to the session
        return getattr(self.session, name)
    
    def __enter__(self):
        return self.session
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.session.close()

# Initialize db as a wrapper around the session
db = DBSessionWrapper(SessionLocal)

# Association table for many-to-many relationship between clusters and tickets
cluster_ticket_mapping = Table(
    'cluster_ticket_mapping',
    Base.metadata,  # Use Base.metadata instead of db.metadata
    Column('cluster_id', String(36), ForeignKey('clusters.id'), primary_key=True),
    Column('ticket_id', String(36), ForeignKey('tickets.id'), primary_key=True)
)

class SOP(Base):
    """Standard Operating Procedure model"""
    __tablename__ = 'sops'
    
    id = Column(String(36), primary_key=True)  # UUID
    title = Column(String(255), nullable=False)
    description = Column(Text)
    content = Column(Text, nullable=False)
    document_path = Column(String(255), nullable=False)  # Path to the saved SOP document
    embedding = Column(Text)  # Store the embedding as JSON string
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    article_id = Column(String(36))
    # --- Scope (partition) tags -------------------------------------------
    # AC: every SOP record is tagged with the configured scope-key type and
    # value, so an SOP is never reused outside the partition that produced it.
    # NULL on both columns means the SOP came from the unscoped path.
    sec_cluster_field = Column(String(255), index=True)
    sec_cluster_value = Column(String(255), index=True)
    # Relationships
    clusters = relationship('Cluster', backref='sop_doc', lazy=True)
    
    def to_dict(self):
        """Convert the model to a dictionary"""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'document_path': self.document_path,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'sec_cluster_field': self.sec_cluster_field,
            'sec_cluster_value': self.sec_cluster_value,
        }

class Ticket(Base):
    """Ticket model for storing individual ticket information"""
    __tablename__ = 'tickets'
    
    id = Column(String(36), primary_key=True)  # UUID
    external_id = Column(String(255))  # External reference ID (e.g., from ServiceNow)
    title = Column(String(255), nullable=False)
    short_description = Column(Text)
    description = Column(Text)
    status = Column(String(50))
    priority = Column(String(50))
    category = Column(String(100))
    subcategory = Column(String(100))
    assigned_to = Column(String(100))
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    embedding = Column(Text)  # Store embedding as serialized JSON string
    additional_data = Column(Text)  # Store any additional fields as JSON
    # Scope tags -- which partition this ticket resolved to.
    sec_cluster_field = Column(String(255), index=True)
    sec_cluster_value = Column(String(255), index=True)
    
    clusters = relationship('Cluster', secondary=cluster_ticket_mapping, back_populates='tickets')
    
    def to_dict(self):
        """Convert the model to a dictionary"""
        return {
            'id': self.id,
            'external_id': self.external_id,
            'title': self.title,
            'short_description': self.short_description,
            'description': self.description,
            'status': self.status,
            'priority': self.priority,
            'category': self.category,
            'subcategory': self.subcategory,
            'assigned_to': self.assigned_to,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Cluster(Base):
    """Cluster model for grouping tickets"""
    __tablename__ = 'clusters'
    
    id = Column(String(36), primary_key=True)  # UUID
    name = Column(String(255), nullable=False)
    description = Column(Text)
    justification = Column(Text)
    sop_id = Column(String(36), ForeignKey('sops.id'), nullable=True)
    embedding =  Column(Vector(1536))  # Store embedding as serialized JSON string
    is_test_cluster = Column(Boolean, default=False)  # Flag for test clusters
    # Scope tags -- THE partition boundary. Every similarity lookup filters on
    # both of these, which is what stops a cluster from one partition being
    # offered as a candidate for a ticket in another.
    sec_cluster_field = Column(String(255), index=True)
    sec_cluster_value = Column(String(255), index=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    tickets = relationship('Ticket', secondary=cluster_ticket_mapping, back_populates='clusters')
    
    def to_dict(self):
        """Convert the model to a dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'justification': self.justification,
            'sop_id': self.sop_id,
            'sec_cluster_field': self.sec_cluster_field,
            'sec_cluster_value': self.sec_cluster_value,
            'ticket_count': len(self.tickets),  # Dynamic count based on relationship
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }
