"""
KNN Clustering implementation for NeuroITOps

This module implements K-Nearest Neighbors clustering for ticket descriptions
and short descriptions, replacing the MCP server clustering logic.
"""
import os
import uuid
import numpy as np
from typing import List, Dict, Any, Tuple, Optional
import logging
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import json

# For more advanced embeddings (if available)
try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False

# Setup logging
logger = logging.getLogger(__name__)

class KNNClusteringEngine:
    """KNN Clustering engine for ticket descriptions"""
    
    def __init__(self, embedding_model: str = "all-MiniLM-L6-v2", use_transformers: bool = True):
        """Initialize the KNN clustering engine"""
        self.use_transformers = use_transformers and SENTENCE_TRANSFORMERS_AVAILABLE
        
        if self.use_transformers:
            try:
                self.embedding_model = SentenceTransformer(embedding_model)
                logger.info(f"Using sentence transformer model: {embedding_model}")
            except Exception as e:
                logger.error(f"Failed to load sentence transformer: {str(e)}")
                self.use_transformers = False
        
        if not self.use_transformers:
            logger.info("Using TF-IDF vectorizer for embeddings")
            self.vectorizer = TfidfVectorizer(
                max_features=5000, 
                stop_words='english',
                ngram_range=(1, 2)
            )
    
    def get_embeddings(self, texts: List[str]) -> np.ndarray:
        """Generate embeddings for a list of texts"""
        if not texts:
            return np.array([])
        if self.use_transformers:
            return self.embedding_model.encode(texts)
        else:
            # If the vectorizer has not been fitted yet, fit on the provided
            # texts. If it has been fitted (e.g. earlier batch), use
            # transform to ensure consistent feature dimensionality across
            # calls. This prevents embedding dimension mismatches when
            # generating embeddings for single tickets incrementally.
            if not hasattr(self.vectorizer, 'vocabulary_'):
                X = self.vectorizer.fit_transform(texts)
            else:
                X = self.vectorizer.transform(texts)
            # Log TF-IDF feature words and their aggregated scores so we can
            # inspect which tokens are considered when computing TF-IDF.
            return X.toarray()
    
    # ----------------- Refactored cluster_tickets -----------------
    def cluster_tickets(self, tickets: List[Dict[str, Any]],
                        n_clusters: Optional[int] = None,
                        min_cluster_size: int = 2,
                        max_distance: float = 0.5) -> Dict[str, Any]:
        """Cluster tickets using KNN (refactored for lower cognitive complexity)"""
        if not tickets:
            return {"clusters": [], "analysis": {"total_tickets": 0, "clustered_tickets": 0, "cluster_count": 0}}

        try:
            ticket_texts = self._prepare_ticket_texts(tickets)
            embeddings = self.get_embeddings(ticket_texts)
            n_clusters = self._determine_n_clusters(len(tickets), n_clusters, min_cluster_size)
            cluster_labels, cluster_centers = self._compute_kmeans(embeddings, n_clusters)
            clusters = self._filter_clusters_by_similarity(tickets, embeddings, cluster_labels, cluster_centers, max_distance)
            formatted_clusters = self._format_clusters(clusters, min_cluster_size)
            analysis = self._generate_analysis(formatted_clusters, tickets, method="kmeans_knn", kmeans_inertia=None)
            return {"clusters": formatted_clusters, "analysis": analysis}

        except Exception as e:
            logger.error(f"Error during clustering: {str(e)}")
            return self._fallback_cluster(tickets, str(e))

    # ----------------- Helper Methods -----------------
    def _prepare_ticket_texts(self, tickets: List[Dict[str, Any]]) -> List[str]:
        texts = []
        for ticket in tickets:
            parts = [ticket.get(k, "") for k in ["title", "short_description", "description"] if ticket.get(k)]
            texts.append(" ".join(parts).strip())
        return texts

    def _determine_n_clusters(self, ticket_count: int, n_clusters: Optional[int], min_cluster_size: int) -> int:
        if n_clusters is not None:
            return min(n_clusters, ticket_count)
        if ticket_count < min_cluster_size * 2:
            return 1
        return max(2, int(np.sqrt(ticket_count / 2)))

    def _compute_kmeans(self, embeddings: np.ndarray, n_clusters: int) -> Tuple[np.ndarray, np.ndarray]:
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        labels = kmeans.fit_predict(embeddings)
        centers = kmeans.cluster_centers_
        # KNN call kept but unused variables replaced with _
        nn = NearestNeighbors(n_neighbors=min(50, len(embeddings)))
        nn.fit(embeddings)
        _, _ = nn.kneighbors(embeddings)
        return labels, centers

    def _filter_clusters_by_similarity(self, tickets, embeddings, labels, centers, max_distance):
        clusters = {}
        for i, label in enumerate(labels):
            clusters.setdefault(label, {"tickets": [], "ticket_ids": [], "centroid": centers[label].tolist()})
            ticket = tickets[i]
            ticket_id = ticket.get("id") or ticket.get("external_id") or str(i)
            similarity = cosine_similarity([embeddings[i]], [centers[label]])[0][0] if embeddings[i].shape == centers[label].shape else 0.5
            if similarity >= (1 - max_distance):
                clusters[label]["tickets"].append(ticket)
                clusters[label]["ticket_ids"].append(ticket_id)
        return clusters

    def _format_clusters(self, clusters, min_cluster_size):
        formatted = []
        for label, cluster in clusters.items():
            if len(cluster["tickets"]) >= min_cluster_size:
                titles = [t.get("title", "") for t in cluster["tickets"]]
                formatted.append({
                    "id": str(uuid.uuid4()),
                    "name": self._generate_cluster_name(titles, label),
                    "tickets": cluster["tickets"],
                    "ticket_ids": cluster["ticket_ids"],
                    "centroid": cluster["centroid"]
                })
        return sorted(formatted, key=lambda x: len(x["tickets"]), reverse=True)

    def _generate_analysis(self, clusters, tickets, method="kmeans_knn", kmeans_inertia=None):
        return {
            "total_tickets": len(tickets),
            "clustered_tickets": sum(len(c["tickets"]) for c in clusters),
            "cluster_count": len(clusters),
            "method": method,
            "model": "sentence_transformer" if self.use_transformers else "tfidf",
            "metrics": {"silhouette_score": None, "inertia": kmeans_inertia}
        }

    def _fallback_cluster(self, tickets, error: str):
        fallback = {
            "id": str(uuid.uuid4()),
            "name": "All Tickets",
            "tickets": tickets,
            "ticket_ids": [t.get("id") or t.get("external_id") or str(i) for i, t in enumerate(tickets)]
        }
        return {
            "clusters": [fallback],
            "analysis": {
                "total_tickets": len(tickets),
                "clustered_tickets": len(tickets),
                "cluster_count": 1,
                "method": "fallback",
                "error": error
            }
        }

    # ----------------- Cluster Name Generator -----------------
    def _generate_cluster_name(self, titles: List[str], cluster_id: int) -> str:
        """Generate a name for a cluster based on common words in titles"""
        if not titles:
            return f"Cluster {cluster_id}"
        from collections import Counter
        import re
        stopwords = {'a', 'an', 'the', 'and', 'or', 'but', 'if', 'then', 'else', 'when',
                     'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into',
                     'through', 'during', 'before', 'after', 'above', 'below', 'to',
                     'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under',
                     'of', 'is', 'are', 'was', 'were', 'be', 'been', 'being'}
        all_words = []
        for title in titles:
            words = re.findall(r'\b[a-zA-Z]{3,}\b', title.lower())
            all_words.extend([w for w in words if w not in stopwords])
        word_counts = Counter(all_words)
        most_common = word_counts.most_common(3)
        if most_common:
            cluster_words = [word for word, count in most_common if count > 1]
            if cluster_words:
                return "Cluster: " + " ".join(cluster_words).title()
        if titles[0]:
            return titles[0][:30] + ("..." if len(titles[0]) > 30 else "")
        return f"Cluster {cluster_id}"

# Create a singleton instance for global use
clustering_engine = KNNClusteringEngine()