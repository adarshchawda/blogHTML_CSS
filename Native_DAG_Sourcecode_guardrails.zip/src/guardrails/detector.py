"""
PII Detector Module
===================
Detects Personally Identifiable Information (PII) in text using Microsoft Presidio.

This module provides enterprise-grade PII detection with:
- Built-in entity detection (names, emails, phones, credit cards, etc.)
- Custom enterprise patterns (server names, incident IDs, employee IDs)
- Configurable confidence thresholds
- Thread-safe operation

Dependencies:
    - presidio-analyzer: Microsoft's PII detection library
    - spacy: NLP backend for named entity recognition
    - en_core_web_lg: Large English language model for spaCy

Usage:
    from pii_masking_integration.masking.detector import PIIDetector
    
    detector = PIIDetector()
    entities = detector.detect("Contact john@company.com for help")

Version: 2.0.0
"""

import logging
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

# Presidio imports
from presidio_analyzer import (
    AnalyzerEngine,
    RecognizerRegistry,
    PatternRecognizer,
    Pattern,
    RecognizerResult
)
from presidio_analyzer.nlp_engine import NlpEngineProvider

from src.guardrails.config import DetectionConfig, default_config

# Configure module logger
logger = logging.getLogger(__name__)


# =============================================================================
# Constants - Custom Recognizer Configurations
# =============================================================================

CUSTOM_RECOGNIZERS: List[Dict[str, Any]] = [
    {
        "entity": "SERVER_NAME",
        "name": "server-name-pattern",
        "regex": r"\b(PROD|DEV|UAT|STG|QA|TEST)-[A-Z]{2,6}-\d{1,4}\b",
        "score": 0.95,
        "context": ["server", "host", "machine", "node", "instance", "hostname"]
    },
    {
        "entity": "INCIDENT_ID",
        "name": "servicenow-incident-pattern",
        "regex": r"\bINC\d{7,10}\b",
        "score": 1.0,
        "context": ["incident", "ticket", "case", "request", "issue"]
    },
    {
        "entity": "EMPLOYEE_ID",
        "name": "employee-id-pattern",
        "regex": r"\b(EMP|CTS|USR)[-]?\d{4,8}[-]?[\w\u00C0-\u024F]*\b",
        "score": 0.98,
        "context": ["employee", "user", "engineer", "staff", "assigned", "reporter", "id"]
    },
    {
        "entity": "ASSET_TAG",
        "name": "asset-tag-pattern",
        "regex": r"\bASSET-\d{4}-\d{6}\b",
        "score": 0.97,
        "context": ["asset", "device", "equipment", "hardware"]
    },
    {
        "entity": "ACCOUNT_NUMBER",
        "name": "account-number-pattern",
        "regex": r"\b[A-Z]{2,4}\d{8,12}\b",
        "score": 0.85,
        "context": ["account", "customer", "client", "acct", "acc#", "account#"]
    },
    {
        "entity": "IP_ADDRESS",
        "name": "ipv4-enhanced-pattern",
        "regex": r"\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b",
        "score": 0.90,
        "context": ["ip", "address", "server", "host", "connect", "network", "subnet"]
    },
    {
        "entity": "PHONE_NUMBER",
        "name": "phone-number-pattern",
        "regex": r"(?<![A-Z0-9])(?:\+\d{1,3}[-.\s]?)?(?:\(?\d{2,4}\)?[-.\s]?)?\d{2,4}[-.\s]?\d{2,4}[-.\s]?\d{2,4}(?![0-9])",
        "score": 0.90,
        "context": ["phone", "call", "contact", "mobile", "cell", "tel", "telephone", "fax", "secondary"]
    },
    {
        "entity": "EMAIL_ADDRESS",
        "name": "international-email-pattern",
        "regex": r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b",
        "score": 0.95,
        "context": ["email", "mail", "contact", "address", "e-mail", "notification", "sent"]
    }
]

# --- SOURCE: NEW — three recognizers with no AWS equivalent (Azure user story) ---
CUSTOM_RECOGNIZERS += [
    {
        "entity": "DATABASE_NAME",
        "name": "database-name-pattern",
        "regex": r"\b([A-Za-z_][A-Za-z0-9_]*\.)?[A-Za-z_][A-Za-z0-9_]*(_db|_database|db_)\b",
        "score": 0.80,
        "context": ["database", "db", "schema", "instance", "catalog", "table"]
    },
    {
        "entity": "CONNECTION_STRING",
        "name": "connection-string-pattern",
        "regex": r"(?i)\b(Server|Data Source|Host)\s*=\s*[^;]+;(.*?;)?(Password|Pwd)\s*=\s*[^;]+",
        "score": 0.95,
        "context": ["connection", "connectionstring", "dsn", "jdbc", "odbc", "server", "password"]
    },
    {
        "entity": "FILE_PATH",
        "name": "file-path-pattern",
        "regex": r"(?:[A-Za-z]:\\[^\s\"']+|\\\\[^\s\"']+|/(?:[^/\s\"']+/){2,}[^/\s\"']*)",
        "score": 0.75,
        "context": ["path", "file", "directory", "folder", "location", "mount"]
    }
]


# =============================================================================
# Data Classes
# =============================================================================


@dataclass(frozen=True)
class DetectedEntity:
    """
    Immutable representation of a detected PII entity.
    
    Attributes:
        entity_type: Type of PII (PERSON, EMAIL_ADDRESS, etc.)
        text: The actual PII text that was detected
        start: Start position in the original text (0-indexed)
        end: End position in the original text (exclusive)
        score: Confidence score from 0.0 to 1.0
    
    Example:
        >>> entity = DetectedEntity(
        ...     entity_type="EMAIL_ADDRESS",
        ...     text="john@company.com",
        ...     start=8,
        ...     end=24,
        ...     score=0.95
        ... )
    """
    entity_type: str
    text: str
    start: int
    end: int
    score: float
    
    def __post_init__(self):
        """Validate entity attributes after initialization."""
        if not self.entity_type:
            raise ValueError("entity_type cannot be empty")
        if self.start < 0:
            raise ValueError("start position cannot be negative")
        if self.end <= self.start:
            raise ValueError("end position must be greater than start")
        if not 0.0 <= self.score <= 1.0:
            raise ValueError("score must be between 0.0 and 1.0")
    
    def __repr__(self) -> str:
        """Return a concise string representation."""
        truncated_text = self.text[:20] + '...' if len(self.text) > 20 else self.text
        return (
            f"DetectedEntity({self.entity_type}: "
            f"'{truncated_text}' [{self.start}:{self.end}] score={self.score:.2f})"
        )


# =============================================================================
# Main Detector Class
# =============================================================================


class PIIDetector:
    """
    Production-grade PII detector using Microsoft Presidio.
    
    This class provides thread-safe PII detection with:
    - Automatic NLP engine initialization with fallback
    - Custom recognizers for enterprise patterns
    - Configurable detection thresholds
    - Comprehensive error handling
    
    Attributes:
        config: Detection configuration settings
        analyzer: Presidio AnalyzerEngine instance
    
    Example:
        >>> detector = PIIDetector()
        >>> entities = detector.detect("Email john@company.com for ticket INC0012345")
        >>> for e in entities:
        ...     print(f"{e.entity_type}: {e.text}")
        EMAIL_ADDRESS: john@company.com
        INCIDENT_ID: INC0012345
    """
    
    def __init__(self, config: Optional[DetectionConfig] = None):
        """
        Initialize the PII detector with Presidio engine.
        
        Args:
            config: Detection configuration. Uses default_config if not provided.
        
        Raises:
            RuntimeError: If Presidio analyzer cannot be initialized.
        """
        self.config = config or default_config.detection
        self._analyzer: Optional[AnalyzerEngine] = None
        
        logger.info(
            "Initializing PIIDetector with config: "
            f"language={self.config.language}, "
            f"spacy_model={self.config.spacy_model}, "
            f"score_threshold={self.config.score_threshold}"
        )
        
        try:
            self._initialize_analyzer()
            logger.info("PIIDetector initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize PIIDetector: {e}", exc_info=True)
            raise RuntimeError(f"PIIDetector initialization failed: {e}") from e
    
    @property
    def analyzer(self) -> AnalyzerEngine:
        """Get the Presidio analyzer engine (lazy initialization)."""
        if self._analyzer is None:
            self._initialize_analyzer()
        return self._analyzer
    
    def _initialize_analyzer(self) -> None:
        """
        Initialize the Presidio AnalyzerEngine with NLP backend.

        This method:
        1. Attempts to load the configured spaCy model
        2. Falls back to default engine if model loading fails
        3. Builds and registers custom recognizers
        4. Creates the analyzer engine
        """
        logger.info("START: _initialize_analyzer()")
        print("START: _initialize_analyzer()")
        nlp_engine = self._create_nlp_engine()
        registry = self._build_recognizer_registry()

        if nlp_engine:
            self._analyzer = AnalyzerEngine(nlp_engine=nlp_engine, registry=registry)
        else:
            logger.warning("Using default NLP engine (limited detection capability)")
            self._analyzer = AnalyzerEngine(registry=registry)
        logger.info("END: _initialize_analyzer() - SUCCESS")
        print("END: _initialize_analyzer() - SUCCESS")
    
    def _create_nlp_engine(self):
        """
        Create the NLP engine with spaCy backend.

        Returns:
            NLP engine instance, or None if creation fails.
        """
        logger.info("START: _create_nlp_engine()")
        print("START: _create_nlp_engine()")
        nlp_config = {
            "nlp_engine_name": "spacy",
            "models": [{
                "lang_code": self.config.language,
                "model_name": self.config.spacy_model
            }]
        }

        try:
            provider = NlpEngineProvider(nlp_configuration=nlp_config)
            nlp_engine = provider.create_engine()
            logger.info(f"Successfully loaded spaCy model: {self.config.spacy_model}")
            logger.info("END: _create_nlp_engine() - SUCCESS")
            print("END: _create_nlp_engine() - SUCCESS")
            return nlp_engine
        except OSError as e:
            logger.warning(
                f"spaCy model '{self.config.spacy_model}' not found. "
                f"Install with: python -m spacy download {self.config.spacy_model}"
            )
            logger.exception(f"OSError loading spaCy model: {e}")
            print(f"ERROR: _create_nlp_engine() {type(e).__name__}")
            return None
        except Exception as e:
            logger.warning(
                f"Failed to load spaCy model '{self.config.spacy_model}': {e}. "
                "Falling back to default NLP engine."
            )
            logger.exception(f"Unexpected error creating NLP engine: {e}")
            print(f"ERROR: _create_nlp_engine() {type(e).__name__}")
            return None
    
    def _build_recognizer_registry(self) -> RecognizerRegistry:
        """
        Build the recognizer registry with built-in and custom recognizers.

        Returns:
            Configured RecognizerRegistry instance.
        """
        logger.info("START: _build_recognizer_registry()")
        print("START: _build_recognizer_registry()")
        registry = RecognizerRegistry()
        registry.load_predefined_recognizers()

        # Add custom recognizers from configuration
        custom_count = 0
        failed_count = 0
        for recognizer_config in CUSTOM_RECOGNIZERS:
            try:
                recognizer = self._create_pattern_recognizer(recognizer_config)
                registry.add_recognizer(recognizer)
                custom_count += 1
                logger.debug(f"Registered custom recognizer: {recognizer_config['entity']}")
            except Exception as e:
                failed_count += 1
                logger.warning(
                    f"Failed to create recognizer for {recognizer_config['entity']}: {e}"
                )
                logger.exception(f"Recognizer creation error for {recognizer_config['entity']}: {e}")
                print(f"ERROR: _build_recognizer_registry() {type(e).__name__}")

        logger.info(f"Registered {custom_count} custom PII recognizers (failed: {failed_count})")
        logger.info("END: _build_recognizer_registry() - SUCCESS")
        print("END: _build_recognizer_registry() - SUCCESS")
        return registry
    
    @staticmethod
    def _create_pattern_recognizer(config: Dict[str, Any]) -> PatternRecognizer:
        """
        Create a PatternRecognizer from configuration dictionary.
        
        Args:
            config: Dictionary with entity, name, regex, score, and context keys.
        
        Returns:
            Configured PatternRecognizer instance.
        """
        return PatternRecognizer(
            supported_entity=config["entity"],
            patterns=[
                Pattern(
                    name=config["name"],
                    regex=config["regex"],
                    score=config["score"]
                )
            ],
            context=config.get("context", [])
        )
    
    def detect(self, text: str) -> List[DetectedEntity]:
        """
        Detect PII entities in the given text.
        
        This method analyzes the input text and returns all detected PII entities
        sorted by their position in the text.
        
        Args:
            text: Input text to analyze for PII.
        
        Returns:
            List of DetectedEntity objects sorted by start position.
            Returns empty list if text is empty or no entities found.
        
        Raises:
            ValueError: If text is None.
        
        Example:
            >>> detector = PIIDetector()
            >>> entities = detector.detect("Contact john@example.com")
            >>> len(entities)
            1
            >>> entities[0].entity_type
            'EMAIL_ADDRESS'
        """
        logger.info("START: detect()")
        print("START: detect()")

        # Input validation
        if text is None:
            raise ValueError("Input text cannot be None")

        if not text or not text.strip():
            logger.debug("Empty text provided, returning empty list")
            logger.info("END: detect() - SUCCESS")
            print("END: detect() - SUCCESS")
            return []

        # Combine all entity types to detect
        all_entities = self.config.builtin_entities + self.config.custom_entities

        # First, run custom pattern-based detection for international characters
        # This ensures Unicode names, emails, phones are detected
        custom_entities = self._detect_with_custom_patterns(text)

        try:
            # Run Presidio analyzer
            logger.info(f"Presidio analyzer.analyze() START: entities={all_entities}, score_threshold={self.config.score_threshold}")
            print(f"Presidio analyzer.analyze() START: entities={all_entities}, score_threshold={self.config.score_threshold}")
            results: List[RecognizerResult] = self.analyzer.analyze(
                text=text,
                language=self.config.language,
                entities=all_entities,
                score_threshold=self.config.score_threshold
            )
            presidio_entity_count = len(results)
            presidio_type_counts: Dict[str, int] = {}
            for r in results:
                presidio_type_counts[r.entity_type] = presidio_type_counts.get(r.entity_type, 0) + 1
            logger.info(
                f"Presidio analyzer.analyze() END: total={presidio_entity_count}, "
                f"types={presidio_type_counts}"
            )
            print(
                f"Presidio analyzer.analyze() END: total={presidio_entity_count}, "
                f"types={presidio_type_counts}"
            )
        except Exception as e:
            logger.exception(f"Presidio analysis failed: {e}")
            print(f"ERROR: detect() Presidio analysis {type(e).__name__}")
            results = []

        # Convert to DetectedEntity objects
        detected_entities = self._convert_results(text, results)

        # Merge custom pattern results with Presidio results
        presidio_count_before_merge = len(detected_entities)
        custom_count_before_merge = len(custom_entities)
        detected_entities = self._merge_entities(detected_entities, custom_entities)

        # Sort by position for consistent masking
        detected_entities.sort(key=lambda e: e.start)

        # Log detection summary
        if detected_entities:
            entity_summary = self._summarize_entities(detected_entities)
            logger.info(f"Detected {len(detected_entities)} PII entities: {entity_summary}")
        else:
            logger.debug("No PII entities detected in text")

        logger.info("END: detect() - SUCCESS")
        print("END: detect() - SUCCESS")
        return detected_entities
    
    def _detect_with_custom_patterns(self, text: str) -> List[DetectedEntity]:
        """
        Detect PII using custom regex patterns for international/Unicode support.
        
        This method handles cases where Presidio's NLP model may miss:
        - International names with accents (María, Ünsal, etc.)
        - Non-Latin scripts (Chinese, Japanese, etc.)
        - International phone numbers
        - Unicode employee IDs
        
        Args:
            text: Input text to analyze.
            
        Returns:
            List of DetectedEntity objects.
        """
        logger.info("START: _detect_with_custom_patterns()")
        print("START: _detect_with_custom_patterns()")
        import re
        entities = []
        per_recognizer_counts: Dict[str, int] = {}

        for recognizer_config in CUSTOM_RECOGNIZERS:
            entity_type = recognizer_config["entity"]
            try:
                pattern = re.compile(recognizer_config["regex"], re.UNICODE)
                match_count = 0
                for match in pattern.finditer(text):
                    entity = DetectedEntity(
                        entity_type=entity_type,
                        text=match.group(),
                        start=match.start(),
                        end=match.end(),
                        score=recognizer_config["score"]
                    )
                    entities.append(entity)
                    match_count += 1
                per_recognizer_counts[entity_type] = match_count
            except Exception as e:
                logger.warning(f"Custom pattern detection failed for {entity_type}: {e}")
                logger.exception(f"Custom pattern detection error for {entity_type}: {e}")
                print(f"ERROR: _detect_with_custom_patterns() {type(e).__name__}")
                continue

        logger.info(f"Custom pattern detection counts per recognizer type: {per_recognizer_counts}")
        logger.info(f"END: _detect_with_custom_patterns() - SUCCESS (total matches: {len(entities)})")
        print(f"END: _detect_with_custom_patterns() - SUCCESS (total matches: {len(entities)})")
        return entities
    
    def _merge_entities(
        self,
        presidio_entities: List[DetectedEntity],
        custom_entities: List[DetectedEntity]
    ) -> List[DetectedEntity]:
        """
        Merge entities from Presidio and custom pattern detection.
        
        Avoids duplicates by checking for overlapping positions.
        
        Args:
            presidio_entities: Entities detected by Presidio.
            custom_entities: Entities detected by custom patterns.
            
        Returns:
            Merged list of unique entities.
        """
        logger.info(
            f"START: _merge_entities() - presidio_input={len(presidio_entities)}, "
            f"custom_input={len(custom_entities)}"
        )
        print(
            f"START: _merge_entities() - presidio_input={len(presidio_entities)}, "
            f"custom_input={len(custom_entities)}"
        )

        # Start with Presidio results
        merged = list(presidio_entities)

        # Add custom entities that don't overlap with existing ones
        added_custom = 0
        deduped_custom = 0
        for custom in custom_entities:
            is_duplicate = False
            for existing in merged:
                # Check for significant overlap (>50%)
                overlap_start = max(custom.start, existing.start)
                overlap_end = min(custom.end, existing.end)
                overlap_len = max(0, overlap_end - overlap_start)
                custom_len = custom.end - custom.start

                if overlap_len > custom_len * 0.5:
                    is_duplicate = True
                    deduped_custom += 1
                    break

            if not is_duplicate:
                merged.append(custom)
                added_custom += 1

        logger.info(
            f"Merge/dedup: presidio={len(presidio_entities)}, custom_added={added_custom}, "
            f"custom_deduped={deduped_custom}, pre-overlap-removal={len(merged)}"
        )

        # Remove overlapping entities, keeping higher scoring ones
        merged = self._remove_overlapping_entities(merged)

        logger.info(f"END: _merge_entities() - SUCCESS (output={len(merged)})")
        print(f"END: _merge_entities() - SUCCESS (output={len(merged)})")
        return merged
    
    def _convert_results(
        self,
        text: str,
        results: List[RecognizerResult]
    ) -> List[DetectedEntity]:
        """
        Convert Presidio results to DetectedEntity objects.
        
        Args:
            text: Original text for extracting entity text.
            results: List of Presidio RecognizerResult objects.
        
        Returns:
            List of DetectedEntity objects.
        """
        logger.info(f"START: _convert_results() - input results count: {len(results)}")
        print(f"START: _convert_results() - input results count: {len(results)}")
        entities = []
        skipped = 0
        for result in results:
            try:
                entity = DetectedEntity(
                    entity_type=result.entity_type,
                    text=text[result.start:result.end],
                    start=result.start,
                    end=result.end,
                    score=result.score
                )
                entities.append(entity)
            except ValueError as e:
                skipped += 1
                logger.warning(f"Invalid entity result skipped: {e}")
                continue

        logger.info(f"Converted {len(entities)} results (skipped {skipped} invalid)")

        # Remove overlapping entities - keep higher priority entity types
        entities = self._remove_overlapping_entities(entities)
        logger.info(f"END: _convert_results() - SUCCESS (after overlap removal: {len(entities)})")
        print(f"END: _convert_results() - SUCCESS (after overlap removal: {len(entities)})")
        return entities
    
    def _remove_overlapping_entities(self, entities: List[DetectedEntity]) -> List[DetectedEntity]:
        """
        Remove overlapping entities, keeping the higher priority entity type.
        
        Priority order (highest to lowest):
        1. Custom enterprise patterns (EMPLOYEE_ID, SERVER_NAME, INCIDENT_ID, etc.)
        2. Specific PII (EMAIL_ADDRESS, PHONE_NUMBER, IP_ADDRESS, CREDIT_CARD, SSN)
        3. Generic entities (PERSON, LOCATION, URL)
        
        Strategy:
        - If entities overlap, keep the one with higher priority
        - If same priority, keep the one with higher confidence score
        - LOCATION is lowest priority (often overlaps with names/IDs)
        
        Args:
            entities: List of detected entities.
            
        Returns:
            Filtered list with overlapping lower-priority entities removed.
        """
        logger.info(f"START: _remove_overlapping_entities() - input count: {len(entities)}")
        print(f"START: _remove_overlapping_entities() - input count: {len(entities)}")
        if not entities:
            logger.info("END: _remove_overlapping_entities() - SUCCESS (no entities)")
            print("END: _remove_overlapping_entities() - SUCCESS (no entities)")
            return entities

        # Define priority tiers (higher number = higher priority)
        priority_map = {
            # Tier 3: Highest - Enterprise custom patterns
            'EMPLOYEE_ID': 30,
            'SERVER_NAME': 30,
            'INCIDENT_ID': 30,
            'ASSET_TAG': 30,
            'ACCOUNT_NUMBER': 30,
            # --- NEW (Azure user story) ---
            'CONNECTION_STRING': 30,
            'DATABASE_NAME': 30,
            'FILE_PATH': 20,
            
            # Tier 2: High - Specific PII types
            'EMAIL_ADDRESS': 20,
            'PHONE_NUMBER': 20,
            'IP_ADDRESS': 20,
            'CREDIT_CARD': 20,
            'US_SSN': 20,
            'US_BANK_NUMBER': 20,
            'AWS_ACCESS_KEY': 20,
            'AWS_SECRET_KEY': 20,
            
            # Tier 1: Medium - Person names
            'PERSON': 10,
            'URL': 10,
            
            # Tier 0: Lowest - Generic location
            'LOCATION': 0,
            'DATE_TIME': 0
        }
        
        def get_priority(entity: DetectedEntity) -> tuple:
            """Get priority tuple for sorting (priority, score, -start)"""
            priority = priority_map.get(entity.entity_type, 5)
            return (priority, entity.score, -entity.start)
        
        # Sort by position first
        sorted_entities = sorted(entities, key=lambda e: e.start)

        # Remove overlapping entities, keeping higher priority ones
        filtered = []
        removed_types: Dict[str, int] = {}
        for entity in sorted_entities:
            should_keep = True

            # Check against already kept entities
            for kept in filtered:
                # Check if they overlap
                if not (entity.end <= kept.start or entity.start >= kept.end):
                    # They overlap - compare priorities
                    entity_priority = get_priority(entity)
                    kept_priority = get_priority(kept)

                    if entity_priority <= kept_priority:
                        # Current entity has lower or equal priority - skip it
                        should_keep = False
                        removed_types[entity.entity_type] = removed_types.get(entity.entity_type, 0) + 1
                        logger.debug(
                            f"Filtered out {entity.entity_type} "
                            f"(overlaps with higher priority {kept.entity_type})"
                        )
                        break
                    else:
                        # Current entity has higher priority - remove the kept one
                        removed_types[kept.entity_type] = removed_types.get(kept.entity_type, 0) + 1
                        filtered.remove(kept)
                        logger.debug(
                            f"Replacing {kept.entity_type} "
                            f"with higher priority {entity.entity_type}"
                        )

            if should_keep:
                filtered.append(entity)

        kept_type_counts: Dict[str, int] = {}
        for e in filtered:
            kept_type_counts[e.entity_type] = kept_type_counts.get(e.entity_type, 0) + 1
        logger.info(
            f"Overlap removal: input={len(entities)}, kept={len(filtered)}, "
            f"removed_by_type={removed_types}, kept_by_type={kept_type_counts}"
        )
        logger.info(f"END: _remove_overlapping_entities() - SUCCESS (output={len(filtered)})")
        print(f"END: _remove_overlapping_entities() - SUCCESS (output={len(filtered)})")
        return filtered
    
    @staticmethod
    def _summarize_entities(entities: List[DetectedEntity]) -> str:
        """
        Create a summary string of detected entity types.
        
        Args:
            entities: List of detected entities.
        
        Returns:
            Summary string like "PERSON(2), EMAIL_ADDRESS(1)".
        """
        counts: Dict[str, int] = {}
        for entity in entities:
            counts[entity.entity_type] = counts.get(entity.entity_type, 0) + 1
        return ", ".join(f"{k}({v})" for k, v in sorted(counts.items()))
    
    def detect_with_context(
        self,
        text: str,
        context_window: int = 20
    ) -> List[Dict[str, Any]]:
        """
        Detect PII with surrounding context for debugging and validation.
        
        This method is useful for:
        - Debugging detection issues
        - Validating detected entities
        - Creating audit logs
        
        Args:
            text: Input text to analyze.
            context_window: Number of characters to include before/after entity.
        
        Returns:
            List of dictionaries with entity info and surrounding context.
        
        Raises:
            ValueError: If context_window is negative.
        
        Example:
            >>> results = detector.detect_with_context("Call john@example.com today")
            >>> results[0]['context']
            '...Call john@example.com tod...'
        """
        logger.info(f"START: detect_with_context() - context_window={context_window}")
        print(f"START: detect_with_context() - context_window={context_window}")
        if context_window < 0:
            raise ValueError("context_window cannot be negative")

        entities = self.detect(text)
        results = []

        for entity in entities:
            start_ctx = max(0, entity.start - context_window)
            end_ctx = min(len(text), entity.end + context_window)

            context_text = text[start_ctx:end_ctx]
            if start_ctx > 0:
                context_text = "..." + context_text
            if end_ctx < len(text):
                context_text = context_text + "..."

            results.append({
                "entity_type": entity.entity_type,
                "text": entity.text,
                "score": entity.score,
                "start": entity.start,
                "end": entity.end,
                "context": context_text
            })

        logger.info(f"END: detect_with_context() - SUCCESS (entities_with_context={len(results)})")
        print(f"END: detect_with_context() - SUCCESS (entities_with_context={len(results)})")
        return results
    
    def get_supported_entities(self) -> List[str]:
        """
        Get list of all supported entity types.

        Returns:
            Combined list of built-in and custom entity types.
        """
        logger.info("START: get_supported_entities()")
        print("START: get_supported_entities()")
        result = self.config.builtin_entities + self.config.custom_entities
        logger.info(f"END: get_supported_entities() - SUCCESS (count={len(result)})")
        print(f"END: get_supported_entities() - SUCCESS (count={len(result)})")
        return result
    
    def is_healthy(self) -> bool:
        """
        Check if the detector is properly initialized and functional.

        Returns:
            True if detector is ready to use, False otherwise.
        """
        logger.info("START: is_healthy()")
        print("START: is_healthy()")
        try:
            # Simple test detection
            self.detect("test@example.com")
            logger.info("END: is_healthy() - SUCCESS (healthy=True)")
            print("END: is_healthy() - SUCCESS (healthy=True)")
            return True
        except Exception as e:
            logger.exception(f"Health check failed: {e}")
            print(f"ERROR: is_healthy() {type(e).__name__}")
            return False


# =============================================================================
# Module-level Functions
# =============================================================================

def create_detector(config: Optional[DetectionConfig] = None) -> PIIDetector:
    """
    Factory function to create a PIIDetector instance.

    Args:
        config: Optional detection configuration.

    Returns:
        Configured PIIDetector instance.
    """
    logger.info("START: create_detector()")
    print("START: create_detector()")
    detector = PIIDetector(config=config)
    logger.info("END: create_detector() - SUCCESS")
    print("END: create_detector() - SUCCESS")
    return detector
