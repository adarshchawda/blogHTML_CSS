terraform {
  required_version = "~> 1.3"

required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
  }
  backend "azurerm" {}
}

provider "azurerm" {
  features {}
  use_msi         = true
  subscription_id = var.subscription_id != "" ? var.subscription_id : null
  client_id       = var.client_id != "" ? var.client_id : null
  tenant_id       = var.tenant_id != "" ? var.tenant_id : null
}


# Reference existing Resource Group
data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

# Reference existing App Service Plan
data "azurerm_service_plan" "app_plan" {
  name                = var.app_service_plan_name
  resource_group_name = data.azurerm_resource_group.rg.name
}

# Reference existing Storage Account
data "azurerm_storage_account" "sa" {
  name                = var.storage_account_name
  resource_group_name = data.azurerm_resource_group.rg.name
}

# Reference existing User-Assigned Managed Identity
data "azurerm_user_assigned_identity" "uami" {
  name                = var.user_assigned_identity_name
  resource_group_name = var.identity_resource_group_name
}
data "azurerm_virtual_network" "existing_vnet" {
  name                = var.virtual_network
  resource_group_name = data.azurerm_resource_group.rg.name
}
data "azurerm_subnet" "existing_subnet" {
  name                 = var.virtual_subnet
  virtual_network_name = data.azurerm_virtual_network.existing_vnet.name
  resource_group_name  = data.azurerm_resource_group.rg.name
}
data "azurerm_subnet" "private_endpoint" {
  name                 = var.private_endpoint_subnet
  virtual_network_name = data.azurerm_virtual_network.existing_vnet.name
  resource_group_name  = data.azurerm_resource_group.rg.name
}

# Function App with User-Assigned Managed Identity
resource "azurerm_linux_function_app" "function_app" {
  name                = var.function_app_name
  location            = data.azurerm_resource_group.rg.location
  resource_group_name = data.azurerm_resource_group.rg.name
  service_plan_id     = data.azurerm_service_plan.app_plan.id
  public_network_access_enabled = false

  storage_account_name       = data.azurerm_storage_account.sa.name
  storage_account_access_key = data.azurerm_storage_account.sa.primary_access_key
  virtual_network_subnet_id = data.azurerm_subnet.existing_subnet.id
  # Required for App Service Environment
  webdeploy_publish_basic_authentication_enabled = false
  ftp_publish_basic_authentication_enabled = false
  https_only = true

  
  # Attach User-Assigned Managed Identity
  identity {
    type         = "UserAssigned"
    identity_ids = [data.azurerm_user_assigned_identity.uami.id]
  }

  site_config {
    always_on = true
    container_registry_managed_identity_client_id = data.azurerm_user_assigned_identity.uami.client_id
    container_registry_use_managed_identity = true

    application_stack {
      docker {
          registry_url = var.registry_url
          image_name   = var.image_name
          image_tag    = var.image_tag
        }
    }

    # IP Restrictions
    # Set default action for unmatched IP restrictions
    ip_restriction_default_action = "Deny"
  
  # IP Restrictions - Only allow specific IPs, deny all others by default
    ip_restriction {
      name       = "AllowSpecificIP_1"
      ip_address = var.function_allowed_ip_addresses[0]
      priority   = 100
    }
  }

  # App settings for Managed Identity
  app_settings = {    
    "WEBSITES_ENABLE_APP_SERVICE_STORAGE" = "false"
    "FUNCTIONS_WORKER_RUNTIME"            = "python"
    "FUNCTIONS_EXTENSION_VERSION"         = "~4"
    "DOCKER_REGISTRY_SERVER_URL" = var.registry_url
    "DOCKER_CUSTOM_IMAGE_NAME"   = "DOCKER|${var.registry_url}/${var.function_app_name}:${var.image_tag}"
    "KEY_VAULT_BASE_URL" = var.azure_keyvault_url
    "MANAGED_IDENTITY_CLIENT_ID" = var.azure_managed_identity_client_id
    "MCP_SERVER_URL" = var.snow_mcp_url
    # Application Insights: use existing if provided, otherwise use the newly created one
    "APPINSIGHTS_INSTRUMENTATIONKEY" = var.application_insights_name != "" ? data.azurerm_application_insights.existing[0].instrumentation_key : azurerm_application_insights.ai[0].instrumentation_key
    "APPLICATIONINSIGHTS_CONNECTION_STRING" = var.application_insights_name != "" ? data.azurerm_application_insights.existing[0].connection_string : azurerm_application_insights.ai[0].connection_string
  } 
}
# Use an existing Application Insights if the name is provided
data "azurerm_application_insights" "existing" {
  count               = var.application_insights_name != "" ? 1 : 0
  name                = var.application_insights_name
  resource_group_name = data.azurerm_resource_group.rg.name
}
# Create Application Insights when no existing name is supplied
resource "azurerm_application_insights" "ai" {
  count               = var.application_insights_name == "" ? 1 : 0
  name                = "${var.function_app_name}-ai"
  location            = data.azurerm_resource_group.rg.location
  resource_group_name = data.azurerm_resource_group.rg.name
  application_type    = "web"
}
resource "azurerm_private_dns_zone" "private_dns" {
  name                = var.private_dns_zone
  resource_group_name = data.azurerm_resource_group.rg.name
}
 

 
resource "azurerm_private_endpoint" "pe" {
  name                = var.private_endpoint_name
  location            = data.azurerm_resource_group.rg.location
  resource_group_name = data.azurerm_resource_group.rg.name
  subnet_id           = data.azurerm_subnet.private_endpoint.id
 
  private_service_connection {
    name                           = "function-connection"
    private_connection_resource_id = azurerm_linux_function_app.function_app.id
    subresource_names              = ["sites"]
    is_manual_connection           = false
  }
 
  private_dns_zone_group {
    name                 = var.dns_zone_group_name
    private_dns_zone_ids = [azurerm_private_dns_zone.private_dns.id]
  }
}

