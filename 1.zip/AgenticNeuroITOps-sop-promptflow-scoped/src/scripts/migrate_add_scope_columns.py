"""Add the scope (partition) columns and indexes to an existing database.

Run this ONCE before deploying the scoped clustering change. It is idempotent --
re-running it is a no-op -- so it is safe to run again if you are unsure whether
it already completed.

What it adds:

    tickets.sec_cluster_field    tickets.sec_cluster_value
    clusters.sec_cluster_field   clusters.sec_cluster_value
    sops.sec_cluster_field       sops.sec_cluster_value

plus a composite index on each table over (sec_cluster_field, sec_cluster_value).

Every column is NULLABLE. Existing rows keep NULL on both, which is exactly what
the unscoped code path looks for, so rows written before this migration continue
to behave as they did. That is what makes unsetting SEC_CLUSTER_FIELD a genuine
rollback rather than a half-state.

Why the composite index matters: every similarity lookup filters on both scope
columns. Without the index each incoming ticket does a full scan of `clusters`.
With a composite scope key like u_hostname,u_env,business_service you will have
thousands of partitions, so this stops being optional very quickly.

Usage (PowerShell):
    python .\\src\\scripts\\migrate_add_scope_columns.py
    python .\\src\\scripts\\migrate_add_scope_columns.py --dry-run
"""
import argparse
import sys

from sqlalchemy import text

try:
    from src import sop_models
except ImportError:  # running from inside src/
    import sop_models  # type: ignore


# (table, column) pairs to add.
COLUMNS = [
    ("tickets", "sec_cluster_field"),
    ("tickets", "sec_cluster_value"),
    ("clusters", "sec_cluster_field"),
    ("clusters", "sec_cluster_value"),
    ("sops", "sec_cluster_field"),
    ("sops", "sec_cluster_value"),
]

INDEXES = [
    ("ix_tickets_scope", "tickets"),
    ("ix_clusters_scope", "clusters"),
    ("ix_sops_scope", "sops"),
]


def column_exists(conn, table, column):
    row = conn.execute(
        text(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = :t AND column_name = :c"
        ),
        {"t": table, "c": column},
    ).first()
    return row is not None


def table_exists(conn, table):
    row = conn.execute(
        text("SELECT 1 FROM information_schema.tables WHERE table_name = :t"),
        {"t": table},
    ).first()
    return row is not None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="report only, change nothing")
    args = ap.parse_args()

    engine = sop_models.engine
    planned, skipped, missing_tables = [], [], []

    with engine.begin() as conn:
        # ---- columns -----------------------------------------------------
        for table, column in COLUMNS:
            if not table_exists(conn, table):
                if table not in missing_tables:
                    missing_tables.append(table)
                continue
            if column_exists(conn, table, column):
                skipped.append(f"{table}.{column}")
                continue
            planned.append(f"{table}.{column}")
            if not args.dry_run:
                conn.execute(
                    text(f"ALTER TABLE {table} ADD COLUMN {column} VARCHAR(255)")
                )

        # ---- indexes -----------------------------------------------------
        for index_name, table in INDEXES:
            if not table_exists(conn, table):
                continue
            if args.dry_run:
                planned.append(f"index {index_name}")
                continue
            conn.execute(
                text(
                    f"CREATE INDEX IF NOT EXISTS {index_name} "
                    f"ON {table} (sec_cluster_field, sec_cluster_value)"
                )
            )
            planned.append(f"index {index_name}")

    # ---- report ----------------------------------------------------------
    print()
    if missing_tables:
        print("Tables not found (create the base schema first):")
        for table in missing_tables:
            print(f"  - {table}")
        print()

    if skipped:
        print("Already present, skipped:")
        for item in skipped:
            print(f"  - {item}")
        print()

    if planned:
        verb = "Would add" if args.dry_run else "Added"
        print(f"{verb}:")
        for item in planned:
            print(f"  - {item}")
    else:
        print("Nothing to do -- schema is already up to date.")

    print()
    if args.dry_run:
        print("Dry run: no changes were written.")
    else:
        print("Migration complete.")
        print()
        print("Verify with:")
        print("  SELECT table_name, column_name FROM information_schema.columns")
        print("  WHERE column_name LIKE 'sec_cluster%' ORDER BY table_name;")

    if missing_tables:
        sys.exit(1)


if __name__ == "__main__":
    main()
