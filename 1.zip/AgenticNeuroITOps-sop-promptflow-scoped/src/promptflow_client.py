import os
import logging
import requests
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


def _http_call_promptflow(flow_url: Optional[str], api_key: Optional[str], payload: Dict[str, Any], timeout: int = 60) -> Dict[str, Any]:
    """Call Promptflow via a simple HTTP POST to a configured endpoint."""
    endpoint = flow_url or os.getenv("PROMPTFLOW_URL")
    key = api_key or os.getenv("PROMPTFLOW_API_KEY")

    if not endpoint:
        return {"error": "PROMPTFLOW_URL not provided"}

    headers = {"Content-Type": "application/json"}
    if key:
        if key.strip().lower().startswith("bearer "):
            headers["Authorization"] = key
        else:
            headers["x-api-key"] = key

    try:
        resp = requests.post(endpoint, json=payload, headers=headers, timeout=timeout)
    except Exception as e:
        logger.exception("Error calling Promptflow endpoint")
        return {"error": f"Request failed: {str(e)}"}

    try:
        data = resp.json()
    except Exception:
        return {"error": "Invalid JSON response from Promptflow", "status_code": resp.status_code, "text": resp.text}

    if resp.status_code >= 400:
        return {"error": "Promptflow returned error", "status_code": resp.status_code, "response": data}

    return data


def _sdk_call_promptflow(flow_id: Optional[str], payload: Dict[str, Any], timeout: int = 60) -> Dict[str, Any]:
    """
    Attempt to call Promptflow using the Azure ML SDK (`azure.ai.ml.MLClient`).

    Requires these environment variables unless parameters are provided:
    - AZURE_SUBSCRIPTION_ID
    - AZURE_RESOURCE_GROUP
    - AZURE_WORKSPACE

    Notes:
    - The Azure SDK surface for Promptflow/flows may differ between versions.
      This function attempts several common method names (`invoke`, `run`, `create_run`).
    - If the required package isn't installed or the SDK doesn't expose a
      compatible method, a helpful error dict is returned.
    """
    try:
        from azure.identity import ManagedIdentityCredential
        from azure.ai.ml import MLClient
    except Exception as e:
        logger.exception("Azure ML SDK or azure-identity not available")
        return {"error": "azure-ai-ml or azure-identity not installed", "exc": str(e)}

    subscription_id = os.getenv("AZURE_SUBSCRIPTION_ID")
    resource_group = os.getenv("AZURE_RESOURCE_GROUP")
    workspace = os.getenv("AZURE_WORKSPACE")

    if not all([subscription_id, resource_group, workspace, flow_id]):
        return {"error": "Missing Azure config or flow_id. Set AZURE_SUBSCRIPTION_ID, AZURE_RESOURCE_GROUP, AZURE_WORKSPACE, and provide flow_id."}

    try:
        # Prefer a user-assigned managed identity if provided via env var.
        client_id = os.getenv("MANAGED_IDENTITY_CLIENT_ID") or os.getenv("AZURE_MANAGED_IDENTITY_CLIENT_ID")
        if client_id:
            cred = ManagedIdentityCredential(client_id=client_id)
        else:
            cred = ManagedIdentityCredential()

        # Try using the Promptflow PFClient first (if installed). This mirrors
        # the reference test: `from promptflow.azure import PFClient`.
        try:
            from promptflow.azure import PFClient

            pf_client = PFClient(
                subscription_id=subscription_id,
                resource_group_name=resource_group,
                workspace_name=workspace,
                credential=cred,
            )

            # Probe for invocation methods on PFClient or its `flows` helper.
            flows_client = getattr(pf_client, "flows", None)
            candidate_methods = []
            if flows_client is not None:
                for name in ("invoke", "run", "submit", "begin_invoke"):
                    if hasattr(flows_client, name):
                        candidate_methods.append((name, getattr(flows_client, name)))

            for name in ("invoke_flow", "invoke", "run_flow", "run"):
                if hasattr(pf_client, name):
                    candidate_methods.append((name, getattr(pf_client, name)))

            if candidate_methods:
                method_name, method = candidate_methods[0]
                logger.info("Calling Promptflow via PFClient SDK method %s", method_name)
                result = method(flow_id, payload)
            else:
                logger.info("PFClient present but no invocation method found; falling back to MLClient")
                raise RuntimeError("no-invoke-method")

        except Exception:
            # PFClient not available or failed to provide an invocation method; fall
            # back to azure.ai.ml.MLClient which some versions expose Promptflow flows.
            try:
                ml_client = MLClient(cred, subscription_id, resource_group, workspace)

                # Try common invocation method names; use the first one found.
                flows_client = getattr(ml_client, "flows", None)
                candidate_methods = []
                if flows_client is not None:
                    for name in ("invoke", "run", "create_run", "submit", "begin_invoke"):
                        if hasattr(flows_client, name):
                            candidate_methods.append((name, getattr(flows_client, name)))

                # Some SDK versions may expose top-level methods directly on ml_client
                for name in ("invoke_flow", "invoke", "run_flow"):
                    if hasattr(ml_client, name):
                        candidate_methods.append((name, getattr(ml_client, name)))

                if not candidate_methods:
                    return {"error": "No compatible Promptflow invocation method found in azure.ai.ml.MLClient. Please check azure-ai-ml version."}

                # Call the first compatible method
                method_name, method = candidate_methods[0]
                logger.info("Calling Promptflow via MLClient SDK method %s", method_name)

                # Many SDK methods are synchronous or return LRO objects; pass payload as-is
                result = method(flow_id, payload)

            except Exception as e:
                logger.exception("Error creating MLClient or invoking flow")
                return {"error": "Failed to create MLClient or invoke flow", "exc": str(e)}

        # If result has a `result()` method (LRO), try to wait/unwrap
        try:
            if hasattr(result, "result") and callable(result.result):
                res = result.result(timeout)
            else:
                res = result
        except Exception:
            res = result

        # Attempt to coerce to dict
        if isinstance(res, dict):
            return res
        try:
            import json
            return json.loads(res)
        except Exception:
            return {"raw_response": str(res)}

    except Exception as e:
        logger.exception("Error invoking Promptflow via SDK")
        return {"error": "SDK invocation failed", "exc": str(e)}


def call_promptflow(flow_url: Optional[str], api_key: Optional[str], payload: Dict[str, Any], timeout: int = 60, mode: str = "http", flow_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Unified entry point for calling Promptflow.

    mode: 'http' (default) or 'sdk'. If 'sdk', `flow_id` must be provided and
    azure environment variables for MLClient must be set.
    """
    if mode == "sdk":
        return _sdk_call_promptflow(flow_id, payload, timeout=timeout)
    return _http_call_promptflow(flow_url, api_key, payload, timeout=timeout)
