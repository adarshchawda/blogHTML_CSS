"""
Direct clustering manager without CrewAI dependency
"""
import os
import logging
import uuid
import numpy as np
from openai import AzureOpenAI
from ..sop_models import db, Cluster
from typing import Dict, List, Any
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.cluster import AgglomerativeClustering
from ..utils.llm_config import LLMConfigManager
from ..scope_config import (
    get_primary_cluster_fields,
    is_scoping_enabled,
    normalize_scope_field,
    scope_descriptor,
    scope_label,
)
import json

logger = logging.getLogger(__name__)

class ClusteringManager:
    """Simple clustering manager using KNN clustering directly"""
    
    def __init__(self):
        self.embedding_provider = None
        self.embedding_model = None
        self.api_key = None
        self.clustering_tool = None
        self.SIMILARITY_THRESHOLD = float(os.environ.get('SIMILARITY_THRESHOLD', '0.8'))
        # Primary clustering fields -- the text that gets embedded and compared.
        # Separate from the scope key: the scope key chooses WHICH partition to
        # search, these choose WHAT text is compared inside it. Override with
        # CLUSTER_FIELDS_PRIMARY without a code change.
        self.CLUSTER_FIELDS = get_primary_cluster_fields()
        self.HC_DISTANCE_THRESHOLD = float(os.environ.get('HC_DISTANCE_THRESHOLD', '0.2'))
        self.HC_AFFINITY = os.environ.get('HC_AFFINITY', 'cosine')
        self.HC_LINKAGE = os.environ.get('HC_LINKAGE', 'average')
        self.emb_modelid = os.environ.get('AZURE_OPENAI_EMBEDDING_MODEL', 'text-embedding-ada-002')
        
    def set_llm(self, provider=None, api_key=None, model=None, **kwargs):
        """
        Configure embedding provider for clustering
        
        Args:
            provider: Embedding provider (openai, azure, etc.)
            api_key: API key for embeddings
            model: Model name (optional, defaults handled by KNN)
            **kwargs: Additional config (Azure endpoint, api_version, deployment, embeddingModel, etc.)
        """
        self.embedding_provider = provider
        self.api_key = api_key
        self.embedding_model = model
        
        # Extract embedding-specific config from kwargs
        # For Azure, look for embeddingModel parameter
        if 'embeddingModel' in kwargs:
            self.embedding_model = kwargs.get('embeddingModel')
        
        # Store additional kwargs that might be needed
        self.embedding_kwargs = kwargs
        
        logger.info(f"Clustering configured with provider={provider}, model={self.embedding_model}")
        
    def incremental_cluster_tickets(self, tickets: List[Dict[str, Any]], clusters: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Cluster tickets incrementally using centroid-matching logic.

        - If `clusters` is empty, run agglomerative clustering to produce initial clusters.
        - If `clusters` is provided, match tickets to existing centroids and create new clusters when no match.
        """
        clusters = clusters or []
        self._log_cluster_config(clusters)

        try:
            if not clusters:
                return self.create_initial_clusters(tickets)
            return self.process_tickets_with_existing_clusters(tickets, clusters)
        except Exception as e:
            return self._handle_overall_error(tickets, e)

    # --- New agglomerative & batch helpers (inspired by new_clustering_manager.py)
    def get_ticket_text(self, ticket: Dict[str, Any], fields: List[str]) -> str:
        try:
            return ' '.join(str(ticket.get(f, '')) for f in fields if ticket.get(f))
        except Exception as e:
            logger.error(f"Error extracting ticket text for ticket {ticket.get('id')}: {e}", exc_info=True)
            raise ValueError("Failed to extract ticket text")

    def get_embeddings(self, tickets: List[Dict[str, Any]], fields: List[str]) -> np.ndarray:
        texts = [self.get_ticket_text(t, fields) for t in tickets]
        logger.info(f"Generating embeddings for {len(texts)} tickets using configured LLM provider.")

        # Resolve LLM/embedding configuration and set environment variables if needed
        try:
            llm_conf = LLMConfigManager.get_config()
            LLMConfigManager.set_environment_variables(llm_conf)
        except Exception:
            llm_conf = {}

        embedding_model = llm_conf.get('embedding_model') or llm_conf.get('embedding_deployment') or llm_conf.get('model') or os.environ.get('AZURE-OPENAI-EMBEDDING-MODEL') or self.emb_modelid

        client = AzureOpenAI(
            api_key=os.environ.get("OPENAI_API_KEY"),
            azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
            api_version=os.environ.get("OPENAI_API_VERSION")
            )

        resp = client.embeddings.create(
            model=embedding_model,  # MUST be deployment name
            input=texts
        )

        embeddings = [item.embedding for item in resp.data]
        return np.array(embeddings, dtype=np.float32)

    def get_similar_cluster_centroids(self, ticket_embedding: np.ndarray,
                                      sec_cluster_field: str = None,
                                      sec_cluster_value: str = None):
            """
            Fetch cluster centroids from DB and compute similarity in Python to
            avoid passing pgvector VECTOR objects into SQL parameters.

            THIS IS WHERE THE PARTITION BOUNDARY IS ENFORCED.

            When a scope is supplied, the query gains two predicates:

                AND sec_cluster_field = :sec_field
                AND sec_cluster_value = :sec_value

            Clusters belonging to any other partition are therefore never
            returned as candidates, so they can never win the similarity
            comparison and can never contribute their SOP to this ticket. That
            is the acceptance criterion 'data from one partition is never used
            to generate an SOP for a ticket belonging to another partition'.

            When no scope is supplied the original global behaviour is used
            unchanged, restricted to rows that are themselves unscoped so the
            two modes cannot bleed into each other.

            Returns: (cluster_ids, centroids_array, db_clusters_dict)
            """
            top_k = int(os.environ.get('CLUSTER_TOP_K', '3'))
            scoped = is_scoping_enabled(sec_cluster_field) and sec_cluster_value is not None

            try:
                query = (
                    db.session.query(Cluster.id, Cluster.embedding)
                    .filter(Cluster.embedding.isnot(None))
                )
                if scoped:
                    query = query.filter(
                        Cluster.sec_cluster_field == normalize_scope_field(sec_cluster_field),
                        Cluster.sec_cluster_value == sec_cluster_value,
                    )
                    logger.info(
                        'Similarity search restricted to partition [%s]',
                        scope_descriptor(sec_cluster_field, sec_cluster_value),
                    )
                else:
                    # Unscoped mode only ever competes against unscoped rows.
                    query = query.filter(Cluster.sec_cluster_field.is_(None))
                    logger.info('Similarity search running unscoped (global)')
                results = query.all()

                cluster_ids = []
                centroids = []
                db_clusters = {}

                logger.info(f"Fetched {len(results)} cluster rows with embeddings from DB")

                expected_dim = int(ticket_embedding.shape[0]) if hasattr(ticket_embedding, 'shape') and len(ticket_embedding.shape) > 0 else None
                skipped = 0
                for cid, emb in results:
                    try:
                        if emb is None:
                            skipped += 1
                            continue

                        # If stored as JSON string, parse it
                        if isinstance(emb, str):
                            try:
                                parsed = json.loads(emb)
                                arr = np.array(parsed, dtype=np.float32)
                            except Exception:
                                # Fallback: try simple comma-split of bracketed list
                                try:
                                    s = emb.strip()
                                    if s.startswith('[') and s.endswith(']'):
                                        parts = s[1:-1].split(',')
                                        arr = np.array([float(p) for p in parts], dtype=np.float32)
                                    else:
                                        raise ValueError('unparsable string')
                                except Exception:
                                    logger.warning(f"Skipping cluster {cid}: cannot parse string embedding")
                                    skipped += 1
                                    continue

                        elif hasattr(emb, 'tolist'):
                            arr = np.array(emb.tolist(), dtype=np.float32)
                        elif isinstance(emb, (list, tuple, np.ndarray)):
                            arr = np.array(emb, dtype=np.float32)
                        else:
                            try:
                                arr = np.array(emb, dtype=np.float32)
                            except Exception:
                                logger.warning(f"Skipping cluster {cid}: cannot convert embedding to array (type={type(emb)})")
                                skipped += 1
                                continue

                        # Validate dimensionality
                        if expected_dim is not None and arr.ndim == 1 and arr.shape[0] != expected_dim:
                            logger.warning(f"Skipping cluster {cid}: embedding dim {arr.shape[0]} != expected {expected_dim}")
                            skipped += 1
                            continue

                    except Exception as ex:
                        logger.warning(f"Skipping cluster {cid} due to unexpected error: {ex}")
                        skipped += 1
                        continue

                    cluster_ids.append(cid)
                    centroids.append(arr)
                    db_clusters[cid] = db.session.get(Cluster, cid)

                if not centroids:
                    logger.info(f"No centroids available after conversion; skipped={skipped}; returning empty set")
                    return ([], np.empty((0, 0)), {})

                centroids_matrix = np.vstack(centroids)
                logger.info(f"Prepared {len(centroids)} centroids; centroids_matrix shape={centroids_matrix.shape}")

                sims = cosine_similarity(ticket_embedding.reshape(1, -1), centroids_matrix)[0]
                logger.info(f"Computed similarities array shape={sims.shape}")

                top_indices = np.argsort(-sims)[:top_k]
                logger.info(f"Selected top indices: {top_indices}")

                sel_cluster_ids = [cluster_ids[i] for i in top_indices]
                sel_centroids = [centroids[i] for i in top_indices]
                sel_db_clusters = {cid: db_clusters[cid] for cid in sel_cluster_ids}

                return (sel_cluster_ids, np.vstack(sel_centroids), sel_db_clusters)

            except Exception as e:
                db.session.rollback()
                logger.error(f"Error in similarity search: {e}", exc_info=True)
                raise

    def _create_new_cluster(self, ticket: Dict[str, Any], embedding: List[float],
                            sec_cluster_field: str = None,
                            sec_cluster_value: str = None) -> Dict[str, Any]:
        """Create and persist one new cluster, tagged with its partition.

        The scope tags written here are what every later similarity lookup
        filters on, so a cluster created inside a partition stays confined to
        it for the rest of its life. The partition label is also prefixed onto
        the cluster name so two identical symptoms in different partitions
        produce visibly different clusters and SOP titles.
        """
        new_cluster_id = str(uuid.uuid4())
        scoped = is_scoping_enabled(sec_cluster_field) and sec_cluster_value is not None

        # Persist cluster in DB using `embedding` column (pgvector) — store as plain list
        emb_list = embedding.tolist() if hasattr(embedding, 'tolist') else list(embedding)

        base_name = ticket.get('short_description') or f"Cluster {new_cluster_id[:8]}"
        if scoped:
            cluster_name = f"[{scope_label(sec_cluster_value)}] {base_name}"[:255]
            cluster_obj = Cluster(
                id=new_cluster_id,
                name=cluster_name,
                embedding=emb_list,
                sec_cluster_field=normalize_scope_field(sec_cluster_field),
                sec_cluster_value=sec_cluster_value,
            )
        else:
            cluster_name = base_name[:255]
            cluster_obj = Cluster(
                id=new_cluster_id,
                name=cluster_name,
                embedding=emb_list,
            )
        try:
            db.session.add(cluster_obj)
            db.session.commit()
            logger.info(
                "Created new cluster %s in DB for ticket %s%s",
                new_cluster_id, ticket.get('id', 'unknown'),
                f" [partition: {scope_descriptor(sec_cluster_field, sec_cluster_value)}]" if scoped else "",
            )
        except Exception as e:
            db.session.rollback()
            logger.error(f"Failed to persist new cluster {new_cluster_id}: {e}", exc_info=True)

        new_cluster = {
            "id": new_cluster_id,
            "name": cluster_obj.name if cluster_obj is not None else cluster_name,
            "tickets": [ticket],
            "ticket_ids": [ticket.get('id', str(uuid.uuid4()))],
            "centroid": emb_list,
            "embedding_dimension": len(emb_list),
            # Carried through so the SOP layer tags the SOP with the same
            # partition without having to re-derive it.
            "sec_cluster_field": normalize_scope_field(sec_cluster_field) if scoped else None,
            "sec_cluster_value": sec_cluster_value if scoped else None,
        }

        return {"new_clusters": [new_cluster], "matched_clusters": {}, "warnings": []}

    def create_initial_clusters(self, tickets: list[dict],
                                sec_cluster_field: str = None,
                                sec_cluster_value: str = None) -> dict:
        """Bootstrap clusters for a partition that has none yet.

        Unscoped: identical to the original global behaviour.

        Scoped: `sec_cluster_value` names the ONE partition being bootstrapped,
        so embeddings and the agglomerative fit are computed over that
        partition's tickets only. Nothing from another partition is in scope.

        A partition holding a single ticket becomes a single cluster directly,
        because AgglomerativeClustering requires at least two samples. Without
        this, the first ticket of every new partition would be silently dropped
        and never receive an SOP.
        """
        scoped = is_scoping_enabled(sec_cluster_field) and sec_cluster_value is not None
        partition = scope_descriptor(sec_cluster_field, sec_cluster_value) if scoped else "unscoped"

        logger.info(
            "Bootstrapping %s with %d ticket(s) via AgglomerativeClustering...",
            f"partition [{partition}]" if scoped else "global cluster space",
            len(tickets),
        )

        matched_clusters = {}
        new_clusters = []
        warnings_list = []

        if not tickets:
            return {
                "analysis": {"total_tickets": 0, "matched_to_existing_clusters": 0,
                             "new_clusters_created": 0, "incremental": False},
                "matched_clusters": {}, "new_clusters": [], "warnings": [],
            }

        try:
            all_embeddings = self.get_embeddings(tickets, self.CLUSTER_FIELDS)
            logger.info(f"Generated embeddings with shape {all_embeddings.shape} for {len(tickets)} tickets.")
        except Exception as e:
            logger.error(f"Error generating embeddings for all tickets: {e}", exc_info=True)
            warnings_list.append(str(e))
            return {"error": str(e), "analysis": {"total_tickets": len(tickets), "matched_to_existing_clusters": 0, "new_clusters_created": 0, "incremental": False}, "matched_clusters": {}, "new_clusters": [], "warnings": warnings_list}

        # AgglomerativeClustering needs 2+ samples. A brand-new partition very
        # often arrives with exactly one ticket, so handle that directly rather
        # than bailing out and losing the ticket.
        if len(tickets) == 1:
            centroid = all_embeddings[0]
            cluster_dict = self._create_new_cluster(
                tickets[0], centroid, sec_cluster_field, sec_cluster_value
            )["new_clusters"][0]
            cluster_dict["tickets"] = [tickets[0]]
            cluster_dict["ticket_ids"] = [tickets[0].get("id")]
            cluster_dict["centroid"] = centroid
            new_clusters.append(cluster_dict)
            logger.info(
                "Single-ticket partition [%s] became cluster %s directly.",
                partition, cluster_dict["id"],
            )
            return {
                "analysis": {"total_tickets": 1, "matched_to_existing_clusters": 0,
                             "new_clusters_created": 1, "incremental": False},
                "matched_clusters": {}, "new_clusters": new_clusters, "warnings": warnings_list,
            }

        try:
            hc = AgglomerativeClustering(n_clusters=None, metric=self.HC_AFFINITY, linkage=self.HC_LINKAGE, distance_threshold=self.HC_DISTANCE_THRESHOLD)
            labels = hc.fit_predict(all_embeddings)
            logger.info(f"AgglomerativeClustering fit complete. Labels: {len(labels)}, unique: {len(set(labels))}")
        except Exception as e:
            logger.error(f"AgglomerativeClustering failed: {e}", exc_info=True)
            warnings_list.append(str(e))
            return {"error": str(e), "analysis": {"total_tickets": len(tickets), "matched_to_existing_clusters": 0, "new_clusters_created": 0, "incremental": False}, "matched_clusters": {}, "new_clusters": [], "warnings": warnings_list}

        label_to_indices = {}
        for idx, label in enumerate(labels):
            label_to_indices.setdefault(label, []).append(idx)

        for label, indices in label_to_indices.items():
            cluster_tickets = [tickets[idx] for idx in indices]
            cluster_ticket_ids = [tickets[idx].get('id') for idx in indices]
            centroid = all_embeddings[indices].mean(axis=0)
            if cluster_tickets:
                cluster_dict = self._create_new_cluster(
                    cluster_tickets[0], centroid, sec_cluster_field, sec_cluster_value
                )["new_clusters"][0]
                cluster_dict["tickets"] = cluster_tickets
                cluster_dict["ticket_ids"] = cluster_ticket_ids
                cluster_dict["centroid"] = centroid
                new_clusters.append(cluster_dict)

        analysis = {"total_tickets": len(tickets), "matched_to_existing_clusters": 0, "new_clusters_created": len(new_clusters), "incremental": False}
        return {"analysis": analysis, "matched_clusters": matched_clusters, "new_clusters": new_clusters, "warnings": warnings_list}

    def _match_within_batch(self, ticket_embedding, batch_clusters,
                            sec_cluster_field, sec_cluster_value):
        """Try to absorb a ticket into a cluster created earlier in this batch.

        Only clusters from the SAME partition are eligible. Without this filter a
        ticket could be absorbed into a cluster belonging to a different
        partition purely because both were created in the same request, which
        would defeat the whole boundary.

        Returns (index_into_batch_clusters, similarity) or (None, best_similarity).
        """
        if not batch_clusters:
            return None, 0.0

        target_field = normalize_scope_field(sec_cluster_field) if sec_cluster_field else None
        eligible = []
        for idx, cluster in enumerate(batch_clusters):
            if target_field is not None:
                if cluster.get("sec_cluster_field") != target_field:
                    continue
                if cluster.get("sec_cluster_value") != sec_cluster_value:
                    continue
            centroid = cluster.get("centroid")
            if centroid is None:
                continue
            try:
                arr = np.array(centroid, dtype=np.float32)
            except Exception:
                continue
            if arr.ndim != 1 or arr.shape[0] != ticket_embedding.shape[0]:
                continue
            eligible.append((idx, arr))

        if not eligible:
            return None, 0.0

        matrix = np.vstack([arr for _idx, arr in eligible])
        sims = cosine_similarity(ticket_embedding.reshape(1, -1), matrix)[0]
        best = int(np.argmax(sims))
        best_sim = float(sims[best])
        if best_sim > self.SIMILARITY_THRESHOLD:
            return eligible[best][0], best_sim
        return None, best_sim

    def process_tickets_with_existing_clusters(self, tickets: list[dict],
                                               sec_cluster_field: str = None,
                                               sec_cluster_value: str = None) -> dict:
        """Incrementally match tickets against clusters that already exist.

        For each ticket: fetch candidate centroids (restricted to the ticket's
        own partition when scoping is on), match by cosine similarity, update the
        matched centroid in the DB, or create a brand-new cluster when nothing in
        the partition is similar enough.

        That last branch matters. The acceptance criteria require that a ticket
        with no similar SOP inside its own partition gets a NEW SOP rather than
        borrowing one, so 'no match' must produce a cluster -- never a silent
        drop and never a fallback to the global cluster space.
        """
        scoped = is_scoping_enabled(sec_cluster_field) and sec_cluster_value is not None
        partition = scope_descriptor(sec_cluster_field, sec_cluster_value) if scoped else "unscoped"

        logger.info(
            "Incremental matching %s for %d ticket(s)...",
            f"inside partition [{partition}]" if scoped else "in global cluster space",
            len(tickets),
        )

        matched_clusters = {}
        new_clusters = []
        warnings_list = []

        if not tickets:
            return {
                "analysis": {"total_tickets": 0, "matched_to_existing_clusters": 0,
                             "new_clusters_created": 0, "incremental": True},
                "matched_clusters": {}, "new_clusters": [], "warnings": [],
            }

        try:
            all_embeddings = self.get_embeddings(tickets, self.CLUSTER_FIELDS)
            logger.info(f"Generated embeddings with shape {all_embeddings.shape} for {len(tickets)} tickets.")
        except Exception as e:
            logger.error(f"Error generating embeddings for tickets: {e}", exc_info=True)
            warnings_list.append(f"Error generating embeddings: {str(e)}")
            return {
                "error": f"Error generating embeddings: {str(e)}",
                "analysis": {"total_tickets": len(tickets), "matched_to_existing_clusters": 0, "new_clusters_created": 0, "incremental": True},
                "matched_clusters": {},
                "new_clusters": [],
                "warnings": warnings_list
            }

        for i, ticket in enumerate(tickets):
            ticket_ref = ticket.get('id') or ticket.get('number') or 'unknown'
            try:
                ticket_embedding = all_embeddings[i]
                match_cluster_id = None
                similarity_score = 0.0
                best_idx = None

                cluster_ids, centroids, db_clusters = self.get_similar_cluster_centroids(
                    ticket_embedding, sec_cluster_field, sec_cluster_value
                )

                if centroids.size > 0:
                    try:
                        sims = cosine_similarity(ticket_embedding.reshape(1, -1), centroids)[0]
                        best_idx = int(np.argmax(sims))
                        similarity_score = float(sims[best_idx])
                        if similarity_score > self.SIMILARITY_THRESHOLD:
                            match_cluster_id = cluster_ids[best_idx]
                            logger.info(
                                "Ticket %s matched cluster %s (similarity %.4f) in partition [%s]",
                                ticket_ref, match_cluster_id, similarity_score, partition,
                            )
                        else:
                            logger.info(
                                "Ticket %s best similarity %.4f is below threshold %.2f "
                                "inside partition [%s]",
                                ticket_ref, similarity_score, self.SIMILARITY_THRESHOLD, partition,
                            )
                    except Exception as e:
                        logger.error(
                            "Error computing similarity for ticket %s: %s", ticket_ref, e,
                            exc_info=True,
                        )
                        warnings_list.append(f"Error computing similarity for ticket {ticket_ref}: {str(e)}")

                if match_cluster_id:
                    # ---- matched an existing DB cluster: fold the ticket in ----
                    db_cluster = db_clusters.get(match_cluster_id)
                    try:
                        n = len(db_cluster.tickets) if db_cluster is not None else 1
                    except Exception:
                        n = 1
                    old_centroid = centroids[best_idx]
                    new_centroid = (old_centroid * n + ticket_embedding) / (n + 1)
                    if db_cluster is not None:
                        try:
                            db_cluster.embedding = new_centroid.tolist()
                            db.session.add(db_cluster)
                            db.session.commit()
                            logger.info("Updated centroid in DB for cluster %s", match_cluster_id)
                        except Exception as db_exc:
                            db.session.rollback()
                            logger.error(
                                "Failed to update centroid in DB for cluster %s: %s",
                                match_cluster_id, db_exc, exc_info=True,
                            )
                            warnings_list.append(
                                f"Failed to update centroid in DB for cluster {match_cluster_id}: {db_exc}"
                            )

                    entry = matched_clusters.setdefault(
                        match_cluster_id,
                        {"tickets": [], "similarity": [], "cluster": {}},
                    )
                    entry["tickets"].append(ticket)
                    entry["similarity"].append(similarity_score)
                    entry["sec_cluster_field"] = normalize_scope_field(sec_cluster_field) if scoped else None
                    entry["sec_cluster_value"] = sec_cluster_value if scoped else None
                    if db_cluster is not None:
                        entry["cluster"] = {
                            "id": match_cluster_id,
                            "name": getattr(db_cluster, "name", None) or f"Cluster {match_cluster_id}",
                            "centroid": new_centroid.tolist(),
                        }
                    continue

                # ---- no DB match: try clusters made earlier in THIS batch ----
                batch_idx, batch_sim = self._match_within_batch(
                    ticket_embedding, new_clusters, sec_cluster_field, sec_cluster_value
                )
                if batch_idx is not None:
                    target = new_clusters[batch_idx]
                    members = len(target.get("tickets", [])) or 1
                    old_centroid = np.array(target["centroid"], dtype=np.float32)
                    target["centroid"] = (
                        (old_centroid * members + ticket_embedding) / (members + 1)
                    ).tolist()
                    target.setdefault("tickets", []).append(ticket)
                    target.setdefault("ticket_ids", []).append(ticket.get("id"))
                    logger.info(
                        "Ticket %s joined in-batch cluster %s (similarity %.4f) in partition [%s]",
                        ticket_ref, target.get("id"), batch_sim, partition,
                    )
                    continue

                # ---- genuinely new: create a cluster so an SOP gets generated ----
                cluster_dict = self._create_new_cluster(
                    ticket, ticket_embedding, sec_cluster_field, sec_cluster_value
                )["new_clusters"][0]
                new_clusters.append(cluster_dict)
                logger.info(
                    "No similar cluster in partition [%s]; created new cluster %s for ticket %s",
                    partition, cluster_dict["id"], ticket_ref,
                )

            except Exception as e:
                logger.error("Error processing ticket %s: %s", ticket_ref, e, exc_info=True)
                warnings_list.append(f"Error processing ticket {ticket_ref}: {str(e)}")
                # Keep going: one bad ticket must not abort the whole partition.
                continue

        analysis = {
            "total_tickets": len(tickets),
            "matched_to_existing_clusters": sum(len(m.get('tickets', [])) for m in matched_clusters.values()),
            "new_clusters_created": len(new_clusters),
            "incremental": True
        }

        result = {
            "analysis": analysis,
            "matched_clusters": matched_clusters,
            "new_clusters": new_clusters,
            "warnings": warnings_list
        }
        logger.info(
            "Batch ticket processing complete for partition [%s]: %d matched, %d new cluster(s).",
            partition, analysis['matched_to_existing_clusters'], analysis['new_clusters_created'],
        )
        return result


# ---------------------------------------------------------------------------
# Helper Methods (Complexity Reduction)
# ---------------------------------------------------------------------------

    def _log_cluster_config(self, clusters):
            similarity_threshold = os.environ.get('SIMILARITY_THRESHOLD', '0.75')

            logger.info("Using incremental centroid-matching clustering with one-by-one ticket processing")
            logger.info("Clustering Configuration:")
            logger.info(f"  - Similarity Threshold: {similarity_threshold}")

            if not clusters:
                logger.info("No existing clusters available. Will create new clusters for first ticket.")
            else:
                logger.info(f"Found {len(clusters)} existing clusters for matching")

    # Clustering tool initializers removed — incremental clustering implemented directly
    def _log_ticket_progress(self, idx, tickets, ticket):
            logger.info(
                f"Processing ticket {idx+1}/{len(tickets)}: {ticket.get('id', 'unknown')}"
            )

    def _handle_new_clusters(self, single_result, ticket, new_clusters, working_clusters):
        new_list = single_result.get("new_clusters", [])
        for new_cluster in new_list:
            working_clusters.append(new_cluster)
            new_clusters.append(new_cluster)
            logger.info(
                f"Created new cluster {new_cluster.get('id')} "
                f"for ticket {ticket.get('id', 'unknown')}"
            )

    def _handle_matched_clusters(self, single_result, ticket, matched_clusters):
        matches = single_result.get("matched_clusters", {})

        for cluster_id, info in matches.items():
            if cluster_id not in matched_clusters:
                matched_clusters[cluster_id] = info
            else:
                matched_clusters[cluster_id]["tickets"].extend(info.get("tickets", []))

            similarity = info.get("similarity", 0)
            logger.info(
                f"Matched ticket {ticket.get('id','unknown')} to cluster {cluster_id} "
                f"with similarity {similarity:.4f}"
            )

    def _collect_warnings(self, single_result, warnings_list):
        warnings_list.extend(single_result.get("warnings", []))

    def _handle_ticket_error(self, ticket, error):
        msg = f"Error processing ticket {ticket.get('id', 'unknown')}: {str(error)}"
        logger.error(msg)
        return msg

    def _finalize_incremental_results(self, tickets, matched_clusters, new_clusters, warnings):
        total_matched = sum(
            len(m.get("tickets", [])) for m in matched_clusters.values()
        )

        logger.info("Incremental ticket processing complete")
        logger.info(f"Final results: {len(matched_clusters)} matched clusters, "
                    f"{len(new_clusters)} new clusters")

        analysis = {
            "total_tickets": len(tickets),
            "matched_to_existing_clusters": total_matched,
            "new_clusters_created": len(new_clusters),
            "incremental": True,
        }

        logger.info(
            f"Incremental clustering complete: "
            f"{analysis['matched_to_existing_clusters']} tickets matched, "
            f"{analysis['new_clusters_created']} new clusters created"
        )

        return {
            "analysis": analysis,
            "matched_clusters": matched_clusters,
            "new_clusters": new_clusters,
            "warnings": warnings,
        }

    def _handle_overall_error(self, tickets, error):
        logger.error(f"Error in incremental ticket clustering: {str(error)}")
        return {
            "error": f"Error during clustering: {str(error)}",
            "analysis": {"matched_to_sops": 0, "requiring_new_sops": 0},
            "matched_sop_groups": {},
            "new_sop_tickets": tickets,
        }
# ---------------------------------------------------------------------------
# Helper Methods Ends
# ---------------------------------------------------------------------------
_clustering_manager = None
def get_clustering_manager():
    """Get singleton clustering manager instance"""
    global _clustering_manager
    if _clustering_manager is None:
        _clustering_manager = ClusteringManager()
    return _clustering_manager
