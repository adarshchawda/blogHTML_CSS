"""
SOP Service - Business logic for SOP generation and ticket processing
"""
import os
import json
import uuid
import logging
import asyncio
from sqlalchemy.exc import IntegrityError
from sqlalchemy.sql.expression import insert
from datetime import datetime, timezone
try:
    from sop_models import db, SOP, Cluster, Ticket, cluster_ticket_mapping, db_session
    from promptflow_services.agent_manager import PromptflowManager
except ImportError:
    from .sop_models import db, SOP, Cluster, Ticket, cluster_ticket_mapping, db_session
    from .promptflow_services.agent_manager import PromptflowManager
from .utils.llm_config import LLMConfigManager
from .clustering.clustering_manager import get_clustering_manager
from .utils.servicenow_kb_client import create_kb_article, link_kb_article as sn_link_kb_article
from .scope_config import (
    build_scope_payload,
    get_configured_scope_field,
    group_tickets_by_scope_value,
    is_scoping_enabled,
    normalize_scope_field,
    parse_scope_fields,
    scope_descriptor,
    scope_label,
    scope_token,
    stamp_scope_on_tickets,
)
# Get logger
logger = logging.getLogger(__name__)


# Constants
KEY_NOT_SET = 'Not set'
KEY_SET_HIDDEN = 'Set (hidden)'
env_inilitialized = False

def _load_environment():
    """Load environment variables from Key Vault if not already loaded."""
    try:
        from load_env import load_env_from_keyvault
    except ImportError:
        from .load_env import load_env_from_keyvault

    global env_inilitialized

    if not env_inilitialized:
        load_env_from_keyvault()
        env_inilitialized = True


def _is_validator_enabled():
    """Return True if config.json enables the SOP validator."""
    try:
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
        with open(config_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        return bool(cfg.get('is_validator_enabled', False))
    except Exception:
        # If config cannot be read, default to False to avoid unexpected validator runs
        return False


def _serialize_embeddings(embeddings):
    """Serialize embeddings to JSON string"""
    if embeddings is None:
        return None
    try:
        # Convert numpy arrays to plain lists
        if hasattr(embeddings, 'tolist'):
            emb_list = embeddings.tolist()
        elif isinstance(embeddings, (list, tuple)):
            emb_list = embeddings
        else:
            # Fallback: try to iterate and convert
            emb_list = list(embeddings)
        if len(emb_list) == 0:
            return None
        return json.dumps(emb_list)
    except Exception as e:
        logger.warning("Could not serialize embeddings: %s", str(e))
        return None

def _insert_ticket_mappings(session, ticket_ids, cluster_id):
    """Insert ticket-cluster mappings into database"""
    from sqlalchemy.exc import IntegrityError
    from sqlalchemy.sql.expression import insert
    
    mapped = 0
    for ticket_id in ticket_ids:
        if not ticket_id:
            continue
        try:
            ticket = session.query(Ticket).filter_by(id=ticket_id).first()
            if not ticket:
                ticket = session.query(Ticket).filter_by(external_id=ticket_id).first()
 
            if not ticket:
                logger.warning("Ticket %s not found in database, skipping mapping", ticket_id)
                continue
            stmt = insert(cluster_ticket_mapping).values(cluster_id=cluster_id, ticket_id=ticket.id)
            session.execute(stmt)
            mapped += 1
        except IntegrityError:
            session.rollback()
            logger.warning("Duplicate mapping for ticket %s in cluster %s", ticket_id, cluster_id)
        except Exception as e:
            session.rollback()
            logger.error("Error creating mapping for ticket %s: %s", ticket_id, str(e))
    return mapped

async def _create_cluster_with_sop(group_tickets, cluster_id, cluster_name, ticket_ids, embeddings,
                                   sec_cluster_field=None, sec_cluster_value=None, **kwargs):
    """Helper method to create a cluster with SOP and add it to the database
    
    Args:
        group_tickets (list): List of tickets in this cluster
        cluster_id (str): Unique ID for the cluster
        cluster_name (str): Name for the cluster
        ticket_ids (list): List of ticket IDs in this cluster
        embeddings (list): Embedding vector for the cluster centroid
        
    Returns:
        tuple: (sop_id, sop_path, cluster)
    """
    sop_id = None
    sop_path = None

    scoped = is_scoping_enabled(sec_cluster_field) and sec_cluster_value is not None
    logger.info(
        "Creating cluster %s ('%s') with %d ticket(s)%s",
        cluster_id, cluster_name, len(ticket_ids),
        f" [partition: {scope_descriptor(sec_cluster_field, sec_cluster_value)}]" if scoped else "",
    )

    try:
        sop = await generate_sop(
            tickets=group_tickets,
            cluster_name=cluster_name,
            clustering_analysis={},  # Default empty analysis
            ticket_ids=ticket_ids,
            sec_cluster_field=sec_cluster_field,
            sec_cluster_value=sec_cluster_value,
            **kwargs
        )
        if sop and 'sop_id' in sop:
            sop_id = sop['sop_id']
            sop_path = sop['filepath']
            logger.info("Generated SOP with ID %s", sop_id)
    except Exception as e:
        logger.error("Error generating SOP: %s", str(e))

    # Convert embeddings to plain list (pgvector expects numeric sequence)
    emb_value = None
    if embeddings is not None:
        try:
            if hasattr(embeddings, 'tolist'):
                emb_value = embeddings.tolist()
            elif isinstance(embeddings, str):
                # Try to parse JSON string
                try:
                    parsed = json.loads(embeddings)
                    emb_value = list(parsed) if parsed is not None else None
                except Exception:
                    emb_value = None
            else:
                emb_value = list(embeddings)
        except Exception:
            emb_value = None

    session = db_session()
    try:
        # If cluster id already exists, reuse it to avoid unique constraint errors
        existing = session.query(Cluster).filter_by(id=cluster_id).first()
        if existing:
            logger.info("Cluster %s already exists. Attaching SOP and scope tags.", cluster_id)
            new_cluster = existing
            # The clustering layer inserts the row without a sop_id, so the
            # common path here is: find that row and complete it.
            try:
                if scoped and not existing.sec_cluster_field:
                    existing.sec_cluster_field = normalize_scope_field(sec_cluster_field)
                if scoped and not existing.sec_cluster_value:
                    existing.sec_cluster_value = sec_cluster_value
                if sop_id and not existing.sop_id:
                    existing.sop_id = sop_id
                session.add(existing)
                session.flush()
            except Exception:
                session.rollback()
            # Update embedding if provided and missing on existing
            try:
                if emb_value and (not getattr(existing, 'embedding', None)):
                    existing.embedding = emb_value
                    session.add(existing)
                    session.flush()
            except Exception:
                session.rollback()
        else:
            new_cluster = Cluster(
                id=cluster_id,
                name=cluster_name[:255],
                description=f"Cluster with {len(ticket_ids)} tickets",
                is_test_cluster=False,
                sop_id=sop_id,
                embedding=emb_value,
                sec_cluster_field=normalize_scope_field(sec_cluster_field) if scoped else None,
                sec_cluster_value=sec_cluster_value if scoped else None,
            )
            session.add(new_cluster)
            session.flush()  # Flush to get the ID without committing

        # Insert mappings using extracted helper
        _insert_ticket_mappings(session, ticket_ids, cluster_id)

        # Commit the transaction
        session.commit()
        logger.info("Successfully created cluster %s with %d ticket mappings", cluster_id, len(ticket_ids))

        # Eagerly load any relationships that might be needed later
        if hasattr(new_cluster, 'tickets'):
            _ = new_cluster.tickets  # This will load the tickets into the session

        # Detach the object from the session but keep the loaded attributes
        session.expunge(new_cluster)

        return sop_id, sop_path, new_cluster

    except Exception as e:
        # Rollback in case of error
        session.rollback()
        logger.error("Error creating cluster or mappings: %s", str(e))
        raise
    finally:
        # Close the session
        session.close()


def _save_tickets_to_db(session, tickets):
    """Save ticket data to database."""
    db_tickets = []
    for ticket_data in tickets:
        ticket = Ticket(
            id=str(uuid.uuid4()),
            external_id=ticket_data.get('number'),
            title=ticket_data.get('short_description', ''),
            short_description=ticket_data.get('short_description', ''),
            description=ticket_data.get('description', ''),
            status=ticket_data.get('state', 'New'),
            priority=ticket_data.get('priority', 'Medium'),
            category=ticket_data.get('category'),
            subcategory=ticket_data.get('subcategory'),
            assigned_to=ticket_data.get('assigned_to', ''),
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            additional_data=json.dumps(ticket_data, default=str),
            sec_cluster_field=ticket_data.get('sec_cluster_field'),
            sec_cluster_value=ticket_data.get('sec_cluster_value'),
        )
        session.add(ticket)
        db_tickets.append(ticket)
    session.commit()
    return db_tickets


def _normalize_clustering_results(cluster_result):
    """Convert matched/new clusters into unified ticket_groups format."""
    ticket_groups_list = []
    
    # Add matched clusters
    for cluster_id, match_info in cluster_result.get('matched_clusters', {}).items():
        cluster = match_info.get('cluster', {}) or {}
        actual_id = cluster_id or cluster.get('id') or match_info.get('cluster_id')
        if not actual_id:
            # Defensive: a null key here used to mean 'no match found', which
            # silently swallowed the ticket. The clustering layer no longer
            # produces it, but drop it loudly rather than process garbage.
            logger.warning("Skipping matched cluster entry with no resolvable ID")
            continue
        ticket_groups_list.append({
            'id': actual_id,
            'name': cluster.get('name', f"Cluster {actual_id}"),
            'tickets': match_info.get('tickets', []),
            'embeddings': cluster.get('centroid', ''),
            'is_matched': True,
            'similarity_score': match_info.get('similarity', 0),
            'sec_cluster_field': match_info.get('sec_cluster_field'),
            'sec_cluster_value': match_info.get('sec_cluster_value'),
        })

    # Add new clusters
    for cluster in cluster_result.get('new_clusters', []):
        original_id = cluster.get('id')
        ticket_groups_list.append({
            'id': original_id,
            'name': cluster.get('name', "New Cluster"),
            'tickets': cluster.get('tickets', []),
            'embeddings': cluster.get('centroid', ''),
            'is_matched': False,
            'similarity_score': 0.0,
            'original_id': original_id,
            'sec_cluster_field': cluster.get('sec_cluster_field'),
            'sec_cluster_value': cluster.get('sec_cluster_value'),
        })
    
    logger.info("Normalized %d cluster groups", len(ticket_groups_list))
    return ticket_groups_list


def _separate_cluster_groups(ticket_groups_list):
    """Separate groups into new and matched lists."""
    new_groups = []
    matched_groups = []
    for group in ticket_groups_list:
        if isinstance(group, dict) and group.get('tickets'):
            if group.get('is_matched'):
                matched_groups.append(group)
            else:
                new_groups.append(group)
    logger.info("Separated into %d new and %d matched groups", len(new_groups), len(matched_groups))
    return new_groups, matched_groups


def _extract_ticket_ids_from_group(group):
    """Extract ticket IDs from a group."""
    group_tickets = group.get('tickets', [])
    return [t.get('ticket_id') or t.get('number') for t in group_tickets if isinstance(t, dict)]

async def _process_new_cluster_group(group, matched_cluster_groups, session, results, processed_ticket_ids, kwargs):
    """Process a new cluster group: create SOP and DB record."""
    ticket_ids = _extract_ticket_ids_from_group(group)
    original_id = group.get('id')
    
    matched_group = next((mg for mg in matched_cluster_groups if mg.get('id') == original_id), None)
    if matched_group:
        matched_ids = _extract_ticket_ids_from_group(matched_group)
        ticket_ids = list(set(ticket_ids + matched_ids))
    
    cluster_id = group.get('id') or str(uuid.uuid4())
    cluster_name = group.get('name') or f"Cluster {cluster_id[:6]}"
    embeddings = group.get('embeddings')
    group_tickets = group.get('tickets', [])
    sec_cluster_field = group.get('sec_cluster_field')
    sec_cluster_value = group.get('sec_cluster_value')

    logger.info("Creating new cluster %s with %d ticket(s)", cluster_id, len(ticket_ids))

    try:
        sop_id, sop_path, new_cluster = await _create_cluster_with_sop(
            group_tickets, cluster_id, cluster_name, ticket_ids, embeddings,
            sec_cluster_field, sec_cluster_value, **kwargs
        )
        
        if new_cluster:
            try:
                for ticket_id in ticket_ids:
                    db_ticket = session.query(Ticket).filter_by(external_id=ticket_id).first()
                    if db_ticket:
                        results.append({
                            'ticket_id': db_ticket.external_id,
                            'ticket_summary': db_ticket.title,
                            'cluster_id': cluster_id,
                            'cluster_name': cluster_name,
                            'sop_document_path': sop_path,
                            'status': 'Created',
                            'sop_id': sop_id,
                            'matched_to_existing_sop': False,
                            'similarity_score': 0.0,
                            'original_id': original_id,
                            'sec_cluster_field': sec_cluster_field,
                            'sec_cluster_value': sec_cluster_value,
                        })
                        new_cluster.tickets.append(db_ticket)
                        processed_ticket_ids.add(db_ticket.external_id)
                session.commit()
            except Exception as e:
                session.rollback()
                logger.error("Error processing tickets in new cluster: %s", str(e))
                raise
            return cluster_id, new_cluster
    except Exception as e:
        logger.error("Error creating new cluster: %s", str(e))
        raise
    
    return None, None

async def _process_matched_cluster_group(group, results, processed_ticket_ids, kwargs):

    """Process a matched cluster group: link to existing cluster."""

    ticket_ids = _extract_ticket_ids_from_group(group)

    matched_cluster_id = group.get('id')

    similarity_score = group.get('similarity_score', 0.0)
    # Coerce similarity_score to a single float for logging and result output
    try:
        if isinstance(similarity_score, (list, tuple)):
            sim_val = float(sum(similarity_score) / len(similarity_score)) if len(similarity_score) > 0 else 0.0
        else:
            sim_val = float(similarity_score)
    except Exception:
        try:
            import numpy as _np
            sim_val = float(_np.mean(similarity_score))
        except Exception:
            sim_val = 0.0

    logger.info("Processing matched cluster %s with similarity %.2f", matched_cluster_id, sim_val)

    # Use a fresh session instance from the PGSession wrapper so we can

    # persist mappings and update SOP records as needed.

    session = db_session()

    try:

        existing_cluster = session.query(Cluster).filter_by(id=matched_cluster_id).first()

        if not existing_cluster:

            logger.warning("Matched cluster %s not found", matched_cluster_id)

            return

        # ---- Partition safety check -------------------------------------
        # The similarity query already restricts candidates to the ticket's
        # own partition, so a mismatch here should be impossible. Assert it
        # anyway: reusing an SOP across partitions is the exact defect this
        # feature exists to prevent, and failing loudly beats producing a
        # wrong SOP quietly.
        group_field = group.get('sec_cluster_field')
        group_value = group.get('sec_cluster_value')
        if group_field or existing_cluster.sec_cluster_field:
            if (existing_cluster.sec_cluster_field != group_field
                    or existing_cluster.sec_cluster_value != group_value):
                logger.error(
                    "REFUSING cross-partition SOP reuse: cluster %s belongs to "
                    "[%s=%s] but tickets resolved to [%s=%s]. Tickets: %s",
                    matched_cluster_id,
                    existing_cluster.sec_cluster_field, existing_cluster.sec_cluster_value,
                    group_field, group_value, ticket_ids,
                )
                return
 
        remaining_ticket_ids = [tid for tid in ticket_ids if tid not in processed_ticket_ids]

        if not remaining_ticket_ids:

            logger.info("All tickets for matched cluster %s already processed", matched_cluster_id)

            return
 
        cluster_id = existing_cluster.id

        cluster_name = existing_cluster.name

        sop_id = existing_cluster.sop_id

        sop_path = None
 
        # If there's a linked SOP, ensure we have an article_id before attempting to link.

        article_id = None

        if sop_id:

            sop = session.query(SOP).filter_by(id=sop_id).first()

            if sop:

                sop_path = getattr(sop, 'document_path', None)

                article_id = getattr(sop, 'article_id', None)
 
                # If ServiceNow integration is enabled and we don't have an article id,

                # attempt to create one and persist it to the SOP record.

                if not article_id and kwargs.get('servicenow_integration', False):

                    try:

                        try:

                            from utils.servicenow_kb_client import create_kb_article

                        except ImportError:

                            from .utils.servicenow_kb_client import create_kb_article
 
                        title = getattr(sop, 'title', f"SOP for {cluster_name}")

                        # Ensure we have SOP content available for validation; if the DB
                        # record doesn't contain the text, attempt to load from the
                        # `document_path` file using the helper.
                        sop_content = _retrieve_sop_content(sop)

                        # Run SOP validator and include its output in the ServiceNow KB request
                        validator_result = None
                        if _is_validator_enabled():
                            try:
                                try:
                                    from validator_agent import SOPValidator
                                except ImportError:
                                    from .validator_agent import SOPValidator

                                validator = SOPValidator()
                                validator_result =  await validator.validate_sop_async(sop_content)
                            except Exception as val_err:
                                logger.error("SOP validator error: %s", str(val_err))
                                validator_result = {"error": str(val_err)}

                        kb_result = create_kb_article(title=title, content=sop_content, validator_output=validator_result)

                        if kb_result.get('status') == 'success' and kb_result.get('article_id'):

                            article_id = kb_result.get('article_id')

                            sop.article_id = article_id

                            session.commit()

                            logger.info("Created ServiceNow KB article %s for SOP %s", article_id, sop_id)

                        else:

                            logger.error("Failed to create KB article for SOP %s: %s", sop_id, kb_result)

                    except Exception as kb_err:

                        logger.error("Error creating KB article for SOP %s: %s", sop_id, str(kb_err))
 
                # Only link if we have a valid article_id

                if article_id:

                    # Always retrieve SOP content first
                    content = _retrieve_sop_content(sop)
                    validator_output = None
                    if _is_validator_enabled():
                        try:
                            try:
                                from validator_agent import SOPValidator
                            except ImportError:
                                from .validator_agent import SOPValidator

                            validator = SOPValidator()
                            validator_output = await validator.validate_sop_async(content)

                        except Exception as val_err:
                            logger.error("Validator error during matched cluster linking: %s", str(val_err))
                            validator_output = {"error": str(val_err)}

                    link_kb_article(
                        article_id,
                        remaining_ticket_ids,
                        validator_output=validator_output,
                        **kwargs
                    )
 
        # Persist ticket<->cluster mappings to DB (idempotent)

        mapped = _insert_ticket_mappings(session, remaining_ticket_ids, cluster_id)

        logger.info("Inserted %d mappings for cluster %s", mapped, cluster_id)
 
        # Build result entries for each mapped ticket

        for ticket_id in remaining_ticket_ids:

            db_ticket = session.query(Ticket).filter_by(external_id=ticket_id).first()

            if db_ticket:

                try:

                    if db_ticket not in getattr(existing_cluster, 'tickets', []):

                        existing_cluster.tickets.append(db_ticket)

                except Exception:

                    # Non-fatal: keep going even if in-memory relationship can't be mutated

                    pass
 
                results.append({

                    'ticket_id': db_ticket.external_id,

                    'ticket_summary': db_ticket.title,

                    'cluster_id': cluster_id,

                    'cluster_name': cluster_name,

                    'sop_document_path': sop_path,

                    'status': 'Mapped',

                    'sop_id': sop_id,

                    'matched_to_existing_sop': True,

                    'similarity_score': sim_val,

                    'sec_cluster_field': existing_cluster.sec_cluster_field,

                    'sec_cluster_value': existing_cluster.sec_cluster_value,

                })

                processed_ticket_ids.add(db_ticket.external_id)
 
        session.commit()

    except Exception as e:

        try:

            session.rollback()

        except Exception:

            pass

        logger.error("Error processing matched cluster %s: %s", matched_cluster_id, str(e), exc_info=True)

        raise

    finally:

        try:

            session.close()

        except Exception:

            pass

async def process_tickets(tickets, **kwargs):
    """Entry point for clustering + SOP generation.

    DISPATCHER. Two mutually exclusive paths:

      scope key configured  -> process_tickets_scoped(), which partitions the
                               batch and enforces partition isolation.
      no scope key          -> the original global logic below, unchanged.

    The scope key comes from kwargs['sec_cluster_field'] (request body) or the
    SEC_CLUSTER_FIELD environment variable. Unset it to revert to the previous
    behaviour with no code change -- that is the rollback switch.
    """

    sec_cluster_field = get_configured_scope_field(kwargs.get('sec_cluster_field'))
    if is_scoping_enabled(sec_cluster_field):
        logger.info(
            "SCOPED clustering path active | scope key = '%s'",
            normalize_scope_field(sec_cluster_field),
        )
        scoped_kwargs = {k: v for k, v in kwargs.items() if k != 'sec_cluster_field'}
        return await process_tickets_scoped(tickets, sec_cluster_field, **scoped_kwargs)

    logger.info("UNSCOPED clustering path active (no scope key configured)")
    kwargs.pop('sec_cluster_field', None)

    session = db_session()
    
    try:
        
        # Step 1: Configure clustering manager
        clustering_manager = get_clustering_manager()

        # Step 2: Check for existing tickets
        ticket_count = session.query(Ticket).count()
        if ticket_count == 0:
            if len(tickets) < 2:
                warning_msg = "For Agglomerative Clustering, minimum 2 tickets are required to process."
                logger.warning(warning_msg)
                return {
                    "error": warning_msg,
                    "analysis": {"total_tickets": len(tickets), "matched_to_existing_clusters": 0, "new_clusters_created": 0, "incremental": False},
                    "matched_clusters": {},
                    "new_clusters": [],
                    "warnings": [warning_msg]
                }
            
            logger.info("No records found in tickets table. Saving incoming tickets.")
            db_tickets = _save_tickets_to_db(session, tickets)
            # for ticket in tickets:
            #     service_now_connector.update_record(ticket['number'])
            logger.info("Saved %d tickets to database", len(db_tickets))
            # Call create_initial_clusters (implementing AgglomerativeClustering)
            cluster_result = clustering_manager.create_initial_clusters(tickets)
            
        else:
            logger.info(" Appending new records to tickets table")
            db_tickets = _save_tickets_to_db(session, tickets)
            # for ticket in tickets:
            #     service_now_connector.update_record(ticket['number'])
            logger.info("Saved %d tickets to database", len(db_tickets))
            logger.info("Creating clusters using incremental approach")
            cluster_result = clustering_manager.process_tickets_with_existing_clusters(tickets)

        if not cluster_result or ('matched_clusters' not in cluster_result and 'new_clusters' not in cluster_result):
            return {'status': 'success', 'message': 'No clusters were found.', 'results': []}, 200
        
        # Step 3: Normalize clustering results
        ticket_groups_list = _normalize_clustering_results(cluster_result)

        # Step 4: Separate into new and matched
        new_groups, matched_groups = _separate_cluster_groups(ticket_groups_list)
        
        # Step 5: Process groups
        results = []
        processed_ticket_ids = set()
        
        logger.info("Processing %d new cluster groups", len(new_groups))
        for group in new_groups:
            await _process_new_cluster_group(group, matched_groups, session, results, processed_ticket_ids, kwargs)
        
        logger.info("Processing %d matched cluster groups", len(matched_groups))
        for group in matched_groups:
            await _process_matched_cluster_group(group, results, processed_ticket_ids, kwargs)

        session.close()
        
        # Step 6 Return results
        unique_cluster_ids = len({r['cluster_id'] for r in results if 'cluster_id' in r})
        return {
            'status': 'success',
            'message': f'Processed {len(tickets)} tickets into {unique_cluster_ids} clusters',
            'results': results
        }
        
    except ValueError as ve:
        logger.error("Configuration error: %s", str(ve))
        return {'status': 'error', 'message': str(ve)}, 400
    except ConnectionError as ce:
        logger.error("MCP server connection error: %s", str(ce))
        return {'status': 'error', 'message': 'MCP server is not running or not accessible. Please start the MCP server.', 'results': []}, 503
    except Exception as e:
        logger.error("Error processing tickets: %s", str(e), exc_info=True)
        if 'session' in locals():
            session.rollback()
            session.close()
        return {'status': 'error', 'message': f'Error: {str(e)}', 'results': []}, 500


def link_kb_article(article_id, ticket_ids=None, validator_output=None, **kwargs):
    """link KB Article in service Now"""
    servicenow_integration = kwargs.get('servicenow_integration', False)
    if servicenow_integration:
        try:
            try:
                from utils.servicenow_kb_client import link_kb_article as sn_link_kb_article
            except ImportError:
                from .utils.servicenow_kb_client import link_kb_article as sn_link_kb_article
            # Normalize to a list of incident IDs
            ids = []
            if isinstance(ticket_ids, list):
                ids = [tid for tid in ticket_ids if tid]
            elif isinstance(ticket_ids, str) and ticket_ids:
                ids = [ticket_ids]
            # Link for each incident individually
            for inc_id in ids:
                kb_result = sn_link_kb_article(
                    article_id=article_id,
                    incident_id=inc_id,
                    validator_output=validator_output
                )
                if kb_result.get('status') == 'success':
                    logger.info(f"Linked ServiceNow KB article {article_id} to incident {inc_id}")
                else:
                    logger.error(f"Failed to link KB article {article_id} to incident {inc_id}: {kb_result}")
                
        except Exception as kb_error:
            logger.error(f"Error creating ServiceNow KB article: {str(kb_error)}")
            # Don't fail the SOP generation if KB article creation fails


def _validate_sop_input(tickets):
    """Validate SOP generation input."""
    if not tickets:
        raise ValueError("No tickets provided for SOP generation")
    logger.info("Ticket Info for SOP generation: %d tickets", len(tickets))


def _get_llm_config_for_sop(kwargs):
    """Retrieve and validate LLM configuration for SOP."""
    try:
        from utils.llm_config import LLMConfigManager
    except ImportError:
        from .utils.llm_config import LLMConfigManager
    llm_config = LLMConfigManager.get_config(kwargs)
    provider = llm_config['llm_provider']
    api_key = llm_config['api_key']
    
    if not api_key:
        raise ValueError(f'No API key available for {provider}. Please provide an API key in the LLM settings UI.')
    
    safe_config = {k: v for k, v in llm_config.items() if k != 'api_key'}
    safe_config['api_key'] = KEY_SET_HIDDEN if api_key else KEY_NOT_SET
    logger.info("LLM Configuration: %s", safe_config)
    return llm_config


async def _generate_sop_with_promptflow(promptflow_manager, tickets, cluster_name, scope_payload=None):
    """Generate SOP content using the Promptflow manager.

    `scope_payload` is embedded in the flow input so the generated SOP text is
    explicitly about this partition. Without it, two partitions with identical
    symptoms would produce word-for-word identical SOPs.
    """
    try:
        if asyncio.iscoroutinefunction(promptflow_manager._generate_sop_async):
            return await promptflow_manager._generate_sop_async(tickets, cluster_name, scope_payload)
        else:
            return promptflow_manager._generate_sop_async(tickets, cluster_name, scope_payload)
    except RuntimeError as e:
        if "asyncio.run() cannot be called from a running event loop" in str(e):
            logger.info("Nested event loop detected, using asyncio.create_task")
            loop = asyncio.get_running_loop()
            task = loop.create_task(
                promptflow_manager._generate_sop_async(tickets, cluster_name, scope_payload)
            )
            return await asyncio.wait_for(task, timeout=300)
        raise RuntimeError(f"Error generating SOP with Promptflow manager: {str(e)}") from e
    except Exception as e:
        raise RuntimeError(f"Unexpected error generating SOP: {str(e)}") from e


def _save_sop_file(sop_id, sop_content):
    """Save SOP content to file and return filepath."""
    sop_filepath = f"sops/{sop_id}.md"
    os.makedirs(os.path.dirname(sop_filepath), exist_ok=True)
    with open(sop_filepath, 'w', encoding='utf-8') as f:
        f.write(sop_content)
    return sop_filepath


def _persist_sop_to_db(sop_id, sop_title, sop_content, sop_filepath,
                       sec_cluster_field=None, sec_cluster_value=None):
    """Create and persist the SOP record, tagged with its partition.

    AC: 'All SOP records in the DB are tagged with the configured scope-key
    type and value.' The tags live on the sops row itself rather than only
    being reachable through clusters.sop_id, so an SOP can be audited or
    queried by partition directly.
    """
    scoped = is_scoping_enabled(sec_cluster_field) and sec_cluster_value is not None
    sop_db = SOP(
        id=sop_id,
        title=sop_title,
        content=sop_content,
        document_path=sop_filepath,
        created_at=datetime.now(),
        sec_cluster_field=normalize_scope_field(sec_cluster_field) if scoped else None,
        sec_cluster_value=sec_cluster_value if scoped else None,
    )
    db_session.add(sop_db)
    db_session.flush()
    return sop_db


def _retrieve_sop_content(sop):
    """Return SOP content from DB record or load from `document_path` file if content is empty.

    This ensures validator has the SOP text even when `SOP.content` was not stored in DB.
    """
    if not sop:
        return ''

    # Prefer stored content if present
    content = getattr(sop, 'content', '') or ''
    if content and content.strip():
        return content

    # Try loading from document_path
    doc_path = getattr(sop, 'document_path', None)
    if not doc_path:
        return content

    try:
        # If relative path, try common locations: repo root and file-relative
        candidates = []
        if os.path.isabs(doc_path):
            candidates.append(doc_path)
        else:
            # file-relative (src/..)
            base = os.path.dirname(__file__)
            candidates.append(os.path.normpath(os.path.join(base, '..', doc_path)))
            # cwd (likely repo root)
            candidates.append(os.path.normpath(os.path.join(os.getcwd(), doc_path)))

        for p in candidates:
            if p and os.path.exists(p):
                try:
                    with open(p, 'r', encoding='utf-8') as f:
                        text = f.read()
                        if text and text.strip():
                            return text
                except Exception as e:
                    logger.warning("Failed to read SOP file %s: %s", p, str(e))
    except Exception as e:
        logger.warning("Error retrieving SOP content for SOP %s: %s", getattr(sop, 'id', 'unknown'), str(e))

    return content


async def _integrate_with_servicenow_kb(sop_db, sop_title, sop_content, ticket_ids, kwargs,
                                        sec_cluster_field=None, sec_cluster_value=None):
    """Create the KB article and link it to each incident.

    This is the step that actually puts the SOP on the ServiceNow incident.
    The partition descriptor is prepended to the article body so an L1/L2
    reading the KB article can see which partition it was generated for and
    never applies a Retail Banking SOP to an Insurance incident.
    """
    if not kwargs.get('servicenow_integration', False):
        logger.info('ServiceNow integration disabled; skipping KB article creation.')
        return

    scoped = is_scoping_enabled(sec_cluster_field) and sec_cluster_value is not None
    if scoped:
        descriptor = scope_descriptor(sec_cluster_field, sec_cluster_value)
        sop_content = (
            f"> **Partition scope:** {descriptor}  \n"
            f"> **Scope key:** `{normalize_scope_field(sec_cluster_field)}` = "
            f"`{sec_cluster_value}`\n\n"
            f"{sop_content}"
        )
    
    try:
        try:
            from utils.servicenow_kb_client import create_kb_article, link_kb_article as sn_link_kb_article
        except ImportError:
            from .utils.servicenow_kb_client import create_kb_article, link_kb_article as sn_link_kb_article

        # Run validator and attach output to ServiceNow KB article as `u_validator_output`
        validator_result = None
        if _is_validator_enabled():
            try:
                try:
                    from validator_agent import SOPValidator
                except ImportError:
                    from .validator_agent import SOPValidator

                validator = SOPValidator()
                validator_result = await validator.validate_sop_async(sop_content)
            except Exception as val_err:
                logger.error("SOP validator error: %s", str(val_err))
                validator_result = {"error": str(val_err)}

        # Call blocking HTTP client in thread executor to avoid blocking event loop
        kb_result = await asyncio.to_thread(
            create_kb_article,
            sop_title,
            sop_content,
            None,
            validator_result
        )

        if kb_result.get('status') == 'success' and kb_result.get('article_id'):
            article_id = kb_result.get('article_id')
            logger.info(
                "Created ServiceNow KB article %s%s", article_id,
                f" for partition [{scope_descriptor(sec_cluster_field, sec_cluster_value)}]" if scoped else "",
            )
            sop_db.article_id = article_id
            db_session.commit()

            linked, failed = 0, 0
            for inc_id in (ticket_ids or []):
                if not inc_id:
                    continue
                try:
                    link_result = await asyncio.to_thread(
                        sn_link_kb_article,
                        article_id=article_id,
                        incident_id=inc_id,
                        validator_output=validator_result
                    )
                    if isinstance(link_result, dict) and link_result.get('status') != 'success':
                        failed += 1
                        logger.error(
                            "ServiceNow rejected linking KB %s to incident %s: %s",
                            article_id, inc_id, link_result,
                        )
                    else:
                        linked += 1
                        logger.info("Attached KB article %s to incident %s", article_id, inc_id)
                except Exception as link_err:
                    failed += 1
                    logger.error(
                        "Failed to link KB article %s to incident %s: %s",
                        article_id, inc_id, str(link_err),
                    )
            logger.info(
                "KB article %s attached to %d incident(s), %d failure(s)",
                article_id, linked, failed,
            )
        else:
            logger.error("Failed to create ServiceNow KB article: %s", kb_result)
    except Exception as kb_error:
        logger.error("Error creating/linking ServiceNow KB article: %s", str(kb_error))


async def generate_sop(tickets, cluster_name='Unnamed Cluster', ticket_ids=None,
                       sec_cluster_field=None, sec_cluster_value=None, **kwargs):
    """Generate a Standard Operating Procedure (SOP) for a cluster of tickets.
    
    Refactored to reduce cognitive complexity by delegating to focused helper functions.
    """
    try:
        # Step 1: Validate and retrieve LLM configuration
        llm_config = _get_llm_config_for_sop(kwargs)
        provider = llm_config['llm_provider']
        api_key = llm_config['api_key']
        model = llm_config['model']
        
        # Step 2: Validate input
        _validate_sop_input(tickets)
        
        # Step 3: Initialize and configure Promptflow manager
        promptflow_manager = PromptflowManager()
        filtered_config = {k: v for k, v in llm_config.items() 
                          if k not in ['llm_provider', 'api_key', 'model']}
        promptflow_manager.set_llm(provider=provider, api_key=api_key, model=model, **filtered_config)
        logger.info("Promptflow manager configured with LLM provider: %s, model: %s", provider, model)
        
        # Step 4: Generate SOP content, scoped to this partition
        scoped = is_scoping_enabled(sec_cluster_field) and sec_cluster_value is not None
        scope_payload = build_scope_payload(sec_cluster_field, sec_cluster_value)
        cluster_id = str(uuid.uuid4())
        logger.info(
            "Starting SOP generation for cluster '%s' with %d ticket(s)%s",
            cluster_name, len(tickets),
            f" [partition: {scope_descriptor(sec_cluster_field, sec_cluster_value)}]" if scoped else "",
        )
        sop_content = await _generate_sop_with_promptflow(
            promptflow_manager, tickets, cluster_name, scope_payload
        )

        # Step 5: Generate metadata. The partition token goes into the title so
        # the same symptom in two partitions yields distinguishable SOP names
        # (SOP_RB_... vs SOP_INS_...) rather than two identical ones.
        sop_id = str(uuid.uuid4())
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if scoped:
            sop_title = f"SOP_{scope_token(sec_cluster_value)} | {cluster_name} - {timestamp}"
        else:
            sop_title = f"SOP for {cluster_name} - {timestamp}"
        sop_title = sop_title[:255]

        # Step 6: Save to file
        sop_filepath = _save_sop_file(sop_id, sop_content)

        # Step 7: Persist to database, tagged with the partition
        sop_db = _persist_sop_to_db(
            sop_id, sop_title, sop_content, sop_filepath,
            sec_cluster_field, sec_cluster_value,
        )
        db_session.commit()

        # Step 8: Create the KB article and attach it to each incident
        await _integrate_with_servicenow_kb(
            sop_db, sop_title, sop_content, ticket_ids, kwargs,
            sec_cluster_field, sec_cluster_value,
        )

        logger.info("SOP generated and saved with ID: %s", sop_id)
        return {
            'sop_id': sop_id,
            'sop_title': sop_title,
            'sop_content': sop_content,
            'cluster_id': cluster_id,
            'filepath': sop_filepath,
            'sec_cluster_field': normalize_scope_field(sec_cluster_field) if scoped else None,
            'sec_cluster_value': sec_cluster_value if scoped else None,
        }
        
    except ValueError as e:
        logger.error("Validation error in SOP generation: %s", str(e))
        raise
    except RuntimeError as e:
        logger.error("Runtime error in SOP generation: %s", str(e))
        raise
    except Exception as e:
        error_message = f"Unexpected error generating SOP: {str(e)}"
        logger.error(error_message, exc_info=True)
        try:
            db_session.rollback()
        except Exception as rollback_err:
            logger.error("Error during rollback: %s", str(rollback_err))
        raise RuntimeError(error_message) from e

def _extract_root_cause_text(field):
    """Extract string text from root cause field (handle dict or string)."""
    if field is None:
        return ''
    
    if isinstance(field, dict):
        try:
            return field.get('display_value', '') or field.get('value', '') or str(field)
        except Exception as e:
            logger.warning("Error extracting root cause text from dict: %s", str(e))
            return str(field)
    
    return str(field) if field else ''


def _filter_records_with_rca(records, min_length=10):
    """Filter records to include only those with meaningful RCA data."""
    filtered = []
    for record in records:
        root_cause = _extract_root_cause_text(record.get('u_root_cause') or record.get('root_cause'))
        if root_cause and len(root_cause.strip()) >= min_length:
            filtered.append(record)
    
    logger.info("Found %d records with RCA data out of %d total", len(filtered), len(records))
    return filtered



# ===========================================================================
# SCOPED (PARTITIONED) PROCESSING
# ===========================================================================

async def process_tickets_scoped(tickets, sec_cluster_field, **kwargs):
    """Partition-scoped orchestration. One partition at a time, start to finish.

    Per the user story, the order of operations for every ticket is:

      1. identify the ticket's scope-key value
      2. filter to that partition's clusters
      3. run the similarity search using the ticket meta details WITHIN that
         partition only
      4. match -> reuse that partition's SOP; no match -> generate a NEW SOP

    Concretely, for each distinct sec_cluster_value:

      a. persist that partition's tickets (tagged with the scope key)
      b. count existing clusters IN THAT PARTITION ONLY -- not globally, because
         a global count would send a brand-new partition down the incremental
         branch and its first ticket would never get a cluster or an SOP
      c. zero clusters -> bootstrap; some clusters -> incremental match
      d. merge that partition's result into the aggregate

    Then SOPs are generated for new clusters and reused for matched ones, and
    the KB article is attached to each incident.
    """
    session = db_session()
    canonical_field = normalize_scope_field(sec_cluster_field)

    try:
        clustering_manager = get_clustering_manager()

        # -- Step 1: identify every ticket's scope-key value -----------------
        tickets, na_tickets = stamp_scope_on_tickets(tickets, canonical_field)

        # -- Step 2: bucket the batch into partitions ------------------------
        partitions = group_tickets_by_scope_value(tickets, canonical_field)
        if not partitions:
            return {
                'status': 'success',
                'message': 'No tickets to process.',
                'results': [],
            }

        cluster_result = {'matched_clusters': {}, 'new_clusters': [], 'warnings': []}
        partition_errors = []

        for scope_value, partition_tickets in partitions.items():
            if not partition_tickets:
                continue

            descriptor = scope_descriptor(canonical_field, scope_value)
            logger.info(
                "=== Partition [%s]: %d ticket(s) ===",
                descriptor, len(partition_tickets),
            )

            try:
                # 2a: persist this partition's tickets
                _save_tickets_to_db(session, partition_tickets)

                # 2b: how many clusters already exist in THIS partition?
                existing_in_partition = (
                    session.query(Cluster)
                    .filter(
                        Cluster.sec_cluster_field == canonical_field,
                        Cluster.sec_cluster_value == scope_value,
                    )
                    .count()
                )

                # 2c: branch on the PER-PARTITION count
                if existing_in_partition == 0:
                    logger.info(
                        "[CLUSTERING] BOOTSTRAP for partition [%s] "
                        "(%d ticket(s)) | reason=no clusters in this partition",
                        descriptor, len(partition_tickets),
                    )
                    partition_result = clustering_manager.create_initial_clusters(
                        partition_tickets,
                        sec_cluster_field=canonical_field,
                        sec_cluster_value=scope_value,
                    )
                else:
                    logger.info(
                        "[CLUSTERING] INCREMENTAL match for partition [%s] "
                        "(%d ticket(s)) | %d existing cluster(s)",
                        descriptor, len(partition_tickets), existing_in_partition,
                    )
                    partition_result = clustering_manager.process_tickets_with_existing_clusters(
                        partition_tickets,
                        sec_cluster_field=canonical_field,
                        sec_cluster_value=scope_value,
                    )

                # 2d: merge into the aggregate, tagging for traceability
                if partition_result:
                    for _cid, _info in (partition_result.get('matched_clusters') or {}).items():
                        _info['sec_cluster_field'] = canonical_field
                        _info['sec_cluster_value'] = scope_value
                    for _new in (partition_result.get('new_clusters') or []):
                        _new.setdefault('sec_cluster_field', canonical_field)
                        _new.setdefault('sec_cluster_value', scope_value)
                    cluster_result['matched_clusters'].update(
                        partition_result.get('matched_clusters', {})
                    )
                    cluster_result['new_clusters'].extend(
                        partition_result.get('new_clusters', [])
                    )
                    cluster_result['warnings'].extend(
                        partition_result.get('warnings', [])
                    )

            except Exception as part_err:
                # One bad partition must not take the rest of the batch with it.
                logger.error(
                    "Partition [%s] failed during clustering: %s",
                    descriptor, part_err, exc_info=True,
                )
                partition_errors.append({'partition': scope_value, 'error': str(part_err)})
                try:
                    session.rollback()
                except Exception:
                    pass
                continue

        # -- Step 3: normalize + separate -----------------------------------
        ticket_groups_list = _normalize_clustering_results(cluster_result)
        new_groups, matched_groups = _separate_cluster_groups(ticket_groups_list)

        # -- Step 4: generate SOPs for new clusters, reuse for matched -------
        results = []
        processed_ticket_ids = set()

        logger.info("Processing %d new cluster group(s)", len(new_groups))
        for group in new_groups:
            try:
                await _process_new_cluster_group(
                    group, matched_groups, session, results, processed_ticket_ids, kwargs
                )
            except Exception as grp_err:
                # A Promptflow timeout in one partition must not block the KB
                # attach for every other partition in the batch.
                logger.error(
                    "New cluster group %s failed: %s",
                    group.get('id'), grp_err, exc_info=True,
                )
                partition_errors.append({
                    'partition': group.get('sec_cluster_value'),
                    'cluster_id': group.get('id'),
                    'error': str(grp_err),
                })

        logger.info("Processing %d matched cluster group(s)", len(matched_groups))
        for group in matched_groups:
            try:
                await _process_matched_cluster_group(
                    group, results, processed_ticket_ids, kwargs
                )
            except Exception as grp_err:
                logger.error(
                    "Matched cluster group %s failed: %s",
                    group.get('id'), grp_err, exc_info=True,
                )
                partition_errors.append({
                    'partition': group.get('sec_cluster_value'),
                    'cluster_id': group.get('id'),
                    'error': str(grp_err),
                })

        try:
            session.close()
        except Exception:
            pass

        # A cluster row can be written while its SOP generation failed --
        # _create_cluster_with_sop deliberately contains that error so the
        # cluster is not lost. Surface it here, otherwise the caller sees
        # 'success' for a ticket that never received an SOP.
        for entry in results:
            if entry.get('sop_id'):
                continue
            partition_errors.append({
                'partition': entry.get('sec_cluster_value'),
                'cluster_id': entry.get('cluster_id'),
                'ticket_id': entry.get('ticket_id'),
                'error': 'cluster created but SOP generation failed; '
                         'no KB article was attached to this incident',
            })

        unique_cluster_ids = len({r['cluster_id'] for r in results if 'cluster_id' in r})
        sop_count = len({r['sop_id'] for r in results if r.get('sop_id')})
        response = {
            'status': 'success' if not partition_errors else 'partial',
            'message': (
                f'Processed {len(tickets)} ticket(s) into {unique_cluster_ids} cluster(s) '
                f'and {sop_count} SOP(s) across {len(partitions)} partition(s)'
            ),
            'scope': {
                'sec_cluster_field': canonical_field,
                'scope_fields': parse_scope_fields(canonical_field),
                'partitions': {k: len(v) for k, v in partitions.items()},
                'na_partition_tickets': na_tickets,
            },
            'results': results,
            'warnings': cluster_result.get('warnings', []),
        }
        if partition_errors:
            response['errors'] = partition_errors
            logger.warning(
                "Completed with %d partition/group error(s); see 'errors' in the response.",
                len(partition_errors),
            )
        return response

    except ValueError as ve:
        logger.error("Scoped configuration error: %s", str(ve))
        return {'status': 'error', 'message': str(ve)}, 400
    except Exception as e:
        logger.error("Error in scoped ticket processing: %s", str(e), exc_info=True)
        try:
            session.rollback()
            session.close()
        except Exception:
            pass
        return {'status': 'error', 'message': f'Error: {str(e)}', 'results': []}, 500

