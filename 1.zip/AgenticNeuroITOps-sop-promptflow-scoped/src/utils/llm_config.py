"""
LLM Configuration Manager
------------------------
Central manager for all LLM configuration across the application.
Handles provider-specific settings, environment variables, and UI overrides.
"""

import os
import logging
import re

# Set up logging
logger = logging.getLogger(__name__)

class LLMConfigManager:
    """
    Centralized manager for LLM configurations.
    Handles standardized access to LLM provider settings with priority:
    1. UI-provided settings
    2. Environment variables
    3. Default values
    """
    
    # Standard provider name mappings
    PROVIDER_MAPPINGS = {
        'openai': ['openai', 'open-ai', 'open_ai'],
        'azure': ['azure', 'azure-openai', 'azure_openai', 'azureopenai'],
        'anthropic': ['anthropic', 'claude'],
        'cohere': ['cohere', 'co-here', 'co_here'],
    }
    
    # Default API versions
    DEFAULT_AZURE_API_VERSION = '2023-05-15'
    
    # Environment variable mappings
    ENV_MAPPINGS = {
        'openai': {
            'api_key': ['OPENAI_API_KEY'],
            'model': ['OPENAI_MODEL', 'DEFAULT_LLM_MODEL'],
        },
        'azure': {
            'api_key': ['AZURE_OPENAI_API_KEY', 'OPENAI_API_KEY'],
            'endpoint': ['AZURE_OPENAI_ENDPOINT', 'OPENAI_API_BASE'],
            'deployment': ['AZURE_OPENAI_DEPLOYMENT', 'AZURE_DEPLOYMENT_ID', 'DEPLOYMENT_NAME'],
            'api_version': ['AZURE_API_VERSION', 'OPENAI_API_VERSION'],
        },
        'anthropic': {
            'api_key': ['ANTHROPIC_API_KEY'],
            'model': ['ANTHROPIC_MODEL', 'DEFAULT_LLM_MODEL'],
        },
        'cohere': {
            'api_key': ['COHERE_API_KEY'],
            'model': ['COHERE_MODEL', 'DEFAULT_LLM_MODEL'],
        }
    }
    
    # Standard parameter names used internally (snake_case)
    STANDARD_PARAMS = [
        'llm_provider', 'api_key', 'model', 
        'temperature', 'max_tokens',
        'endpoint', 'deployment', 'api_version'
    ]
    
    # Frontend to backend parameter name mappings (camelCase -> snake_case)
    PARAM_MAPPINGS = {
        'llmProvider': 'llm_provider',
        'llmApiKey': 'api_key',
        'llmModel': 'model',
        'azureEndpoint': 'endpoint',
        'azureDeployment': 'deployment',
        'azureApiVersion': 'api_version',
        'embeddingProvider': 'embedding_provider',
        'embeddingModel': 'embedding_model',
        'temperature': 'temperature',
        'maxTokens': 'max_tokens',
    }
    
    @classmethod
    def normalize_provider_name(cls, provider_name):
        """Normalize LLM provider name to standard format."""
        if not provider_name:
            return None
            
        provider_lower = provider_name.lower().strip()
        
        for standard_name, variants in cls.PROVIDER_MAPPINGS.items():
            if provider_lower in variants:
                return standard_name
                
        return provider_lower  # Return as-is if no mapping found
        
    @classmethod
    def standardize_param_names(cls, input_params):
        """Convert frontend camelCase names to backend snake_case names."""
        if not input_params:
            return {}
            
        result = {}
        
        # Process all keys in input_params
        for key, value in input_params.items():
            # Try direct mapping
            if key in cls.PARAM_MAPPINGS:
                result[cls.PARAM_MAPPINGS[key]] = value
            # Try lowercase version of the key
            elif key.lower() in cls.PARAM_MAPPINGS:
                result[cls.PARAM_MAPPINGS[key.lower()]] = value
            else:
                # Convert camelCase to snake_case if needed
                snake_key = re.sub(r'(?<!^)(?=[A-Z])', '_', key).lower()
                if snake_key in cls.STANDARD_PARAMS:
                    result[snake_key] = value
                else:
                    # Keep original key if no mapping found
                    result[key] = value
                    
        return result
        
    @classmethod
    def get_env_var(cls, provider, param_name):
        """Get value from appropriate environment variable based on provider and parameter."""
        if provider not in cls.ENV_MAPPINGS or param_name not in cls.ENV_MAPPINGS[provider]:
            return None
            
        # Try each possible environment variable
        for env_var in cls.ENV_MAPPINGS[provider][param_name]:
            if env_var in os.environ and os.environ[env_var].strip():
                # Skip placeholder values
                value = os.environ[env_var].strip()
                if not (param_name == 'api_key' and cls._is_placeholder_api_key(value)):
                    return value
                    
        return None
        
    @staticmethod
    def _is_placeholder_api_key(key):
        """Check if an API key looks like a placeholder."""
        if not key:
            return True
            
        placeholder_patterns = [
            r'^sk-placeholder',
            r'^placeholder',
            r'^your-api-key',
            r'^sk-[a-zA-Z0-9]{3}$',  # Too short to be real
            r'^x{3,}$',              # xxx
            r'^api-key-goes-here'
        ]
        
        return any(re.match(pattern, key, re.IGNORECASE) for pattern in placeholder_patterns)
        
    @classmethod
    def get_config(cls, ui_params=None):
        """
        Get complete LLM configuration with proper fallbacks.
        
        Args:
            ui_params: Dictionary of parameters from the UI/request
            
        Returns:
            Dictionary with standardized configuration parameters
        """
        # Start with empty config
        config = {}

        # Standardize UI parameters
        std_params = cls.standardize_param_names(ui_params) if ui_params else {}
        logger.info(f"Input parameters received: {std_params}")

        # Resolve provider
        provider = cls._resolve_provider(std_params)
        config['llm_provider'] = provider

        # Resolve common parameters
        cls._resolve_api_key(config, std_params)
        cls._resolve_model(config, std_params)
        cls._resolve_numeric(config, std_params, 'temperature', default=0.7, env_key='DEFAULT_LLM_TEMPERATURE', cast=float)
        cls._resolve_numeric(config, std_params, 'max_tokens', default=4000, env_key='DEFAULT_LLM_MAX_TOKENS', cast=int)

        # Provider-specific resolution
        if provider == 'azure':
            cls._resolve_azure(config, std_params)

        # Embedding configuration
        cls._resolve_embedding(config, std_params)

        # Finalize and log (redact sensitive fields)
        cls._finalize_and_log(config)

        return config

    @classmethod
    def _resolve_provider(cls, std_params: dict) -> str:
        """Resolve and normalize the provider name from UI params or environment."""
        provider = std_params.get('llm_provider')
        logger.info(f"Provider from parameters: {provider}")
        if not provider:
            provider = os.environ.get('DEFAULT_LLM_PROVIDER', 'openai')
            logger.info(f"Using provider from env var: {provider}")
        normalized = cls.normalize_provider_name(provider)
        logger.info(f"After normalization: {provider} -> {normalized}")
        return normalized

    @classmethod
    def _resolve_api_key(cls, config: dict, std_params: dict) -> None:
        api_key = std_params.get('api_key')
        provider = config.get('llm_provider')
        if not api_key or cls._is_placeholder_api_key(api_key):
            api_key = cls.get_env_var(provider, 'api_key')
        config['api_key'] = api_key

    @classmethod
    def _resolve_model(cls, config: dict, std_params: dict) -> None:
        provider = config.get('llm_provider')
        model = std_params.get('model')
        if not model:
            model = cls.get_env_var(provider, 'model')
            if not model:
                defaults = {
                    'openai': 'gpt-4-turbo',
                    'azure': None,
                    'anthropic': 'claude-2',
                    'cohere': 'command',
                }
                model = defaults.get(provider)
        config['model'] = model

    @classmethod
    def _resolve_numeric(cls, config: dict, std_params: dict, name: str, default, env_key: str = None, cast=float) -> None:
        value = std_params.get(name)
        if value is None and env_key:
            env_val = os.environ.get(env_key)
            if env_val is not None:
                try:
                    value = cast(env_val)
                except (ValueError, TypeError):
                    value = default
            else:
                value = default

        try:
            config[name] = cast(value)
        except (ValueError, TypeError):
            config[name] = default

    @classmethod
    def _resolve_azure(cls, config: dict, std_params: dict) -> None:
        # Endpoint (UI -> env var)
        endpoint = std_params.get('endpoint') or cls.get_env_var('azure', 'endpoint')
        if endpoint:
            endpoint = endpoint.rstrip('/')
        config['endpoint'] = endpoint

        # Deployment (UI -> env var -> fallback to model)
        deployment = std_params.get('deployment') or cls.get_env_var('azure', 'deployment') or config.get('model')
        config['deployment'] = deployment

        # API Version (UI -> env var -> default)
        api_version = std_params.get('api_version') or cls.get_env_var('azure', 'api_version') or cls.DEFAULT_AZURE_API_VERSION
        config['api_version'] = api_version

    @classmethod
    def _resolve_embedding(cls, config: dict, std_params: dict) -> None:
        provider = config.get('llm_provider')
        embedding_provider = std_params.get('embedding_provider') or provider
        config['embedding_provider'] = embedding_provider

        embedding_model = std_params.get('embedding_model')
        if embedding_model:
            config['embedding_model'] = embedding_model

        # Azure-specific embedding deployment handling
        if provider == 'azure':
            embedding_deployment = std_params.get('embedding_deployment') or os.environ.get('AZURE_OPENAI_EMBEDDING_DEPLOYMENT')
            if not embedding_deployment:
                deployment = config.get('deployment')
                if deployment and ('embed' in deployment.lower() or deployment.lower() == 'text-embedding-ada-002'):
                    embedding_deployment = deployment
                else:
                    embedding_deployment = 'text-embedding-ada-002'
            config['embedding_deployment'] = embedding_deployment
            logger.info(f"Azure embedding deployment set to: {embedding_deployment}")

    @classmethod
    def _finalize_and_log(cls, config: dict) -> None:
        safe_config = config.copy()
        if 'api_key' in safe_config:
            safe_config['api_key'] = '*** REDACTED ***' if safe_config['api_key'] else None
        logger.info(f"LLM configuration: {safe_config}")
        
    @classmethod
    def set_environment_variables(cls, config):
        """
        Set environment variables based on configuration.
        This is needed for libraries that rely on environment variables.
        
        Args:
            config: Standardized LLM configuration dictionary
        """
        provider = config.get('llm_provider')
        if not provider:
            return
            
        # Set common variables
        if 'api_key' in config and config['api_key']:
            os.environ[f"{provider.upper()}_API_KEY"] = config['api_key']
            
        if 'model' in config and config['model']:
            os.environ[f"{provider.upper()}_MODEL"] = config['model']
            
        # Set Azure-specific variables
        if provider == 'azure':
            azure_vars = {
                "OPENAI_API_TYPE": "azure",
                "OPENAI_API_VERSION": config.get('api_version', cls.DEFAULT_AZURE_API_VERSION),
                "OPENAI_API_BASE": config.get('endpoint', ''),
                "OPENAI_API_KEY": config.get('api_key', ''),
                "AZURE_OPENAI_ENDPOINT": config.get('endpoint', ''),
                "AZURE_DEPLOYMENT_ID": config.get('deployment', ''),
                "AZURE_OPENAI_API_KEY": config.get('api_key', ''),
                "OPENAI_API_MODEL": config.get('deployment', ''),
                "AZURE_OPENAI_DEPLOYMENT": config.get('deployment', ''),
                "OPENAI_API_DEPLOYMENT_ID": config.get('deployment', ''),
                "DEPLOYMENT_NAME": config.get('deployment', ''),
                "DEPLOYMENT_ID": config.get('deployment', '')
            }
                
            # Set Azure OpenAI environment variables
            for key, value in azure_vars.items():
                if value:  # Only set if value is not empty
                    os.environ[key] = value
                    
            # Configure base URL for the deployment if both endpoint and deployment are provided
            if config.get('endpoint') and config.get('deployment'):
                base_url = f"{config['endpoint']}/openai/deployments/{config['deployment']}"
                os.environ["OPENAI_API_BASE"] = base_url
                os.environ["AZURE_OPENAI_BASE_URL"] = base_url
