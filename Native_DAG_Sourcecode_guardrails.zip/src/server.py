"""
FastAPI Server - API endpoints for NeuroITOps SOP generation system
"""
# FastAPI imports
from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os
import json
import logging
import secrets
try:
    from load_env import load_env_from_keyvault
except ImportError:
    from .load_env import load_env_from_keyvault

load_env_from_keyvault()
# Database and models
try:
    from sop_models import init_db, db_session, SOP
    from sop_service import process_tickets
except ImportError:
    from .sop_models import init_db, db_session, SOP
    from .sop_service import process_tickets
    

# Constants
KEY_NOT_SET = 'Not set'
KEY_SET_HIDDEN = 'Set (hidden)'

# Get logger
logger = logging.getLogger('app')

# CORS configuration
origins = [
    "http://localhost:3001",
    "http://localhost:3000",
]

# Models
class CSRFToken(BaseModel):
    token: str

# Initialize FastAPI app
app = FastAPI(title="NeuroITOps SOP API", version="1.0.0")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure upload folder
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Create database tables
def create_tables():
    # Initialize Postgres tables if they don't exist
    init_db()

create_tables()

@app.get("/")
async def root():
    """Root endpoint - health check"""
    return {"message": "NeuroITOps SOP API is running", "status": "healthy"}

@app.get("/health")
async def health():
    """Health check endpoint"""
    return {"message": "NeuroITOps Backend API is running", "status": "healthy"}

@app.get("/api/csrf-token", response_model=CSRFToken)
async def get_csrf_token():
    """Generate and return a CSRF token"""
    token = secrets.token_urlsafe(32)
    response = JSONResponse(content={"csrf_token": token})
    response.set_cookie(
        key="XSRF-TOKEN",
        value=token,
        httponly=True,
        samesite="lax",
        secure=os.getenv('ENVIRONMENT') == 'production',
        max_age=3600  # 1 hour
    )
    return response

@app.post('/api/sop/process-records')
async def process_servicenow_records(request: Request):
    """Process ServiceNow records for clustering"""

    def _extract_value(field):
        if field is None:
            return ''
        if isinstance(field, dict):
            return field.get('display_value') or field.get('value') or ''
        return str(field)

    def _completed_incident_numbers(response_data):
        """Incident numbers that ended up attached to a SOP, per the flow result.

        The flow returns results[] items with 'ticket_id' (== ServiceNow incident
        number / Ticket.external_id) and 'status' of 'Created' (new SOP) or
        'Mapped' (matched to an existing SOP). Both count as Completed.
        """
        completed = set()
        if not isinstance(response_data, dict):
            return completed
        for item in response_data.get('results', []) or []:
            if isinstance(item, dict) and item.get('status') in ('Created', 'Mapped'):
                tid = item.get('ticket_id')
                if tid:
                    completed.add(tid)
        return completed

    async def _parse_request():
        content_type = (request.headers.get('content-type') or '').lower()
        if 'multipart/form-data' in content_type or 'application/x-www-form-urlencoded' in content_type:
            form_data = await request.form()
            rd = dict(form_data)
            if 'records' not in rd:
                raise ValueError("Missing 'records' in form data")
            return json.loads(rd['records']), rd
        else:
            body = await request.body()
            if not body:
                raise ValueError("Empty request body")
            data = json.loads(body.decode('utf-8'))
            if 'records' not in data:
                raise ValueError("Missing 'records' in JSON body")
            return data['records'], data

    def _get_config_value(data, key, default=None):
        return data.get(key) if data.get(key) not in (None, '') else default

    def _build_combined_kwargs(data):
        llm_provider = _get_config_value(data, 'llm_provider', os.environ.get('DEFAULT_LLM_PROVIDER', 'openai'))
        combined = {
            'llm_provider': llm_provider,
            'model': _get_config_value(data, 'llm_model', os.environ.get('DEFAULT_LLM_MODEL', 'gpt-4')),
            'api_key': _get_config_value(data, 'llm_api_key', os.environ.get('OPENAI_API_KEY')),
            'servicenow_integration': True,
            'use_sagemaker': os.environ.get('USE_SAGEMAKER_FOR_RESOLUTION', 'False').lower() == 'true',
            'auto_cluster': str(_get_config_value(data, 'autoCluster', 'true')).lower() == 'true'
        }
        if llm_provider.lower() == 'azure':
            combined.update({
                'azureEndpoint': _get_config_value(data, 'azureEndpoint', os.environ.get('AZURE_OPENAI_ENDPOINT', '')),
                'azureDeployment': _get_config_value(data, 'azureDeployment', os.environ.get('AZURE_OPENAI_DEPLOYMENT', '')),
                'azureApiVersion': _get_config_value(data, 'azureApiVersion', os.environ.get('AZURE_OPENAI_API_VERSION', '')),
                'embeddingModel': _get_config_value(data, 'embeddingModel', os.environ.get('AZURE_OPENAI_EMBEDDING_MODEL', ''))
            })
        return combined

    def _convert_records_to_tickets(records):
        tickets = []
        for record in records:
            tickets.append({
                'id': _extract_value(record.get('id')) or _extract_value(record.get('sys_id')),
                'number': _extract_value(record.get('number')),
                'short_description': _extract_value(record.get('short_description')),
                'resolution_notes': _extract_value(record.get('u_rca_notes')),
                'description': _extract_value(record.get('description')),
                'category': _extract_value(record.get('category')),
                'subcategory': _extract_value(record.get('subcategory')),
                'work_notes': _extract_value(record.get('work_notes')),
                'comments': _extract_value(record.get('comments')),
                'sys_created_on': _extract_value(record.get('sys_created_on')),
                'sys_updated_on': _extract_value(record.get('sys_updated_on')),
                'state': _extract_value(record.get('state')),
                'priority': _extract_value(record.get('priority')),
                'assignment_group': _extract_value(record.get('assignment_group', {})),
                'assigned_to': _extract_value(record.get('assigned_to', {})),
                'opened_by': _extract_value(record.get('opened_by', {})),
                'sys_id': record.get('sys_id', ''),
                'table': record.get('sys_class_name', '')
            })
        return tickets

    def _normalize_response(result):
        if isinstance(result, tuple):
            response_data, status_code = result
        else:
            response_data, status_code = result, 200

        # Guard: if response_data is None or not a dict, convert to an error dict
        if response_data is None or not isinstance(response_data, dict):
            # Log raw result for debugging
            logger.error("process_tickets returned non-dict response: %r", response_data)
            response_data = {
                'status': 'error',
                'message': 'Invalid response from processing service',
                'raw_response': str(response_data)
            }
            status_code = 500

        # If results not present but clusters are, build results list for backward compatibility
        try:
            if 'results' not in response_data and 'clusters' in response_data:
                response_data['results'] = [
                    {
                        'cluster_id': c.get('id'),
                        'name': c.get('name'),
                        'tickets': c.get('tickets', []),
                        'is_matched': c.get('is_matched', False),
                        'sop_id': c.get('sop_id', None)
                    } for c in response_data.get('clusters', [])
                ]
        except Exception as e:
            logger.exception("Error while normalizing response_data structure: %s", str(e))

        response_data['status'] = response_data.get('status', 'success' if status_code == 200 else 'error')
        return response_data, status_code

    try:
        records, request_data = await _parse_request()
        if not records:
            return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={'status': 'error', 'message': 'No valid records found'})

        tickets = _convert_records_to_tickets(records)
        combined_kwargs = _build_combined_kwargs(request_data or {})

        # --- SOP GEN Status: mark every incoming incident In Progress (2) ---------
        # Done here, at record receipt (before clustering), so a ticket reflects
        # "picked up for SOP" as soon as it enters the flow - regardless of what
        # clustering later decides. Parallel + best-effort; never blocks processing.
        if combined_kwargs.get('servicenow_integration', False):
            try:
                try:
                    from utils.servicenow_kb_client import (
                        update_many_sop_gen_status_async, SOP_STATUS_IN_PROGRESS,
                    )
                except ImportError:
                    from .utils.servicenow_kb_client import (
                        update_many_sop_gen_status_async, SOP_STATUS_IN_PROGRESS,
                    )
                incoming_incident_numbers = [t.get('number') for t in tickets if t.get('number')]
                if incoming_incident_numbers:
                    logger.info(
                        "Marking %d incident(s) In Progress (u_sop_gen_status=2)",
                        len(incoming_incident_numbers),
                    )
                    await update_many_sop_gen_status_async(
                        incoming_incident_numbers, SOP_STATUS_IN_PROGRESS
                    )
            except Exception as status_exc:
                logger.error("Failed marking incidents In Progress: %s", str(status_exc))
        # -------------------------------------------------------------------------

        logger.info("Processing %d tickets with combined kwargs (keys only): %s", len(tickets), list(combined_kwargs.keys()))
        result = await process_tickets(tickets=tickets, **combined_kwargs)
        response_data, status_code = _normalize_response(result)

        # --- SOP GEN Status: revert any incident that did NOT complete ------------
        # Completed (3) is written per-incident at KB-link time inside the flow.
        # Here we revert to Yet to start (1) any incident we marked In Progress that
        # did not end up Completed (processing error, no clusters, <2 tickets, or a
        # KB-link failure). We treat the flow's per-ticket results as the source of
        # which incidents completed; everything else picked up is reverted so nothing
        # is stranded at In Progress.
        if combined_kwargs.get('servicenow_integration', False):
            try:
                try:
                    from utils.servicenow_kb_client import (
                        update_many_sop_gen_status_async, SOP_STATUS_YET_TO_START,
                    )
                except ImportError:
                    from .utils.servicenow_kb_client import (
                        update_many_sop_gen_status_async, SOP_STATUS_YET_TO_START,
                    )
                incoming = [t.get('number') for t in tickets if t.get('number')]
                completed = _completed_incident_numbers(response_data)
                to_revert = [inc for inc in incoming if inc not in completed]
                if to_revert:
                    logger.info(
                        "Reverting %d incident(s) to Yet to start (u_sop_gen_status=1)",
                        len(to_revert),
                    )
                    await update_many_sop_gen_status_async(to_revert, SOP_STATUS_YET_TO_START)
            except Exception as status_exc:
                logger.error("Failed reverting incidents to Yet to start: %s", str(status_exc))
        # -------------------------------------------------------------------------

        return JSONResponse(content=response_data, status_code=status_code)

    except ValueError as ve:
        logger.error("Bad request: %s", str(ve))
        return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={'status': 'error', 'message': str(ve)})
    except Exception as e:
        logger.exception("Failed to process records: %s", str(e))
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={'status': 'error', 'message': f"Failed to process records: {str(e)}"}
        )
