# 🧠 Agentic NeuroITOps

A unified alert and incident aggregation platform with custom webhook integrations.

## 🌐 Overview

Agentic NeuroITOps is a centralized observability and operations interface designed to ingest alerts, incidents, or events from a wide range of external monitoring tools and systems (like Datadog, Splunk, Prometheus, ServiceNow, etc.) via custom webhook URLs. It normalizes, manages, visualizes, and enables action on IT operations data from various sources in one unified view.

## 🏗️ Project Structure

```
agentic-neuroitops/
├── backend/                # Flask API backend
│   ├── models/             # Database models
│   ├── routes/             # API endpoints
│   ├── services/           # Business logic
│   ├── utils/              # Helper functions
│   └── tests/              # Backend tests
├── frontend/               # React.js frontend
│   └── src/
│       ├── components/     # Reusable UI components
│       ├── pages/          # Page components
│       ├── context/        # React context providers
│       ├── services/       # API client services
│       └── assets/         # Static assets
└── docs/                   # Project documentation
```

## 🚀 Key Features

- **Webhook-Based Alert Ingestion**: Custom endpoints for external monitoring systems
- **Real-Time Alert Dashboard**: Visualization and management of incoming alerts
- **Integration Management**: Configure and manage external system integrations
- **Alert Enrichment and Normalization**: Standardize alerts from various sources
- **Security and Access Control**: Role-based access and secure webhooks

## 💻 Technology Stack

- **Frontend**: React.js
- **Backend**: Python with Flask
- **Database**: SQLite (with option to scale to other databases)
- **Authentication**: JWT-based authentication

## 🛠️ Setup and Installation

### Backend Setup

1. Navigate to the backend directory:
   ```
   cd backend
   ```

2. Set up a Python virtual environment:
   ```
   python -m venv venv
   venv\Scripts\activate  # On Windows
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Initialize the database:
   ```
   python manage.py init_db
   ```

5. Start the Flask server:
   ```
   python app.py
   ```

### Frontend Setup

1. Navigate to the frontend directory:
   ```
   cd frontend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm start
   ```

## 👥 User Roles

- **Admin**: Manage integrations, access all alerts
- **Operator**: View alerts, perform actions (acknowledge, resolve)
- **Viewer**: Read-only access to dashboards

## 📚 Documentation

Refer to the `docs` directory for detailed documentation about the architecture, API endpoints, and user guides.

## 🔄 Workflow

1. Admin creates integrations in the UI and receives unique webhook URLs
2. External systems are configured to send alerts to these webhook URLs
3. Alerts are normalized and stored in the database
4. Users monitor and manage alerts through the dashboard
5. Actions on alerts are tracked and can trigger notifications

## 🔮 Future Enhancements

- AI/ML-based alert classification and clustering
- Automated root cause analysis
- Integration with ITSM tools (ServiceNow, Jira)
- Automated remediation workflows
- Multi-tenant support
