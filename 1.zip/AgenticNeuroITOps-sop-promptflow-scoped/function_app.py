"""Azure Function App entry point for Snow MCP Server."""
import logging

import azure.functions as func

from src import app as fastapi_app

# Configure logging
logging.basicConfig(level=logging.INFO)

# Create the ASGI function app
app = func.AsgiFunctionApp(
    app=fastapi_app, 
    http_auth_level=func.AuthLevel.ANONYMOUS
)