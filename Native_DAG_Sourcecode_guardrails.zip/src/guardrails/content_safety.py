# src/guardrails/content_safety.py
# SOURCE: NEW — Azure AI Content Safety + Prompt Shields (no AWS equivalent)
import os
import logging
from typing import Tuple

logger = logging.getLogger(__name__)


class ContentSafetyGuard:
    """Screens text for harmful content and prompt-injection before the LLM."""

    def __init__(self):
        self._client = None

    def _get_client(self):
        if self._client is None:
            from azure.ai.contentsafety import ContentSafetyClient
            from azure.identity import ManagedIdentityCredential
            endpoint = os.environ["AZURE_CONTENT_SAFETY_ENDPOINT"]
            cred = ManagedIdentityCredential(
                client_id=os.getenv("MANAGED_IDENTITY_CLIENT_ID"))
            self._client = ContentSafetyClient(endpoint, cred)
        return self._client

    def check_harmful(self, text: str) -> Tuple[bool, str]:
        """Return (is_safe, reason). Fail-open so it never blocks SOP flow."""
        if not text or os.getenv("CONTENT_SAFETY_ENABLED", "true").lower() != "true":
            return True, "skipped"
        try:
            from azure.ai.contentsafety.models import AnalyzeTextOptions
            resp = self._get_client().analyze_text(AnalyzeTextOptions(text=text))
            threshold = int(os.getenv("CONTENT_SAFETY_THRESHOLD", "4"))
            for cat in resp.categories_analysis:
                if cat.severity is not None and cat.severity >= threshold:
                    return False, f"harmful:{cat.category}:{cat.severity}"
            return True, "ok"
        except Exception:
            logger.exception("Content safety check failed — allowing (fail-open)")
            return True, "error-failopen"

    def check_prompt_injection(self, text: str) -> Tuple[bool, str]:
        """Prompt Shields: detect jailbreak / injection. Runs in flag mode."""
        if not text or os.getenv("PROMPT_SHIELDS_ENABLED", "true").lower() != "true":
            return True, "skipped"
        try:
            client = self._get_client()
            result = client.detect_text_jailbreak({"text": text})   # Prompt Shields
            if getattr(result, "jailbreak_analysis", None) and \
               result.jailbreak_analysis.detected:
                return False, "prompt-injection-detected"
            return True, "ok"
        except Exception:
            logger.exception("Prompt Shields check failed — allowing (fail-open)")
            return True, "error-failopen"
