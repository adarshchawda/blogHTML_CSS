"""
DAG-based flow orchestration engine with async execution
Replaces: promptflow flow.dag.yaml + runtime
"""
import asyncio
import time
from dataclasses import dataclass, field
from typing import Callable, Any, Dict, List, Optional, Set
from collections import defaultdict
from enum import Enum


class StepStatus(Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    COMPLETED = "completed"
    FAILED    = "failed"
    SKIPPED   = "skipped"


@dataclass
class FlowStep:
    name:       str
    fn:         Callable
    inputs:     Dict[str, Any] = field(default_factory=dict)
    depends_on: List[str]      = field(default_factory=list)
    condition:  Optional[Callable] = None
    metadata:   Dict[str, Any] = field(default_factory=dict)


@dataclass
class FlowResult:
    outputs:        Dict[str, Any]          = field(default_factory=dict)
    step_results:   Dict[str, Any]          = field(default_factory=dict)
    step_status:    Dict[str, StepStatus]   = field(default_factory=dict)
    execution_time: float                   = 0.0
    error:          Optional[Exception]     = None


class Flow:
    """DAG-based flow orchestration engine — replaces promptflow subprocess + blob poll."""

    def __init__(self, name: str):
        self.name = name
        self._steps: Dict[str, FlowStep] = {}
        self._execution_order: List[str] = []

    def add_step(self, step: FlowStep) -> 'Flow':
        if step.name in self._steps:
            raise ValueError(f"Step '{step.name}' already exists")
        self._steps[step.name] = step
        self._execution_order = []
        return self

    def _topological_sort(self) -> List[List[str]]:
        in_degree = {name: 0 for name in self._steps}
        graph     = defaultdict(list)

        for step_name, step in self._steps.items():
            for dep in step.depends_on or []:
                if dep not in self._steps:
                    raise ValueError(f"Step '{step_name}' depends on unknown step '{dep}'")
                graph[dep].append(step_name)
                in_degree[step_name] += 1

        result        = []
        current_level = [name for name, degree in in_degree.items() if degree == 0]

        while current_level:
            result.append(current_level)
            next_level = []
            for node in current_level:
                for neighbor in graph[node]:
                    in_degree[neighbor] -= 1
                    if in_degree[neighbor] == 0:
                        next_level.append(neighbor)
            current_level = next_level

        if sum(in_degree.values()) > 0:
            raise ValueError("Flow contains circular dependencies")

        return result

    def _resolve_inputs(self, inputs: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        resolved = {}
        for key, value in inputs.items():
            if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                ref = value[2:-1]
                if ref.startswith("inputs."):
                    var_name       = ref.split(".", 1)[1]
                    resolved[key]  = context.get("inputs", {}).get(var_name)
                elif ref in context.get("step_outputs", {}):
                    resolved[key]  = context["step_outputs"][ref]
                else:
                    resolved[key]  = context.get(ref, value)
            else:
                resolved[key] = value
        return resolved

    async def _execute_step(self, step: FlowStep, context: Dict[str, Any]) -> Any:
        resolved_inputs = self._resolve_inputs(step.inputs, context)

        import inspect
        sig = inspect.signature(step.fn)
        if 'llm_client' in sig.parameters and 'llm_client' in context:
            resolved_inputs['llm_client'] = context['llm_client']

        if step.condition and not step.condition(context):
            return None

        if asyncio.iscoroutinefunction(step.fn):
            return await step.fn(**resolved_inputs)
        return step.fn(**resolved_inputs)

    async def run_async(self, inputs: Dict[str, Any]) -> FlowResult:
        start_time       = time.time()
        execution_levels = self._topological_sort()

        context = {
            "inputs":       inputs,
            "step_outputs": {},
            "llm_client":   inputs.get("llm_client"),
        }

        result = FlowResult()

        try:
            for level in execution_levels:
                tasks = []
                for step_name in level:
                    step = self._steps[step_name]
                    result.step_status[step_name] = StepStatus.RUNNING
                    tasks.append(self._execute_step(step, context))

                level_results = await asyncio.gather(*tasks, return_exceptions=True)

                for step_name, step_result in zip(level, level_results):
                    if isinstance(step_result, Exception):
                        result.step_status[step_name] = StepStatus.FAILED
                        result.error = step_result
                        raise step_result
                    else:
                        result.step_status[step_name]      = StepStatus.COMPLETED
                        result.step_results[step_name]     = step_result
                        context["step_outputs"][step_name] = step_result

            if execution_levels:
                result.outputs = {
                    "final_output": result.step_results.get(execution_levels[-1][-1]),
                    **result.step_results,
                }

        except Exception as e:
            result.error = e
            raise
        finally:
            result.execution_time = time.time() - start_time

        return result

    def run(self, inputs: Dict[str, Any]) -> FlowResult:
        return asyncio.run(self.run_async(inputs))
