"""
Scope (partition) configuration for scoped clustering and SOP generation.

WHAT A "SCOPE KEY" IS
---------------------
A scope key is the partition boundary for clustering. Two tickets may only be
compared against each other -- and may only share an SOP -- if they resolve to
the SAME partition. This is what stops a Retail Banking ticket from receiving an
SOP built out of Insurance history.

The scope key has two halves, and BOTH are persisted on every tickets, clusters
and sops row:

    sec_cluster_field   the scope-key TYPE   "u_application_lob"
                        or a composite       "u_application_lob,u_hostname"

    sec_cluster_value   the scope-key VALUE  "Retail Banking"
                        or a composite       "Retail Banking,APPSRV-RB-04"

CONFIGURABLE WITHOUT CODE CHANGES
---------------------------------
The active scope key is read from the SEC_CLUSTER_FIELD environment variable
(an Azure Function App Setting), and may be overridden per request by sending
"sec_cluster_field" in the JSON body. Nothing in this module -- or anywhere
downstream -- is hardcoded to LOB. Any ServiceNow field name works, and any
number of them can be combined.

    SEC_CLUSTER_FIELD=u_application_lob
    SEC_CLUSTER_FIELD=u_hostname
    SEC_CLUSTER_FIELD=u_hostname,u_env,business_service
    SEC_CLUSTER_FIELD=u_application_lob,u_hostname,u_env,business_service,u_hostname_add

Leave it unset or empty to disable scoping entirely and fall back to the
original global clustering behaviour. That is the rollback switch.

ORDER MATTERS, POSITIONS ARE STABLE
-----------------------------------
Values are joined in configuration order, so "RB,HOST1" can never collide with
"HOST1,RB". A field that is missing or blank on a ticket contributes the NA
placeholder rather than an empty string, which keeps every position aligned and
keeps composite values unambiguous.

NA IS A REAL PARTITION
----------------------
A ticket missing one or more of its scope fields lands in a partition whose
value contains "NA". That partition is treated like any other: it is never
merged with, and never compared against, a partition carrying real values. This
is deliberate. Letting NA tickets fall back to a global search is exactly the
cross-partition contamination the whole feature exists to prevent.
"""
import logging
import os
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)

# Written into sec_cluster_value for any configured field that is blank/absent.
NA_PLACEHOLDER = "NA"

# Separator for composite scope keys, on both the field side and the value side.
SCOPE_SEPARATOR = ","

# Human-readable labels for the ServiceNow fields commonly used as scope keys.
# Purely cosmetic -- used for log lines, cluster names and SOP titles. An
# unknown field name falls back to the raw field name, so adding a new scope
# field never requires touching this map.
FIELD_LABELS = {
    "u_application_lob": "LOB",
    "u_hostname": "Host",
    "business_service": "Service",
    "u_env": "Env",
    "u_hostname_add": "Application",
}

# Short tokens used when composing SOP titles, e.g. "SOP_RB_Storage_Timeout".
# Also cosmetic and also optional.
_TITLE_STOPWORDS = {"and", "or", "the", "of", "for", "a", "an"}


def get_configured_scope_field(override: Any = None) -> str:
    """Resolve the active scope-key type.

    Priority:
      1. `override` -- the "sec_cluster_field" value from the request body
      2. SEC_CLUSTER_FIELD environment variable / Function App Setting
      3. "" -- scoping disabled, original global behaviour

    Returns:
        str: comma-separated field names, or "" when scoping is disabled.
    """
    if override is not None and str(override).strip():
        return str(override).strip()
    return (os.environ.get("SEC_CLUSTER_FIELD") or "").strip()


def parse_scope_fields(sec_cluster_field: Any) -> List[str]:
    """Split a scope-key type string into an ordered list of field names.

    Duplicates are removed while preserving first-seen order, so a misconfigured
    "u_hostname,u_hostname" behaves as a single-field scope rather than silently
    doubling every value.

        "u_hostname,u_env"  -> ["u_hostname", "u_env"]
        ""  /  None         -> []
    """
    if not sec_cluster_field:
        return []
    seen = []
    for raw in str(sec_cluster_field).split(SCOPE_SEPARATOR):
        name = raw.strip()
        if name and name not in seen:
            seen.append(name)
    return seen


def normalize_scope_field(sec_cluster_field: Any) -> str:
    """Canonical string form of a scope-key type.

    Re-joining the parsed list makes the stored value insensitive to incidental
    whitespace and duplicates, so "u_hostname , u_env" and "u_hostname,u_env"
    both persist as "u_hostname,u_env" and therefore match the same partitions.
    """
    return SCOPE_SEPARATOR.join(parse_scope_fields(sec_cluster_field))


def is_scoping_enabled(sec_cluster_field: Any) -> bool:
    """True when a usable scope key is configured."""
    return bool(parse_scope_fields(sec_cluster_field))


def extract_display_value(value: Any) -> str:
    """Flatten one ServiceNow field value into a plain trimmed string.

    ServiceNow reference fields arrive as {"display_value": ..., "link": ...}
    when the API is queried with display values, and as a bare string otherwise.
    Both shapes -- plus the nested/None cases -- collapse to a string here.
    """
    if value is None:
        return ""
    if isinstance(value, dict):
        value = value.get("display_value")
        if value is None:
            value = ""
        # A reference field can itself nest another reference field.
        if isinstance(value, dict):
            value = value.get("display_value") or value.get("value") or ""
    if isinstance(value, (list, tuple)):
        value = SCOPE_SEPARATOR.join(str(v) for v in value if v is not None)
    return str(value).strip()


def _lookup_field(ticket: Dict[str, Any], field_name: str) -> Any:
    """Read one scope field off a ticket dict, tolerating shape differences.

    Tries the configured name first, then a couple of harmless variations, so a
    scope field survives whether the record arrived raw from ServiceNow or
    already flattened by the server layer.
    """
    if field_name in ticket:
        return ticket.get(field_name)

    # ServiceNow sometimes exposes the same value with/without the u_ prefix,
    # and callers occasionally pass a friendlier alias.
    candidates = [field_name.lower()]
    if field_name.startswith("u_"):
        candidates.append(field_name[2:])
    else:
        candidates.append("u_" + field_name)

    for key in candidates:
        if key in ticket:
            return ticket.get(key)

    # Last resort: case-insensitive scan.
    lowered = field_name.lower()
    for key, value in ticket.items():
        if str(key).lower() == lowered:
            return value
    return None


def build_scope_value(ticket: Dict[str, Any], scope_fields: List[str]) -> str:
    """Build the composite sec_cluster_value for one ticket.

    Every configured field contributes exactly one position, in configuration
    order. A missing or blank field contributes NA so positions stay aligned.
    """
    if not scope_fields:
        return ""
    parts = []
    for field_name in scope_fields:
        raw = extract_display_value(_lookup_field(ticket, field_name))
        parts.append(raw if raw else NA_PLACEHOLDER)
    return SCOPE_SEPARATOR.join(parts)


def scope_value_has_na(scope_value: Any) -> bool:
    """True when at least one position of the composite value is NA/blank."""
    if not scope_value:
        return True
    return any(
        part.strip() == "" or part.strip().upper() == NA_PLACEHOLDER
        for part in str(scope_value).split(SCOPE_SEPARATOR)
    )


def stamp_scope_on_tickets(
    tickets: List[Dict[str, Any]], sec_cluster_field: Any
) -> Tuple[List[Dict[str, Any]], List[str]]:
    """Write sec_cluster_field / sec_cluster_value onto every ticket dict.

    This is the single point where a ticket's partition is decided. Everything
    downstream reads the stamped values rather than re-deriving them, so the
    partition a ticket lands in cannot drift between the clustering step and the
    SOP step.

    Args:
        tickets: ticket dicts, raw or already flattened.
        sec_cluster_field: the configured scope-key type.

    Returns:
        (tickets, na_ticket_numbers) -- the same list, mutated in place, plus the
        ticket numbers that resolved to a partition containing NA. The NA list is
        informational only; those tickets are still processed, inside their own
        NA partition.
    """
    scope_fields = parse_scope_fields(sec_cluster_field)
    canonical = normalize_scope_field(sec_cluster_field)
    na_tickets: List[str] = []

    if not scope_fields:
        return tickets, na_tickets

    for ticket in tickets:
        if not isinstance(ticket, dict):
            continue
        scope_value = build_scope_value(ticket, scope_fields)
        ticket["sec_cluster_field"] = canonical
        ticket["sec_cluster_value"] = scope_value
        if scope_value_has_na(scope_value):
            na_tickets.append(ticket.get("number") or ticket.get("id") or "unknown")

    if na_tickets:
        logger.warning(
            "%d ticket(s) are missing at least one scope field and will be "
            "clustered inside their own NA partition (never merged with a real "
            "partition): %s",
            len(na_tickets), ", ".join(str(t) for t in na_tickets[:20]),
        )

    logger.info(
        "Stamped scope '%s' on %d ticket(s); %d landed in an NA partition.",
        canonical, len(tickets), len(na_tickets),
    )
    return tickets, na_tickets


def group_tickets_by_scope_value(
    tickets: List[Dict[str, Any]], sec_cluster_field: Any = None
) -> Dict[str, List[Dict[str, Any]]]:
    """Bucket tickets by their stamped sec_cluster_value.

    Falls back to computing the value on the fly if a ticket was not stamped,
    so this is safe to call independently of stamp_scope_on_tickets.
    """
    scope_fields = parse_scope_fields(sec_cluster_field)
    partitions: Dict[str, List[Dict[str, Any]]] = {}

    for ticket in tickets:
        if not isinstance(ticket, dict):
            continue
        scope_value = ticket.get("sec_cluster_value")
        if not scope_value and scope_fields:
            scope_value = build_scope_value(ticket, scope_fields)
            ticket["sec_cluster_value"] = scope_value
        partitions.setdefault(scope_value or NA_PLACEHOLDER, []).append(ticket)

    logger.info(
        "Grouped %d ticket(s) into %d partition(s): %s",
        len(tickets), len(partitions), list(partitions.keys()),
    )
    return partitions


def scope_pairs(sec_cluster_field: Any, sec_cluster_value: Any) -> List[Tuple[str, str, str]]:
    """Zip a composite scope key into (field_name, human_label, value) triples.

    Used for log lines, ServiceNow payloads and prompt context. Tolerates a
    field/value length mismatch (which can only happen if configuration changed
    after rows were written) by padding with NA instead of raising.
    """
    fields = parse_scope_fields(sec_cluster_field)
    values = [v.strip() for v in str(sec_cluster_value or "").split(SCOPE_SEPARATOR)]
    pairs = []
    for idx, field_name in enumerate(fields):
        value = values[idx] if idx < len(values) else NA_PLACEHOLDER
        pairs.append((field_name, FIELD_LABELS.get(field_name, field_name), value or NA_PLACEHOLDER))
    return pairs


def scope_label(sec_cluster_value: Any) -> str:
    """Compact human label for a partition, for cluster names and log lines.

        "Retail Banking"                  -> "Retail Banking"
        "Retail Banking,APPSRV-RB-04"     -> "Retail Banking / APPSRV-RB-04"
    """
    if not sec_cluster_value:
        return NA_PLACEHOLDER
    parts = [p.strip() for p in str(sec_cluster_value).split(SCOPE_SEPARATOR) if p.strip()]
    return " / ".join(parts) if parts else NA_PLACEHOLDER


def scope_descriptor(sec_cluster_field: Any, sec_cluster_value: Any) -> str:
    """Fully qualified partition descriptor for logs and SOP bodies.

        "LOB=Retail Banking, Host=APPSRV-RB-04"
    """
    pairs = scope_pairs(sec_cluster_field, sec_cluster_value)
    if not pairs:
        return "unscoped"
    return ", ".join(f"{label}={value}" for _field, label, value in pairs)


def _token_overrides() -> Dict[str, str]:
    """Optional explicit value -> token map, as JSON in SCOPE_TOKEN_MAP.

    Lets you pin an abbreviation when the automatic one is not what the business
    calls it, e.g. {"Retail Banking": "RB", "Bancassurance": "BANCA"}.
    """
    raw = (os.environ.get("SCOPE_TOKEN_MAP") or "").strip()
    if not raw:
        return {}
    try:
        import json as _json
        parsed = _json.loads(raw)
        if isinstance(parsed, dict):
            return {str(k).strip().lower(): str(v).strip() for k, v in parsed.items()}
    except Exception as exc:
        logger.warning("SCOPE_TOKEN_MAP is not valid JSON, ignoring it: %s", exc)
    return {}


def _token_for_part(part: str, overrides: Dict[str, str], max_len: int) -> str:
    """Abbreviate one position of a composite scope value.

    A value containing a space is treated as a business phrase and reduced to
    its initials. A value without a space is treated as an identifier and kept
    intact, because initials of "APPSRV-RB-04" would be meaningless. Long single
    words are clipped to a 3-letter prefix, which is what turns "Insurance" into
    "INS".
    """
    explicit = overrides.get(part.strip().lower())
    if explicit:
        return explicit

    if " " in part:
        words = [
            "".join(ch for ch in w if ch.isalnum())
            for w in part.split()
        ]
        words = [w for w in words if w and w.lower() not in _TITLE_STOPWORDS]
        if len(words) > 1:
            return "".join(w[0].upper() for w in words)
        if words:
            part = words[0]
        else:
            return NA_PLACEHOLDER

    compact = part.replace(" ", "").upper()
    if compact.isalpha() and len(compact) > 4:
        return compact[:3]
    return compact[:max_len]


def scope_token(sec_cluster_value: Any, max_len: int = 24) -> str:
    """Short uppercase token for SOP titles.

        "Retail Banking"              -> "RB"
        "Insurance"                   -> "INS"
        "Retail Banking,APPSRV-RB-04" -> "RB_APPSRV-RB-04"
        "H1,PROD,Payments"            -> "H1_PROD_PAY"

    This is what gives you SOP_RB_Storage_Timeout vs SOP_INS_Storage_Timeout
    style naming without any per-LOB configuration.
    """
    if not sec_cluster_value:
        return NA_PLACEHOLDER

    overrides = _token_overrides()
    tokens = []
    for part in str(sec_cluster_value).split(SCOPE_SEPARATOR):
        part = part.strip()
        if not part:
            continue
        tokens.append(_token_for_part(part, overrides, max_len))

    return "_".join(t for t in tokens if t) or NA_PLACEHOLDER


def get_primary_cluster_fields() -> List[str]:
    """The fields whose text is embedded for similarity search.

    Per the user story these are the primary clustering fields, and they are
    separate from the scope key: the scope key decides WHICH partition to search,
    these decide WHAT text is compared inside it. Overridable via
    CLUSTER_FIELDS_PRIMARY for tuning without a code change.
    """
    raw = (os.environ.get("CLUSTER_FIELDS_PRIMARY") or "").strip()
    if raw:
        fields = [f.strip() for f in raw.split(SCOPE_SEPARATOR) if f.strip()]
        if fields:
            return fields
    return ["short_description", "description", "resolution_notes"]


def build_scope_payload(sec_cluster_field: Any, sec_cluster_value: Any) -> Dict[str, Any]:
    """Structured scope block for the Promptflow input and ServiceNow payload.

    The work item asks for the scope-key type and value to be included in the
    payload per partition; this is that block.
    """
    if not is_scoping_enabled(sec_cluster_field):
        return {"scoped": False}

    return {
        "scoped": True,
        "sec_cluster_field": normalize_scope_field(sec_cluster_field),
        "sec_cluster_value": str(sec_cluster_value or ""),
        "partition_label": scope_label(sec_cluster_value),
        "partition_descriptor": scope_descriptor(sec_cluster_field, sec_cluster_value),
        "fields": [
            {"field": field, "label": label, "value": value}
            for field, label, value in scope_pairs(sec_cluster_field, sec_cluster_value)
        ],
    }
