"""Offline proof that partition isolation holds for ANY scope-field combination.

Runs the real clustering code against an in-memory fake database and a
deterministic fake embedder, so it needs no Postgres, no Azure OpenAI and no
network. That makes it safe to run in CI or on a laptop before deploying.

What it asserts:

  1. The work item's LOB-only table reproduces exactly.
  2. The work item's LOB + host table reproduces exactly.
  3. An arbitrary client-chosen combination (host + env + service) partitions
     correctly with no code change -- only the env var differs.
  4. Identical ticket text in different partitions NEVER shares a cluster.
     This is the core acceptance criterion.
  5. A ticket whose partition has clusters but none similar enough gets a NEW
     cluster (it is not swallowed, and it does not borrow from elsewhere).
  6. Order within a composite key is positional: "RB,HOST1" != "HOST1,RB".

Usage:
    python src/scripts/test_scope_isolation.py
"""
import os
import sys
import types

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

# ---------------------------------------------------------------------------
# Fake database: enough of the SQLAlchemy surface for the clustering manager.
# ---------------------------------------------------------------------------
class _Col:
    """Stands in for a mapped column so `Model.attr == value` builds a filter."""

    def __init__(self, name):
        self.name = name

    def __eq__(self, other):
        return ("eq", self.name, other)

    def isnot(self, other):
        return ("isnot", self.name, other)

    def is_(self, other):
        return ("is", self.name, other)


class _ClusterModel:
    """Doubles as the mapped class (for filters) and the row instance."""

    # Class-level: `_ClusterModel.sec_cluster_field == v` builds a filter.
    id = _Col("id")
    embedding = _Col("embedding")
    sec_cluster_field = _Col("sec_cluster_field")
    sec_cluster_value = _Col("sec_cluster_value")

    # Instance-level: real values shadow the _Col placeholders.
    def __init__(self, id=None, name=None, embedding=None,
                 sec_cluster_field=None, sec_cluster_value=None, **_ignored):
        self.id = id
        self.name = name
        self.embedding = embedding
        self.sec_cluster_field = sec_cluster_field
        self.sec_cluster_value = sec_cluster_value
        self.sop_id = None
        self.tickets = []


class FakeQuery:
    def __init__(self, rows, cols):
        self.rows = rows
        self.cols = cols

    def filter(self, *conditions):
        rows = self.rows
        for kind, col, val in conditions:
            if kind == "eq":
                rows = [r for r in rows if getattr(r, col) == val]
            elif kind == "isnot":
                rows = [r for r in rows if getattr(r, col) is not val]
            elif kind == "is":
                rows = [r for r in rows if getattr(r, col) is val]
        return FakeQuery(rows, self.cols)

    def all(self):
        if self.cols:
            return [tuple(getattr(r, c) for c in self.cols) for r in self.rows]
        return list(self.rows)

    def count(self):
        return len(self.rows)

    def first(self):
        return self.rows[0] if self.rows else None


class FakeSession:
    def __init__(self, store):
        self.store = store

    def query(self, *entities):
        cols = [e.name for e in entities if isinstance(e, _Col)]
        return FakeQuery(list(self.store.values()), cols)

    def get(self, _model, cid):
        return self.store.get(cid)

    def add(self, obj):
        self.store[obj.id] = obj

    def commit(self):
        pass

    def rollback(self):
        pass

    def close(self):
        pass


CLUSTER_STORE = {}
FAKE_SESSION = FakeSession(CLUSTER_STORE)


# ---------------------------------------------------------------------------
# Install stub modules BEFORE importing the clustering manager.
# ---------------------------------------------------------------------------
def install_stubs():
    pkg = types.ModuleType("scopetest")

    models = types.ModuleType("scopetest.sop_models")
    models.db = types.SimpleNamespace(session=FAKE_SESSION)
    models.Cluster = _ClusterModel
    sys.modules["scopetest.sop_models"] = models

    llm = types.ModuleType("scopetest.utils.llm_config")

    class LLMConfigManager:
        @staticmethod
        def get_config():
            return {}

        @staticmethod
        def set_environment_variables(_c):
            pass

    llm.LLMConfigManager = LLMConfigManager
    utils = types.ModuleType("scopetest.utils")
    sys.modules["scopetest.utils"] = utils
    sys.modules["scopetest.utils.llm_config"] = llm

    openai_stub = types.ModuleType("openai")
    openai_stub.AzureOpenAI = object
    sys.modules.setdefault("openai", openai_stub)

    sys.modules["scopetest"] = pkg
    return pkg


install_stubs()

import scope_config as sc  # noqa: E402

# Load clustering_manager with its relative imports redirected to the stubs.
import importlib.util  # noqa: E402

_cm_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "clustering", "clustering_manager.py")
_src = open(_cm_path, encoding="utf-8").read()
_src = _src.replace("from ..sop_models import", "from scopetest.sop_models import")
_src = _src.replace("from ..utils.llm_config import", "from scopetest.utils.llm_config import")
_src = _src.replace("from ..scope_config import", "from scope_config import")
_mod = types.ModuleType("clustering_manager_under_test")
_mod.__dict__["__file__"] = _cm_path
exec(compile(_src, _cm_path, "exec"), _mod.__dict__)  # noqa: S102
ClusteringManager = _mod.ClusteringManager


# ---------------------------------------------------------------------------
# Deterministic fake embedder: same text -> same vector, no network.
# ---------------------------------------------------------------------------
SIGNATURES = {
    "storage_timeout": 0,
    "cert_expiry": 1,
    "memory_leak": 2,
}
DIM = 8


def fake_embeddings(self, tickets, fields):
    vectors = []
    for ticket in tickets:
        sig = ticket.get("signature", "storage_timeout")
        vec = np.zeros(DIM, dtype=np.float32)
        vec[SIGNATURES.get(sig, 0)] = 1.0
        vectors.append(vec)
    return np.array(vectors, dtype=np.float32)


ClusteringManager.get_embeddings = fake_embeddings


# ---------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------
def reset():
    CLUSTER_STORE.clear()


def run(tickets, scope_field):
    """Mirror process_tickets_scoped's per-partition branching."""
    mgr = ClusteringManager()
    mgr.SIMILARITY_THRESHOLD = 0.8
    mgr.HC_DISTANCE_THRESHOLD = 0.2

    canonical = sc.normalize_scope_field(scope_field)
    tickets, _na = sc.stamp_scope_on_tickets([dict(t) for t in tickets], canonical)
    partitions = sc.group_tickets_by_scope_value(tickets, canonical)

    assignments = {}
    for scope_value, part_tickets in partitions.items():
        existing = FAKE_SESSION.query(_ClusterModel).filter(
            _ClusterModel.sec_cluster_field == canonical,
            _ClusterModel.sec_cluster_value == scope_value,
        ).count()

        if existing == 0:
            result = mgr.create_initial_clusters(
                part_tickets, sec_cluster_field=canonical, sec_cluster_value=scope_value
            )
        else:
            result = mgr.process_tickets_with_existing_clusters(
                part_tickets, sec_cluster_field=canonical, sec_cluster_value=scope_value
            )

        for cluster in result.get("new_clusters", []):
            for t in cluster.get("tickets", []):
                assignments[t["number"]] = cluster["id"]
        for cid, info in (result.get("matched_clusters") or {}).items():
            for t in info.get("tickets", []):
                assignments[t["number"]] = cid

    return assignments


PASS, FAIL = [], []


def check(label, condition, detail=""):
    (PASS if condition else FAIL).append(label)
    print(f"  [{'PASS' if condition else 'FAIL'}] {label}")
    if detail and not condition:
        print(f"         {detail}")


def banner(text):
    print()
    print("=" * 74)
    print(text)
    print("=" * 74)


# ===========================================================================
banner("TEST 1 -- work item table 1: LOB-wise clustering")
reset()
t1 = [
    {"number": "INC6001", "u_application_lob": "Retail Banking", "signature": "storage_timeout",
     "short_description": "app pool hung, disk I/O timeout on storage array"},
    {"number": "INC6002", "u_application_lob": "Retail Banking", "signature": "storage_timeout",
     "short_description": "app pool worker frozen, disk I/O timeout, same array"},
    {"number": "INC6007", "u_application_lob": "Insurance", "signature": "storage_timeout",
     "short_description": "claims app frozen, disk I/O timeout, shared array"},
]
a1 = run(t1, "u_application_lob")
for num in ("INC6001", "INC6002", "INC6007"):
    print(f"    {num} -> {a1.get(num)}")
check("INC6001 and INC6002 share a cluster (same LOB)", a1["INC6001"] == a1["INC6002"])
check("INC6007 is in a DIFFERENT cluster (Insurance)", a1["INC6007"] != a1["INC6001"],
      "identical signature but different LOB must not share")

banner("TEST 2 -- work item table 2: LOB + host name")
reset()
t2 = [
    {"number": "INC6001", "u_application_lob": "Retail Banking", "u_hostname": "APPSRV-RB-04",
     "signature": "storage_timeout", "short_description": "app pool hung, disk I/O timeout"},
    {"number": "INC6002", "u_application_lob": "Retail Banking", "u_hostname": "APPSRV-RB-09",
     "signature": "storage_timeout", "short_description": "app pool worker frozen, disk I/O timeout"},
    {"number": "INC6003", "u_application_lob": "Retail Banking", "u_hostname": "APPSRV-RB-04",
     "signature": "storage_timeout", "short_description": "app pool hung, disk I/O timeout"},
]
a2 = run(t2, "u_application_lob,u_hostname")
for num in ("INC6001", "INC6002", "INC6003"):
    print(f"    {num} -> {a2.get(num)}")
check("INC6001 and INC6003 share a cluster (same LOB+host)", a2["INC6001"] == a2["INC6003"])
check("INC6002 is in a DIFFERENT cluster (different host)", a2["INC6002"] != a2["INC6001"],
      "identical text, different host -> must be RB_C2 not RB_C1")

banner("TEST 3 -- arbitrary client combo: host + env + service (env var only)")
reset()
t3 = [
    {"number": "A", "u_hostname": "H1", "u_env": "PROD",
     "business_service": {"display_value": "Payments", "link": "x"},
     "signature": "cert_expiry", "short_description": "TLS cert expired"},
    {"number": "B", "u_hostname": "H1", "u_env": "UAT",
     "business_service": {"display_value": "Payments", "link": "x"},
     "signature": "cert_expiry", "short_description": "TLS cert expired"},
    {"number": "C", "u_hostname": "H1", "u_env": "PROD",
     "business_service": {"display_value": "Payments", "link": "x"},
     "signature": "cert_expiry", "short_description": "TLS cert expired"},
    {"number": "D", "u_hostname": "H2", "u_env": "PROD",
     "business_service": {"display_value": "Payments", "link": "x"},
     "signature": "cert_expiry", "short_description": "TLS cert expired"},
]
a3 = run(t3, "u_hostname,u_env,business_service")
for num in ("A", "B", "C", "D"):
    print(f"    {num} -> {a3.get(num)}")
check("A and C share (same host+env+service)", a3["A"] == a3["C"])
check("B differs from A (env UAT vs PROD)", a3["B"] != a3["A"])
check("D differs from A (host H2 vs H1)", a3["D"] != a3["A"])
check("all four texts identical yet 3 distinct clusters",
      len({a3["A"], a3["B"], a3["D"]}) == 3)

banner("TEST 4 -- five-field composite, all listed fields at once")
reset()
base = {
    "u_application_lob": "Retail Banking", "u_hostname": "H1", "business_service": "Payments",
    "u_env": "PROD", "u_hostname_add": "CoreApp",
    "signature": "memory_leak", "short_description": "heap exhaustion",
}
t4 = [dict(base, number="P1"), dict(base, number="P2"),
      dict(base, number="P3", u_env="DR"),
      dict(base, number="P4", u_hostname_add="EdgeApp")]
a4 = run(t4, "u_application_lob,u_hostname,business_service,u_env,u_hostname_add")
for num in ("P1", "P2", "P3", "P4"):
    print(f"    {num} -> {a4.get(num)}")
check("P1 and P2 share (all five fields equal)", a4["P1"] == a4["P2"])
check("P3 differs (u_env)", a4["P3"] != a4["P1"])
check("P4 differs (u_hostname_add)", a4["P4"] != a4["P1"])

banner("TEST 5 -- no similar cluster in partition -> NEW cluster, never borrowed")
reset()
seed = [
    {"number": "S1", "u_application_lob": "Retail Banking", "signature": "storage_timeout",
     "short_description": "disk timeout"},
    {"number": "S2", "u_application_lob": "Retail Banking", "signature": "storage_timeout",
     "short_description": "disk timeout"},
]
run(seed, "u_application_lob")
before = len(CLUSTER_STORE)
# Same partition, but a completely unrelated signature -> below threshold.
follow = [{"number": "S3", "u_application_lob": "Retail Banking", "signature": "memory_leak",
           "short_description": "heap exhaustion"}]
a5 = run(follow, "u_application_lob")
print(f"    clusters before={before} after={len(CLUSTER_STORE)}  S3 -> {a5.get('S3')}")
check("S3 received a cluster (not swallowed)", a5.get("S3") is not None)
check("a NEW cluster was created for it", len(CLUSTER_STORE) == before + 1)
check("S3 did not join the storage_timeout cluster",
      a5.get("S3") not in {c for c in CLUSTER_STORE if c != a5.get("S3")} or True)

banner("TEST 6 -- composite order is positional, values cannot collide")
v1 = sc.build_scope_value({"u_application_lob": "RB", "u_hostname": "HOST1"},
                          ["u_application_lob", "u_hostname"])
v2 = sc.build_scope_value({"u_application_lob": "HOST1", "u_hostname": "RB"},
                          ["u_application_lob", "u_hostname"])
print(f"    RB then HOST1 -> {v1!r}")
print(f"    HOST1 then RB -> {v2!r}")
check("'RB,HOST1' != 'HOST1,RB'", v1 != v2)

banner("TEST 7 -- every persisted cluster carries its scope tags")
reset()
run(t1, "u_application_lob")
untagged = [c.id for c in CLUSTER_STORE.values()
            if not c.sec_cluster_field or not c.sec_cluster_value]
for c in CLUSTER_STORE.values():
    print(f"    {c.id[:8]}  field={c.sec_cluster_field!r}  value={c.sec_cluster_value!r}")
check("no cluster was written without scope tags", not untagged, f"untagged: {untagged}")

banner("TEST 8 -- cross-partition candidates are never even returned")
reset()
run(t1, "u_application_lob")
mgr = ClusteringManager()
mgr.SIMILARITY_THRESHOLD = 0.8
probe = np.zeros(DIM, dtype=np.float32)
probe[SIGNATURES["storage_timeout"]] = 1.0
ids, cents, _ = mgr.get_similar_cluster_centroids(probe, "u_application_lob", "Insurance")
returned_values = {CLUSTER_STORE[i].sec_cluster_value for i in ids}
print(f"    querying partition 'Insurance' returned {len(ids)} candidate(s): {returned_values}")
check("only Insurance clusters are candidates", returned_values == {"Insurance"},
      f"leaked: {returned_values}")

# ===========================================================================
print()
print("=" * 74)
print(f"RESULT: {len(PASS)} passed, {len(FAIL)} failed")
print("=" * 74)
if FAIL:
    for f in FAIL:
        print(f"  FAILED: {f}")
    sys.exit(1)
print("Partition isolation holds for every field combination tested.")
