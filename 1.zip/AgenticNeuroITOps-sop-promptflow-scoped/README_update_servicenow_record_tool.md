# ServiceNow Record Update Tool

## Overview

The `update_servicenow_record_tool` is an MCP (Model Context Protocol) tool that allows you to update ServiceNow records with resolution notes, work notes, and other field values. This tool follows the existing ServiceNow integration patterns and uses environment variables for authentication.

## Features

- Update ServiceNow records in any table (incidents, problems, change requests, etc.)
- Add resolution notes, work notes, and close notes
- Update record state and other fields
- Flexible parameter handling with both specific parameters and generic update data
- Progress notifications and error handling
- Supports both basic authentication and API key authentication

## Authentication

The tool uses environment variables for ServiceNow authentication:

```bash
# Required
SERVICENOW_INSTANCE_URL=https://your-instance.service-now.com

# Authentication (choose one method)
# Method 1: Basic Authentication
SERVICENOW_USERNAME=your_username
SERVICENOW_PASSWORD=your_password
SERVICENOW_AUTH_TYPE=basic

# Method 2: API Key Authentication
SERVICENOW_API_KEY=your_api_key
SERVICENOW_AUTH_TYPE=api_key
```

## Usage

### MCP Tool Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `table_name` | string | No | ServiceNow table name (default: "incident") |
| `sys_id` | string | Yes | System ID of the record to update |
| `update_data` | dict | No | Dictionary of fields to update |
| `resolution_notes` | string | No | Resolution notes to add (sets close_notes field) |
| `work_notes` | string | No | Work notes to add |
| `close_notes` | string | No | Close notes to add |
| `state` | string | No | State to set (e.g., "6" for Resolved, "7" for Closed) |

### Examples

#### Example 1: Update with Resolution Notes
```python
{
    "table_name": "incident",
    "sys_id": "abc123def456",
    "resolution_notes": "Issue resolved by restarting the service",
    "state": "6"
}
```

#### Example 2: Add Work Notes
```python
{
    "table_name": "incident", 
    "sys_id": "abc123def456",
    "work_notes": "Investigated the issue and found root cause"
}
```

#### Example 3: Generic Field Updates
```python
{
    "table_name": "incident",
    "sys_id": "abc123def456", 
    "update_data": {
        "assigned_to": "john.doe",
        "priority": "2",
        "short_description": "Updated incident description"
    }
}
```

#### Example 4: Combined Updates
```python
{
    "table_name": "incident",
    "sys_id": "abc123def456",
    "resolution_notes": "Issue resolved successfully", 
    "work_notes": "Applied patch and verified fix",
    "state": "6",
    "update_data": {
        "priority": "3"
    }
}
```

## Response Format

### Success Response
```json
{
    "success": true,
    "message": "Successfully updated incident record abc123def456",
    "record": {
        "sys_id": "abc123def456",
        "state": "6",
        "close_notes": "Issue resolved by restarting the service",
        ...
    },
    "sys_id": "abc123def456", 
    "table": "incident",
    "updated_fields": ["close_notes", "state"]
}
```

### Error Response
```json
{
    "success": false,
    "message": "System ID (sys_id) is required to update a record"
}
```

## ServiceNow Field Mapping

| Parameter | ServiceNow Field | Description |
|-----------|------------------|-------------|
| `resolution_notes` | `close_notes` | Notes added when resolving/closing |
| `work_notes` | `work_notes` | Work log entries |
| `close_notes` | `close_notes` | Closing notes |
| `state` | `state` | Record state (1=New, 2=In Progress, 6=Resolved, 7=Closed) |

## Common ServiceNow States

| State | Value | Description |
|-------|-------|-------------|
| New | 1 | Newly created record |
| In Progress | 2 | Work in progress |
| On Hold | 3 | Temporarily paused |
| Resolved | 6 | Issue resolved |
| Closed | 7 | Record closed |

## Error Handling

The tool includes comprehensive error handling for:

- Missing or invalid sys_id
- Empty update data
- ServiceNow API errors
- Authentication failures
- Network connectivity issues

## Testing

Use the provided test script to validate the tool:

```bash
cd python-sdk-main/mcp-server-dev
python test_update_tool.py
```

The test script will:
1. Validate environment configuration
2. Test ServiceNow connectivity
3. Test parameter validation
4. Perform a real update (if test data is available)

## Integration

The tool is automatically registered in the MCP server as `update_servicenow_record_tool` and can be called via the MCP protocol from any compatible client.

## Security Notes

- Never hardcode credentials in your code
- Use environment variables for all authentication
- The tool logs update operations but masks sensitive data
- All API communications use HTTPS

## Troubleshooting

### Common Issues

1. **Authentication Error**: Verify environment variables are set correctly
2. **Record Not Found**: Check that the sys_id exists and is valid
3. **Permission Denied**: Ensure the ServiceNow user has update permissions
4. **Invalid Field**: Check that field names match ServiceNow schema

### Debug Logging

Enable debug logging to troubleshoot issues:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

This will show detailed API requests and responses for debugging.
