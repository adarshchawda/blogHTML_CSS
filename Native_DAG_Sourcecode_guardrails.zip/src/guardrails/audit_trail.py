# src/guardrails/audit_trail.py
# SOURCE: AWS (adapted) — from audit_trail.py, reading the new pii_mapping table
"""Per-ticket audit report.  Usage:  python -m src.guardrails.audit_trail <request_id>"""
import sys
from collections import Counter

try:
    from sop_models import SessionLocal, PIIMapping
except ImportError:
    from ..sop_models import SessionLocal, PIIMapping

from src.guardrails.config import default_config


def report(request_id: str) -> None:
    session = SessionLocal()
    try:
        rows = (session.query(PIIMapping)
                .filter(PIIMapping.request_id == request_id).all())
        masked = Counter(r.entity_type for r in rows)
        destroyed = default_config.masking.redact_entities

        print(f"\nPII Audit Report for request: {request_id}")
        print("=" * 50)
        print("Reversibly masked (stored, restorable):")
        if masked:
            for etype, n in masked.items():
                print(f"  - {etype}: {n}")
        else:
            print("  (none found / already cleaned up)")
        print("\nPermanently destroyed entity types (never stored):")
        for etype in destroyed:
            print(f"  - {etype}")
        print("=" * 50)
    finally:
        session.close()


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python -m src.guardrails.audit_trail <request_id>")
        sys.exit(1)
    report(sys.argv[1])
