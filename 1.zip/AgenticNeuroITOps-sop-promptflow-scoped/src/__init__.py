"""
MCP Datadog Server Package

This package provides a FastAPI server for fetching logs from Datadog
based on various filters like service name, host name, and custom filters.
"""

# Import main components for easier access
from .server import app

__all__ = ["app"]
