# CHANGES — Guardrails + Intermediate Status (merged)

This codebase now contains **two independent change-sets**, both applied to the
real files:

1. **PII-masking / LLM-safety guardrails** (new in this pass) — ported and adapted
   from the proven AWS Presidio build.
2. **Intermediate SOP-generation status** (already completed earlier) — the
   `u_sop_gen_status` ServiceNow field + the `sop_ticket_status` tracking table.

This file documents both and, importantly, **how they interact** (ordering at the
KB-link moment).

---

## Part A — Guardrails (NEW in this pass)

Detection uses **Presidio + spaCy** (`en_core_web_lg`), the same engine validated
in the AWS build. Sensitive data is split into two paths: reversibly **masked**
data (names, emails, server names, etc.) gets a placeholder + a stored mapping and
is restored after the LLM is done; high-risk **secrets** (credentials, keys, card
numbers, SSNs, and the credential part of connection strings) are **permanently
destroyed** at detection time and never stored or restored. Mappings live in one
new table in the app's existing Azure Postgres DB. Azure AI Content Safety +
Prompt Shields add harmful-content and prompt-injection screening (fail-open). A
secure-logging filter strips secrets from every log line. Everything is
feature-flagged via `config.json` / env vars.

### New files (`src/guardrails/`)

| File | Source | Purpose |
|------|--------|---------|
| `config.py` | AWS (adapted) | Entity lists, thresholds, mask-vs-destroy policy, env overrides |
| `detector.py` | AWS (ported) + 3 NEW recognizers | Presidio+spaCy detection; NEW: DATABASE_NAME, CONNECTION_STRING, FILE_PATH |
| `mapping_repository.py` | AWS (adapted) | Store/fetch/cleanup reversible mappings via the app's `SessionLocal` |
| `masking_service.py` | AWS (adapted) | Masking Gate (`mask_tickets`/`mask_text`) + Remap Gate (`remap_text`) |
| `secure_logging.py` | AWS (ported) | Log filter that hides secrets in every log line |
| `content_safety.py` | NEW | Azure Content Safety + Prompt Shields (no AWS precedent) |
| `audit_trail.py` | AWS (adapted) | Per-ticket "what was masked / destroyed" report |
| `__init__.py` | NEW | Package marker |

### Edited files (guardrail wiring)

| File | Edit |
|------|------|
| `src/sop_models.py` | Added `PIIMapping` ORM model (auto-created by `init_db()`). Placed after `Cluster`, before the status-tracking section. |
| `src/sop_service.py` | In `generate_sop()`: **Masking Gate** before `flow.run_async` (masks tickets, `request_id=cluster_id`); **Remap Gate** right after the DAG output, before save/persist/KB. |
| `src/clustering/clustering_manager.py` | In `get_embeddings()`: mask ticket text before the Azure OpenAI embeddings call (fail-closed). |
| `function_app.py` | Install the secure-logging filter at startup (best-effort). |
| `config.json` | Added `guardrails` flag block + `AZURE-CONTENT-SAFETY-ENDPOINT` to required env vars. |
| `requirements.txt` | Added `presidio-analyzer`, `presidio-anonymizer`, `spacy` (AWS) and `azure-ai-contentsafety` (NEW). Note: `python -m spacy download en_core_web_lg` is a separate build step. |

### Config / env flags (guardrails)

```
pii_masking_enabled            (PII_MASKING_ENABLED)        on/off master switch
pii_score_threshold            (PII_SCORE_THRESHOLD)        min Presidio confidence
pii_retention_days             (PII_RETENTION_DAYS)         mapping retention window
pii_auto_delete_after_remap                                 delete mapping after remap
content_safety_enabled         (CONTENT_SAFETY_ENABLED)     harmful-content screen on/off
content_safety_threshold       (CONTENT_SAFETY_THRESHOLD)   severity cutoff
prompt_shields_enabled         (PROMPT_SHIELDS_ENABLED)     jailbreak/injection screen on/off
```

### Source-provenance summary

* **Ported from AWS as-is:** the `PIIDetector` class + its 5 original recognizers, the secure-logging filter.
* **Adapted from AWS:** config, mapping store/repository, mask/remap service, audit report (same design, rewired to this app's Postgres session + ticket shape).
* **Net-new (no AWS precedent):** content safety + Prompt Shields, the 3 new recognizers, all pipeline wiring lines.

---

## Part B — Intermediate SOP-generation status (already completed earlier)

Writes `u_sop_gen_status` to the ServiceNow incident (1 = Yet to start, 2 = In
Progress, 3 = Completed), driven by what actually happens in the flow, and mirrors
each transition into a new `sop_ticket_status` Postgres table (human-readable
labels). Completion = the incident's KB article was actually linked.

Files involved (all already applied in this merged tree):

| File | Role |
|------|------|
| `src/utils/servicenow_kb_client.py` | `update_sop_gen_status` + async/batch variants; mirrors each write into `sop_ticket_status` |
| `src/server.py` | In Progress (2) at record receipt; revert to Yet to start (1) for anything not completed |
| `src/sop_service.py` | Completed (3) at the KB-link moment (both the created-SOP and matched-SOP paths) |
| `src/sop_models.py` | `SopTicketStatus` model + `upsert_sop_ticket_status` helper |

Status lifecycle:

```
record received ─────────────► u_sop_gen_status = 2 (In Progress)   [server.py]
KB article linked to incident ► u_sop_gen_status = 3 (Completed)     [sop_service.py]
not completed (any reason) ───► u_sop_gen_status = 1 (Yet to start)  [server.py]
```

(Full detail of Part B, including the matched-path completion bug fix, is preserved
in `CHANGES_DAG_SOP_STATUS.md`.)

---

## Part C — How the two change-sets interact (ordering)

Both features touch `src/sop_service.py`, so ordering matters. The guardrail
**Remap Gate runs before the KB-link moment**, which is correct:

```
generate_sop():
  cluster_id = uuid                         # request_id for masking
  mask_tickets(...)         ◄── GUARDRAIL Masking Gate  (before DAG / Azure OpenAI)
  flow.run_async(masked_tickets)            # 3-step DAG runs on MASKED text
  sop_content = <dag output, still masked>
  remap_text(...)          ◄── GUARDRAIL Remap Gate     (restore real values)
  _save_sop_file / _persist_sop_to_db
  _integrate_with_servicenow_kb(...)        # KB article created + LINKED
        └── on successful link ──► u_sop_gen_status = 3 (Completed)  ◄── STATUS
```

So the SOP that gets attached to the ServiceNow KB article carries the **real,
remapped** values, and the ticket only flips to **Completed** *after* that link
succeeds — exactly as intended. The two features do not conflict: remap finishes
well before the status-Completed write.

---

## Verifying / running

* New table `pii_mapping` (and existing `sop_ticket_status`) auto-create on startup
  via the existing `init_db()` → `Base.metadata.create_all(engine)`. No migration.
* Install deps: `pip install -r requirements.txt` then
  `python -m spacy download en_core_web_lg`.
* Set `AZURE-CONTENT-SAFETY-ENDPOINT` in Key Vault (used by content safety /
  Prompt Shields; both fail open if unset/unreachable).
* Turn masking off for a quick A/B by setting `PII_MASKING_ENABLED=false`.
* Per-ticket audit: `python -m src.guardrails.audit_trail <cluster_id>`.
