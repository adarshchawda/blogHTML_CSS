import os
import json
import logging
import asyncio
from typing import Dict, Optional, Any, List
from pathlib import Path
from dotenv import load_dotenv

# Import AutoGen modules
import openai

# Autogen removed: use Promptflow adapter or direct OpenAI/Azure OpenAI calls
try:
    from .promptflow_client import call_promptflow
except Exception:
    try:
        from promptflow_client import call_promptflow
    except Exception:
        call_promptflow = None
# Optional Promptflow adapter (calls a Promptflow / PromptFlow HTTP endpoint)
try:
    from .promptflow_client import call_promptflow
except Exception:
    try:
        from promptflow_client import call_promptflow
    except Exception:
        call_promptflow = None

# Import LLM clients
import time

class SOPValidator:
    def __init__(self, config_dir: str = None):
            
        load_dotenv()
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        self.model_client = None
        self.llm_config = None
        self.selector_group_chat = None

        self._configure_llm()
    
    def _configure_llm(self):
        """Configure the LLM based on environment variables."""
        try:
            from load_env import load_env_from_keyvault
        except ImportError:
            from .load_env import load_env_from_keyvault
    
        load_env_from_keyvault()
        llm_provider = os.getenv("LLM_PROVIDER", "azure").lower()

        if llm_provider in ["azure", "azure_openai"]:
            api_key = os.getenv("AZURE_OPENAI_API_KEY")
            endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
            deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
            api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2023-07-01-preview")

            if not all([api_key, endpoint, deployment]):
                raise ValueError("Missing required Azure OpenAI environment variables")

            # Configure the openai library for Azure OpenAI
            openai.api_type = "azure"
            openai.api_base = endpoint
            openai.api_version = api_version
            openai.api_key = api_key

            self.llm_config = {
                "temperature": float(os.getenv("TEMPERATURE", "0.7")),
                "timeout": int(os.getenv("TIMEOUT", "60")),
                "model": deployment,
                "provider": "azure",
                "api_key": api_key,
                "endpoint": endpoint,
                "api_version": api_version,
            }

        elif llm_provider == "openai":
            api_key = os.getenv("OPENAI_API_KEY")
            model = os.getenv("OPENAI_MODEL", "gpt-4")

            if not api_key:
                raise ValueError("Missing OPENAI_API_KEY environment variable")

            openai.api_key = api_key

            self.llm_config = {
                "temperature": float(os.getenv("TEMPERATURE", "0.7")),
                "timeout": int(os.getenv("TIMEOUT", "60")),
                "model": model,
                "provider": "openai",
                "api_key": api_key,
            }

        else:
            raise ValueError(f"Unsupported LLM provider: {llm_provider}")

        # Standard system message for the validator (used when not using Promptflow)
        self.system_message = (
            "You are a SOP (Standard Operating Procedure) Validator.\n"
            "Your task is to evaluate SOP documents based on predefined criteria.\n\n"
            "Validation Criteria:\n"
            "1. Clarity and Understandability\n"
            "2. Completeness and Coverage\n"
            "3. Accuracy and Correctness\n"
            "4. Structure and Organization\n"
            "5. Compliance with Standards\n"
            "6. Practicality and Feasibility\n"
            "7. Risk Management\n"
            "8. Documentation Quality\n"
            "9. Version\n"
            "10. Review and Approval Process\n\n"
            "For each SOP, provide:\n"
            "- Overall rating (1-10)\n"
            "- Detailed score for each criterion (1-10)\n"
            "- Specific feedback for improvement\n\n"
            "Please format your response in JSON format with the following structure:\n"
            "{\n  \"overall_rating\": <int>,\n  \"criteria_scores\": {\n    \"Clarity\": <int>,\n    \"Completeness\": <int>,\n    \"Accuracy\": <int>,\n    \"Structure\": <int>,\n    \"Compliance\": <int>,\n    \"Practicality\": <int>,\n    \"Risk\": <int>,\n    \"Documentation\": <int>,\n    \"Version\": <int>,\n    \"Review\": <int>\n  },\n  \"feedback\": \"<detailed feedback>\"\n}"
        )

        self.logger.info("Initialized LLM client for provider %s with config: %s", llm_provider, {k: v for k, v in self.llm_config.items() if k != 'api_key'})
    
    def _initialize_agents(self):
        """Initialize the agents for validation."""
        try:
            # Create the validator agent
            self.validator_agent = AssistantAgent(
                name="sop_validator",
                model_client=self.model_client,
                system_message="""You are a SOP (Standard Operating Procedure) Validator.
                Your task is to evaluate SOP documents based on predefined criteria.
                
                Validation Criteria:
                1. Clarity and Understandability
                2. Completeness and Coverage
                3. Accuracy and Correctness
                4. Structure and Organization
                5. Compliance with Standards
                6. Practicality and Feasibility
                7. Risk Management
                8. Documentation Quality
                9. Version
                10. Review and Approval Process
                
                For each SOP, provide:
                - Overall rating (1-10)
                - Detailed score for each criterion (1-10)
                - Specific feedback for improvement
                
                Please format your response in JSON format with the following structure:
                {
                    "overall_rating": <int>,
                    "criteria_scores": {
                        "Clarity": <int>,
                        "Completeness": <int>,
                        "Accuracy": <int>,
                        "Structure": <int>,
                        "Compliance": <int>,
                        "Practicality": <int>,
                        "Risk": <int>,
                        "Documentation": <int>,
                        "Version": <int>,
                        "Review": <int>
                    },
                    "feedback": "<detailed feedback>"
                }"""
            )
            # Create a passive helper assistant so the SelectorGroupChat has
            # at least two participants but does not require interactive user input.
            self.validator_helper = AssistantAgent(
                name="sop_helper",
                model_client=self.model_client,
                system_message=(
                    "You are a helper assistant for SOP validation. Do not request any user input. "
                    "Only provide brief clarifications if explicitly asked by the validator."
                )
            )

            # Setup team chat with termination conditions
            termination = TextMentionTermination("TERMINATE") | MaxMessageTermination(3)

            self.selector_group_chat = SelectorGroupChat(
                participants=[self.validator_agent, self.validator_helper],
                model_client=self.model_client,
                max_turns=10,
                termination_condition=termination,
                allow_repeated_speaker=True,
                emit_team_events=True,
            )
            
            self.logger.info("Agents and group chat initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Error initializing agents: {str(e)}", exc_info=True)
            raise


    async def _validate_sop_async(self, sop_content: str) -> Dict:
        """
        Async method to validate an SOP document using streaming.
        
        Args:
            sop_content: The content of the SOP document to validate
            
        Returns:
            Dictionary containing validation results
        """
        # If configured to use Promptflow, call the Promptflow endpoint instead
        use_promptflow = os.getenv("USE_PROMPTFLOW", "false").lower() in ("1", "true", "yes") or os.getenv("LLM_PROVIDER", "").lower() == "promptflow"
        if use_promptflow and call_promptflow is not None:
            try:
                payload = {
                    "input": {
                        "task": "validate_sop",
                        "sop_content": sop_content,
                        "output_format": "json"
                    }
                }
                timeout = (self.llm_config.get("timeout") if isinstance(self.llm_config, dict) else None) or 60

                # Choose mode: SDK if PROMPTFLOW_USE_SDK=true
                use_sdk = os.getenv("PROMPTFLOW_USE_SDK", "true").lower() in ("1", "true", "yes")
                flow_id = os.getenv("PROMPTFLOW_FLOW_ID")

                loop = asyncio.get_running_loop()
                # run the blocking call in a thread; pass SDK mode and flow_id when requested
                if use_sdk:
                    resp = await loop.run_in_executor(None, call_promptflow, None, None, payload, timeout, "sdk", flow_id)
                else:
                    resp = await loop.run_in_executor(None, call_promptflow, None, None, payload, timeout, "http", None)

                # Attempt to find a JSON result in the response
                if isinstance(resp, dict):
                    # Common shapes: {'result': {...}} or {'output': {...}} or direct
                    for key in ("result", "output", "outputs", "response", "data"):
                        if key in resp and isinstance(resp[key], dict):
                            if "overall_rating" in resp[key]:
                                return resp[key]
                            # attempt to find nested JSON
                            candidate = resp[key]
                            if isinstance(candidate, dict) and "overall_rating" in candidate:
                                return candidate

                    # If top-level contains expected fields, return it
                    if "overall_rating" in resp:
                        return resp

                    # If there's a textual output, try to parse JSON from it
                    text_fields = [resp.get(k) for k in ("text", "output_text", "output") if resp.get(k)]
                    for t in text_fields:
                        if isinstance(t, str):
                            try:
                                import json as _json
                                parsed = _json.loads(t)
                                if isinstance(parsed, dict) and "overall_rating" in parsed:
                                    return parsed
                            except Exception:
                                continue

                return {"error": "No valid response from Promptflow", "raw_response": resp}
            except Exception as e:
                self.logger.exception("Error calling Promptflow for validation")
                return {"error": f"Promptflow call failed: {str(e)}"}

        try:
            # Format the validation request
            validation_request = f"""Please evaluate the following SOP document:
                
            {sop_content}
                
            Please provide your evaluation in the specified JSON format.
            """

            # Helper: extract JSON object from a text blob (strip code fences)
            def _extract_json_from_text(text: str) -> Optional[dict]:
                try:
                    s = text.strip()
                    if s.startswith('```'):
                        parts = s.split('\n')
                        if parts[0].startswith('```'):
                            parts = parts[1:]
                        if parts and parts[-1].strip().endswith('```'):
                            parts = parts[:-1]
                        s = '\n'.join(parts).strip()

                    try:
                        return json.loads(s)
                    except Exception:
                        start = s.find('{')
                        end = s.rfind('}')
                        if start != -1 and end != -1 and end > start:
                            candidate = s[start:end+1]
                            try:
                                return json.loads(candidate)
                            except Exception:
                                return None
                        return None
                except Exception:
                    return None

            # Build chat messages
            messages_payload = [
                {"role": "system", "content": getattr(self, 'system_message', '')},
                {"role": "user", "content": validation_request}
            ]

            # Blocking OpenAI call executed in a thread to avoid blocking loop
            def _sync_chat_call(msgs):
                try:
                    params = {
                        "model": self.llm_config.get("model"),
                        "messages": msgs,
                        "temperature": float(self.llm_config.get("temperature", 0.7)),
                    }
                    # Optional max tokens
                    if "max_tokens" in self.llm_config:
                        params["max_tokens"] = int(self.llm_config["max_tokens"])

                    resp = openai.ChatCompletion.create(**params)
                    # Extract content
                    if resp and resp.get("choices"):
                        first = resp["choices"][0]
                        # Newer API: message.content
                        if isinstance(first.get("message"), dict) and first["message"].get("content"):
                            return first["message"]["content"]
                        # Fallback: text
                        if first.get("text"):
                            return first.get("text")
                    return ""
                except Exception as e:
                    logger.exception("Error calling OpenAI chat completion")
                    return json.dumps({"error": str(e)})

            loop = asyncio.get_running_loop()
            text = await loop.run_in_executor(None, _sync_chat_call, messages_payload)

            parsed = _extract_json_from_text(text or "")
            if parsed and isinstance(parsed, dict) and 'overall_rating' in parsed:
                return parsed

            # If not parsed, attempt to pull JSON from text
            return {"error": "No valid JSON response from LLM", "raw_response": text}

        except Exception as e:
            self.logger.error(f"Error during SOP validation: {str(e)}", exc_info=True)
            return {"error": f"An error occurred during validation: {str(e)}"}
    
    def validate_sop(self, sop_content: str) -> Dict:
        """
        Validate an SOP document using the configured assistant agent.
        
        Args:
            sop_content: The content of the SOP document to validate
            
        Returns:
            Dictionary containing validation results including:
            - Overall rating
            - Criteria scores
            - Feedback
        """
        # Synchronous wrapper that runs the async validator in a separate thread.
        # This avoids "This event loop is already running" when called from
        # code that already has a running event loop (e.g., framework servers).
        import concurrent.futures

        def _run_in_thread(content: str):
            new_loop = asyncio.new_event_loop()
            try:
                asyncio.set_event_loop(new_loop)
                return new_loop.run_until_complete(self._validate_sop_async(content))
            finally:
                try:
                    new_loop.close()
                except Exception:
                    pass

        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
                future = ex.submit(_run_in_thread, sop_content)
                result = future.result()
                return result
        except Exception as e:
            self.logger.error(f"Error in validate_sop: {str(e)}", exc_info=True)
            return {"error": f"An error occurred: {str(e)}"}

    async def validate_sop_async(self, sop_content: str) -> Dict:
        """
        Async public API to validate SOP content. Callers running inside an
        event loop should use this method to avoid thread/loop issues.
        """
        return await self._validate_sop_async(sop_content)

def main():
    """Main function to demonstrate SOP validation."""
    try:
        # Example usage
        validator = SOPValidator()
        
        # Example SOP content
        example_sop = """
        Title: Email Management Procedure
        
        Purpose:
        To establish a standardized process for managing company emails.
        
        Scope:
        Applies to all employees using company email accounts.
        
        Responsibilities:
        - All employees must check emails daily
        - Managers must respond within 2 business days
        """
        
        # Validate the SOP
        print("\nValidating SOP...")
        result = validator.validate_sop(example_sop)
        
        # Print the results
        print("\nValidation Results:")
        if 'error' in result:
            print(f"Error: {result['error']}")
            if 'raw_response' in result:
                print(f"Raw Response: {result['raw_response']}")
        else:
            # Check if we got a valid response with the expected structure
            if 'overall_rating' in result and 'criteria_scores' in result and 'feedback' in result:
                print(f"Overall Rating: {result['overall_rating']}/10\n")
                
                print("Criteria Scores:")
                for criterion, score in result['criteria_scores'].items():
                    print(f"- {criterion}: {score}/10")
                    
                print(f"\nFeedback: {result['feedback']}")
            else:
                # Handle case where response doesn't have expected structure
                print("Unexpected response format. Raw response:")
                print(json.dumps(result, indent=2))
    
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
