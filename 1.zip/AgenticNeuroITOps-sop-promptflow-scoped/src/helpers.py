import os
import pandas as pd
import hashlib
import logging
import tempfile

# Setup logging
logger = logging.getLogger(__name__)

def extract_tickets_from_excel(file):
    """
    Extract ticket data from an Excel file
    """
    try:
        df = _read_excel_to_df(file)
        _standardize_columns(df)
        _convert_timestamps(df)
        tickets = _extract_tickets_from_df(df)
        return tickets
    except Exception as e:
        logger.error(f"Error extracting tickets from Excel: {str(e)}")
        return []

def _read_excel_to_df(file):
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
    file.save(temp_file.name)
    temp_file.close()
    df = pd.read_excel(temp_file.name)
    os.unlink(temp_file.name)
    logger.info(f"Excel file read. Columns: {df.columns.tolist()}")
    return df

def _standardize_columns(df):
    df.columns = [col.strip().lower().replace(' ', '_').replace('-', '_') for col in df.columns]
    df.fillna('', inplace=True)

def _convert_timestamps(df):
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].astype(str)
        df[col] = df[col].apply(lambda x: str(x) if isinstance(x, (pd.Timestamp, pd.Timedelta)) else x)

def _extract_tickets_from_df(df):
    tickets = []
    for i, row in df.iterrows():
        ticket_id, original_id = _get_ticket_id(row, df, i)
        ticket = {
            'id': ticket_id,
            'external_id': original_id,
            'title': _get_first_nonempty(row, df, ['summary', 'subject', 'title']),
            'short_description': row.get('short_description', ''),
            'description': row.get('description', ''),
            'work_notes': row.get('work_notes', ''),
            'additional_comments': row.get('additional_comments', ''),
            'resolution_notes': row.get('resolution_notes', ''),
            'created_at': str(row.get('created_date', '')),
            'severity': str(row.get('priority', '')),
            'category': row.get('category', 'Unknown'),
            'subcategory': row.get('subcategory', '')
        }
        tickets.append(ticket)
    return tickets

def _get_ticket_id(row, df, index):
    original_id = _get_first_nonempty(row, df, ['id', 'ticket_id', 'number', 'incident_number'])
    ticket_id = original_id if original_id else f"TICKET_{index+1}"
    return ticket_id, original_id

def _get_first_nonempty(row, df, fields):
    for field in fields:
        if field in df.columns and pd.notna(row[field]) and row[field]:
            return str(row[field])
    return ''

def find_matching_cluster(new_cluster):
    """
    Check if a cluster matches an existing one in the database
    
    Args:
        new_cluster: The new cluster to check against existing ones
    
    Returns:
        Matching cluster if found, None otherwise
    """
    from models.cluster import Cluster
    
    # Generate content fingerprint for this cluster
    ticket_titles = sorted([t.get('title', '') for t in new_cluster.get('tickets', [])])
    cluster_content = ''.join(ticket_titles)
    content_hash = hashlib.md5(cluster_content.encode()).hexdigest()
    
    # First try to find by name
    existing_cluster = Cluster.query.filter_by(name=new_cluster.get('name')).first()
    
    # If found by name, verify ticket count matches
    if existing_cluster and len(existing_cluster.tickets) == len(new_cluster.get('tickets', [])):
        logger.info(f"Found existing cluster with identical name and ticket count: {existing_cluster.name}")
        return existing_cluster
    
    # Find clusters with similar content
    # Usually you would use embeddings for this, but simplified for our example
    all_clusters = Cluster.query.all()
    for cluster in all_clusters:
        # Skip clusters with no tickets
        if not cluster.tickets.count():
            continue
        
        # Extract ticket titles from existing cluster
        existing_titles = sorted([t.title for t in cluster.tickets])
        existing_content = ''.join(existing_titles)
        existing_hash = hashlib.md5(existing_content.encode()).hexdigest()
        
        # Match if hash is similar (would typically use embedding similarity instead)
        if content_hash == existing_hash or len(set(ticket_titles).intersection(set(existing_titles))) > len(ticket_titles) * 0.7:
            logger.info(f"Found existing cluster with similar content: {cluster.name}")
            return cluster
    
    # No match found
    return None

def link_tickets_to_existing_sop(cluster, existing_cluster):
    """
    Link new tickets to an existing SOP document
    
    Args:
        cluster: The new cluster to link
        existing_cluster: The existing cluster with SOP
    
    Returns:
        Path to the SOP document
    """
    from models.ticket import Ticket
    from models.sop import SOP
    from models.db import db
    
    # Get existing SOP if available
    sop = SOP.query.get(existing_cluster.sop_id) if existing_cluster.sop_id else None
    if not sop:
        logger.warning(f"Existing cluster {existing_cluster.name} has no SOP document")
        return ''
    
    # Link each new ticket to the existing cluster
    for ticket_data in cluster.get('tickets', []):
        # Check if ticket already exists
        ticket_id = ticket_data.get('id')
        existing_ticket = Ticket.query.filter_by(id=ticket_id).first()
        
        if existing_ticket:
            # Update existing ticket if needed
            existing_ticket.cluster_id = existing_cluster.id
        else:
            # Create new ticket and link to cluster
            new_ticket = Ticket(
                id=ticket_id,
                external_id=ticket_data.get('external_id', ''),
                title=ticket_data.get('title', ''),
                description=ticket_data.get('description', ''),
                short_description=ticket_data.get('short_description', ''),
                work_notes=ticket_data.get('work_notes', ''),
                cluster_id=existing_cluster.id
            )
            db.session.add(new_ticket)
    
    # Commit changes
    db.session.commit()
    
    # Return the path to the SOP document
    return sop.document_path

def create_sop_document(sop_content, cluster):
    """
    Create a new SOP document and save it to disk
    
    Args:
        sop_content: The content of the SOP document
        cluster: The cluster for which to create the SOP
    
    Returns:
        Path to the created SOP document
    """
    from models.cluster import Cluster
    from models.sop import SOP
    from models.db import db
    import uuid
    import os
    
    # Generate a unique SOP filename
    sop_id = str(uuid.uuid4())
    sop_filename = f"SOP_{sop_id}.html"
    
    # Ensure the SOPs directory exists
    sops_dir = os.path.join(os.getcwd(), 'sops')
    os.makedirs(sops_dir, exist_ok=True)
    
    # Save SOP content to file
    sop_path = os.path.join(sops_dir, sop_filename)
    with open(sop_path, 'w') as f:
        f.write(sop_content)
    
    # Create a database cluster if it doesn't exist
    db_cluster = Cluster.query.filter_by(name=cluster.get('name')).first()
    if not db_cluster:
        db_cluster = Cluster(
            id=cluster.get('id', str(uuid.uuid4())),
            name=cluster.get('name', ''),
            description=cluster.get('description', '')
        )
        db.session.add(db_cluster)
    
    # Create SOP record in database
    sop = SOP(
        id=sop_id,
        title=f"SOP for {cluster.get('name', 'Unknown Cluster')}",
        document_path=sop_path,
        created_at=pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
    )
    db.session.add(sop)
    
    # Link SOP to cluster
    db_cluster.sop_id = sop.id
    
    # Commit changes
    db.session.commit()
    
    return sop_path
