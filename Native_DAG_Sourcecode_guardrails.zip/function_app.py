"""Azure Function App entry point for Snow MCP Server."""
import logging

import azure.functions as func

from src import app as fastapi_app

# Configure logging
logging.basicConfig(level=logging.INFO)

# --- GUARDRAIL: Secure logging filter ---------------------------------------
# Attach a filter that auto-masks secrets in every log line the app emits.
# Best-effort: never block startup if it cannot be installed.
try:
    from src.guardrails.secure_logging import install_secure_logging
    install_secure_logging()
except Exception:
    pass
# ----------------------------------------------------------------------------

# Create the ASGI function app
app = func.AsgiFunctionApp(
    app=fastapi_app, 
    http_auth_level=func.AuthLevel.ANONYMOUS
)