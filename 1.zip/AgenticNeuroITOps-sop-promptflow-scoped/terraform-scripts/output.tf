output "function_app_url" {
  description = "The default URL of the Azure Function App"
  value       = azurerm_linux_function_app.function_app.default_hostname
}
