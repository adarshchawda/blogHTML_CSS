# Scoped (Partitioned) Clustering — Implementation & Deployment Guide

Generic, configurable partition-scoped clustering and SOP generation.

The scope key is set entirely through an environment variable. Any ServiceNow
field works, in any combination, in any order — no code change is required to
switch from LOB-wise to host-wise to a five-field composite.

---

## 1. What problem this solves

Before this change, similarity search ran across **every** cluster in the
database. Two tickets with the same symptom text matched each other regardless of
which line of business, host, service or environment they came from — so an
Insurance incident could be handed an SOP generated entirely from Retail Banking
history.

Now the ticket's partition is resolved first, and the similarity search is
restricted to that partition. A cluster from another partition is never returned
as a candidate, so it cannot win the comparison and cannot contribute its SOP.

---

## 2. Configuration

One setting controls everything:

| Setting | Purpose |
|---|---|
| `SEC_CLUSTER_FIELD` | The scope key. Comma-separated ServiceNow field names. Empty/unset = original global behaviour. |

### The five fields from the work item

| Business name | Field |
|---|---|
| LOB Name | `u_application_lob` |
| Host Name | `u_hostname` |
| Service Name | `business_service` |
| Environment | `u_env` |
| Application Name | `u_hostname_add` |

### Examples — all of these work with no code change

```
# LOB-wise (work item table 1)
SEC_CLUSTER_FIELD=u_application_lob

# LOB + host (work item table 2)
SEC_CLUSTER_FIELD=u_application_lob,u_hostname

# Host + environment + service
SEC_CLUSTER_FIELD=u_hostname,u_env,business_service

# Everything
SEC_CLUSTER_FIELD=u_application_lob,u_hostname,business_service,u_env,u_hostname_add

# Disabled — reverts to the previous behaviour
SEC_CLUSTER_FIELD=
```

Order is positional and preserved, so `Retail Banking,HOST1` can never collide
with `HOST1,Retail Banking`.

### Per-request override

A request body may override the App Setting, which is useful for testing a new
scope key without redeploying:

```json
{
  "records": [ ... ],
  "sec_cluster_field": "u_hostname,u_env"
}
```

### Optional tuning

| Setting | Default | Purpose |
|---|---|---|
| `CLUSTER_FIELDS_PRIMARY` | `short_description,description,resolution_notes` | The text that gets embedded and compared. Separate from the scope key. |
| `SIMILARITY_THRESHOLD` | `0.8` | Match threshold inside a partition. |
| `HC_DISTANCE_THRESHOLD` | `0.2` | Agglomerative distance threshold when bootstrapping a partition. |
| `CLUSTER_TOP_K` | `3` | Candidate centroids retrieved per ticket. |
| `SCOPE_TOKEN_MAP` | — | JSON map pinning SOP-title abbreviations, e.g. `{"Bancassurance":"BANCA"}`. |
| `PROMPTFLOW_POLL_ATTEMPTS` | `40` | Promptflow output poll attempts. |
| `PROMPTFLOW_POLL_INTERVAL` | `5` | Seconds between poll attempts. |

**Do not add `SEC_CLUSTER_FIELD` to `config.json`.** Anything listed in
`required_env_vars` must exist as a Key Vault secret or `load_env.py` raises and
the whole app fails to start. Use a Function App Setting, which the code reads
with a safe default. If you later want it in Key Vault, create the secret
`SEC-CLUSTER-FIELD` first (hyphens — `load_env.py` converts them to underscores).

---

## 3. Deployment steps

### Step 1 — Migrate the database

Run once, before deploying the code. Idempotent, so re-running is safe.

```bash
# Preview
python src/scripts/migrate_add_scope_columns.py --dry-run

# Apply
python src/scripts/migrate_add_scope_columns.py
```

Or hand the SQL to your DBA:

```bash
psql -f src/scripts/migrate_add_scope_columns.sql
```

This adds `sec_cluster_field` / `sec_cluster_value` to `tickets`, `clusters` and
`sops`, plus a composite index on each. All columns are **nullable** — existing
rows keep `NULL`, which is exactly what the unscoped path filters for.

Verify (expect six rows):

```sql
SELECT table_name, column_name
FROM   information_schema.columns
WHERE  column_name LIKE 'sec_cluster%'
ORDER  BY table_name, column_name;
```

### Step 2 — Set the scope key

Azure Portal → Function App → Configuration → Application settings:

```
Name:  SEC_CLUSTER_FIELD
Value: u_application_lob
```

### Step 3 — Make sure ServiceNow returns the scope fields

The scope field has to be **present in the incoming record** or every ticket
resolves to `NA`. If your ServiceNow query uses `sysparm_fields`, add the scope
fields to it. `server.py` copies each configured scope field onto the ticket
automatically, flattening `{"display_value": ...}` reference fields, and tolerates
`u_` prefix drift between the config and the payload.

### Step 4 — Verify offline before deploying

```bash
python src/scripts/test_scope_isolation.py      # 17 assertions
python src/scripts/test_pipeline_end_to_end.py  # 26 assertions
```

Both run with the database, Azure OpenAI, Promptflow and ServiceNow stubbed, so
they need no credentials and no network.

### Step 5 — Deploy and confirm from the logs

```
Processing 3 ticket(s) | mode = SCOPED | scope key = 'u_application_lob'
SCOPED clustering path active | scope key = 'u_application_lob'
Stamped scope 'u_application_lob' on 3 ticket(s); 0 landed in an NA partition.
Grouped 3 ticket(s) into 2 partition(s): ['Retail Banking', 'Insurance']
=== Partition [LOB=Retail Banking]: 2 ticket(s) ===
[CLUSTERING] BOOTSTRAP for partition [LOB=Retail Banking] ...
Similarity search restricted to partition [LOB=Retail Banking]
...
Attached KB article KB0001 to incident INC6001
KB article KB0001 attached to 2 incident(s), 0 failure(s)
```

`mode = SCOPED` is the line that confirms the feature is live.

---

## 4. Rollback

Clear `SEC_CLUSTER_FIELD` and restart. The dispatcher takes the original global
path, which now also filters to `sec_cluster_field IS NULL` so scoped and
unscoped rows never compete. No schema change to undo.

---

## 5. How it works

### Order of operations, per the user story

```
1. identify the ticket's scope-key value
2. filter to that partition's clusters
3. run the similarity search using ticket meta details WITHIN that partition only
4. match  -> reuse that partition's SOP
   no match -> generate a NEW SOP
```

### Where each step lives

| Step | Location |
|---|---|
| Resolve the scope key | `scope_config.get_configured_scope_field` |
| Copy scope fields off the record | `server._convert_records_to_tickets` |
| Stamp the partition onto each ticket | `scope_config.stamp_scope_on_tickets` |
| Bucket the batch into partitions | `scope_config.group_tickets_by_scope_value` |
| Choose scoped vs unscoped | `sop_service.process_tickets` (dispatcher) |
| Per-partition orchestration | `sop_service.process_tickets_scoped` |
| **Enforce the boundary** | `clustering_manager.get_similar_cluster_centroids` |
| Tag new clusters | `clustering_manager._create_new_cluster` |
| Tag SOP rows | `sop_service._persist_sop_to_db` |
| Attach to the incident | `sop_service._integrate_with_servicenow_kb` |

### The load-bearing part

`get_similar_cluster_centroids` adds two predicates when a scope is active:

```sql
AND sec_cluster_field = :sec_field
AND sec_cluster_value = :sec_value
```

Candidates from other partitions are never returned, so they cannot win the
similarity comparison. This is the mechanism behind *"data from one partition is
never used to generate an SOP for a ticket belonging to another partition."*

### Per-partition cluster counting

The branch between bootstrap and incremental matching is decided by counting
clusters **in that partition only**. A global count would send a brand-new
partition down the incremental branch, where agglomerative clustering requires
two or more tickets — so the partition's first ticket would get no cluster, no
SOP, and would be refetched forever.

A partition arriving with exactly one ticket becomes a single cluster directly.

### Tickets missing a scope field

If a configured field is blank or absent, that position becomes `NA` and the
ticket lands in its own `NA` partition. `NA` is treated as a real partition: it is
never merged with, and never compared against, a partition holding real values.
Letting `NA` tickets fall back to a global search would reintroduce exactly the
contamination this feature prevents. The response lists them under
`scope.na_partition_tickets` so you can spot a misconfigured ServiceNow query.

### SOP naming

The partition token is prefixed onto the SOP title, so the same symptom in two
partitions yields distinguishable SOPs:

```
SOP_RB  | [Retail Banking] app pool hung, disk I/O timeout - 2026-09-08 ...
SOP_INS | [Insurance] app pool hung, disk I/O timeout - 2026-09-08 ...
```

Multi-word values become initials (`Retail Banking` → `RB`); single long words are
clipped (`Insurance` → `INS`); identifiers are kept intact (`APPSRV-RB-04`). Pin
anything you dislike with `SCOPE_TOKEN_MAP`.

The partition is also written into the KB article body and into the Promptflow
input, so the generated SOP text is explicitly about that partition rather than
generic.

---

## 6. Response shape

```json
{
  "status": "success",
  "message": "Processed 3 ticket(s) into 2 cluster(s) and 2 SOP(s) across 2 partition(s)",
  "scope": {
    "sec_cluster_field": "u_application_lob",
    "scope_fields": ["u_application_lob"],
    "partitions": { "Retail Banking": 2, "Insurance": 1 },
    "na_partition_tickets": []
  },
  "results": [
    {
      "ticket_id": "INC6001",
      "cluster_id": "...",
      "sop_id": "...",
      "status": "Created",
      "sec_cluster_field": "u_application_lob",
      "sec_cluster_value": "Retail Banking"
    }
  ],
  "warnings": []
}
```

`status` is `partial` when at least one partition or cluster failed; the failures
are then listed under `errors`. A cluster that was created but whose SOP
generation failed is reported there too — previously that returned `success` with
no SOP attached, which is misleading.

---

## 7. Bugs fixed along the way

These were pre-existing and would have undermined the feature.

**1. Tickets with no match were silently swallowed.**
The matching loop only created a new cluster when a partition had *zero*
candidates. If a partition had clusters but none passed the threshold, the ticket
was filed under dictionary key `None` — no cluster, no SOP, ever. This directly
contradicted *"if no similar SOP exists within the correct partition, the system
generates a new SOP."* The loop now creates a cluster whenever nothing matches.

**2. `raise SystemExit(1)` killed the ServiceNow attach silently.**
`SystemExit` derives from `BaseException`, not `Exception`, so it slipped past
every `except Exception` between `agent_manager` and the FastAPI route. The
database showed updated clusters, nothing reached ServiceNow, and **no error was
logged** because the `logger.error` calls lived in handlers that never ran. Now a
`RuntimeError` carrying the run name and blob path, which the existing handlers
catch and log.

**3. A blocking `time.sleep` in an async function.**
The poll loop stalled the Function's event loop for up to 600 seconds — longer
than Azure's 230-second HTTP limit, so the request was killed mid-poll. Now
`await asyncio.sleep`, with a shorter budget and an early abort when
`pfazure run show` reports `Failed`.

**4. One failure took down the whole batch.**
Partitions are processed sequentially. A Promptflow timeout in the first
partition prevented every later partition from attaching its KB article —
including matched clusters that needed no LLM call at all. Each partition and
each cluster group is now individually contained.

**5. In-batch matching ignored the partition.**
A ticket that found no database match was compared against clusters created
earlier in the same request, with no partition check — so it could be absorbed
into another partition's cluster purely because both arrived together.
`_match_within_batch` now filters candidates by partition first.

**6. Cross-partition SOP reuse had no guard.**
`_process_matched_cluster_group` now asserts that the cluster's partition equals
the tickets' partition and refuses the mapping if they differ, logging loudly.
The similarity query should make this impossible; failing loudly beats producing
a wrong SOP quietly.

---

## 8. Test coverage

`src/scripts/test_scope_isolation.py` — 17 assertions

1. Work item table 1 (LOB-wise) reproduces exactly
2. Work item table 2 (LOB + host) reproduces exactly
3. Arbitrary combination `u_hostname,u_env,business_service` partitions correctly
4. Five-field composite partitions correctly
5. No similar cluster in a partition produces a **new** cluster
6. Composite order is positional — `RB,HOST1` ≠ `HOST1,RB`
7. Every persisted cluster carries its scope tags
8. Cross-partition candidates are never returned by the query

`src/scripts/test_pipeline_end_to_end.py` — 26 assertions

1. Two partitions with identical text produce two separate SOPs
2. Every SOP row is tagged with the scope-key type and value
3. SOP titles are partition-distinguishable
4. A KB article is created per SOP and attached only to that partition's incidents
5. The KB body carries a partition scope header
6. The Promptflow input carries the partition scope
7. An arbitrary three-field combination works end to end
8. One partition's Promptflow failure does not block the others
9. Clearing `SEC_CLUSTER_FIELD` reverts to unscoped behaviour with `NULL` tags

---

## 9. Acceptance criteria

| Criterion | Where it is satisfied |
|---|---|
| Scope field configurable without code changes, in addition to the primary fields | `SEC_CLUSTER_FIELD`; primary fields stay separate in `CLUSTER_FIELDS_PRIMARY` |
| All SOP records tagged with the scope-key type and value | `sops.sec_cluster_field` / `sops.sec_cluster_value`, set in `_persist_sop_to_db` |
| System correctly identifies a ticket's scope-key value | `stamp_scope_on_tickets`, logged per batch |
| Identify value → filter to partition → similarity search within partition only | `process_tickets_scoped` → `get_similar_cluster_centroids` |
| Records matched and SOPs generated only from matched data in the correct partition | Query-level partition filter; in-batch matcher also partition-filtered |
| Data from one partition never used for another | Partition predicates plus the refusal guard in `_process_matched_cluster_group` |
| No similar SOP in the partition → generate a new one | New-cluster branch in `process_tickets_with_existing_clusters` |
| Payload carries the scope-key type and value per partition | `build_scope_payload`, embedded in the Promptflow input and the KB body |

---

## 10. Files

**New**

```
src/scope_config.py                          scope engine (no DB/LLM dependency)
src/scripts/migrate_add_scope_columns.py     idempotent migration runner
src/scripts/migrate_add_scope_columns.sql    same migration as plain SQL
src/scripts/test_scope_isolation.py          17 partition-isolation assertions
src/scripts/test_pipeline_end_to_end.py      26 full-pipeline assertions
```

**Modified**

```
src/sop_models.py                            scope columns on tickets/clusters/sops
src/clustering/clustering_manager.py         partition filter, tagging, matcher fixes
src/sop_service.py                           dispatcher + process_tickets_scoped
src/server.py                                scope resolution, scope-field pass-through
src/promptflow_services/agent_manager.py     scope in payload, SystemExit fix, async poll
SOP_v3/*.jinja2                              partition-aware prompts
local.settings.json                          SEC_CLUSTER_FIELD and tuning defaults
```

**Removed**

```
src/promptflow_services/agent_manager copy.py    stale backup still containing
                                                 raise SystemExit(1)
```

---

## 11. Known limitations

**Prompt-template changes need a flow redeploy.** The `SOP_v3/*.jinja2` edits only
take effect once the flow is redeployed to Azure ML. The partition context is
embedded in the `tickets` input payload as well, so scoped SOPs work correctly
before redeployment — the template edits are reinforcement, not a prerequisite.

**Promptflow cold start is still the main fragility.** The `SystemExit` fix makes
a timeout visible and contained rather than fatal, but it does not make Azure ML
faster. A cold automatic compute session can take five to ten minutes. For
production, either add `--stream` to the `pfazure` call so the subprocess blocks
and returns a real exit code (letting you delete the blob-polling loop entirely),
or move SOP generation onto a queue trigger instead of an HTTP request.

**Payload growth with large clusters.** Full ticket dictionaries are serialised
into the Promptflow input. A cluster of twenty tickets each carrying every `u_*`
and `sys_*` field risks exhausting the model context on `issue_analyzer`.
Consider whitelisting the fields sent to the flow.

**Changing the scope key leaves historical rows tagged with the old key.** They
will not match the new partitions and will simply be ignored, which is safe but
means clusters effectively restart. Clear `clusters` and `sops` if you want a
clean slate after a scope-key change.
