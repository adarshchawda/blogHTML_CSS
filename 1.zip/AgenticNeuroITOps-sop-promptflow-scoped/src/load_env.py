"""Module for loading environment variables from Azure Key Vault."""
import json
import logging
import os

from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient

logger = logging.getLogger(__name__)


def load_env_from_keyvault():
    """Load required environment variables from Azure Key Vault based on config.json."""
    config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")
    
    # Load config.json to get required variable names
    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)
    values_to_fetch = config.get("required_env_vars", [])

    key_vault_url = os.getenv("KEY_VAULT_BASE_URL", "")
    msi_client_id = os.getenv("MANAGED_IDENTITY_CLIENT_ID", "")

    if not key_vault_url:
        raise ValueError("KEY_VAULT_BASE_URL not set in environment.")
    if not values_to_fetch:
        raise ValueError("No required_env_vars defined in config.json.")
    if not msi_client_id:
        raise ValueError("MANAGED_IDENTITY_CLIENT_ID not set in environment.")
    
    # Initialize Managed Identity credentials
    credential = ManagedIdentityCredential(client_id=msi_client_id)

    logger.info("Credentials initialized for Managed Identity: %s", credential)
    logger.info("Fetching values from Key Vault...")

    # Create KeyVault client
    try:
        kv_client = SecretClient(vault_url=key_vault_url, credential=credential)
    except (ValueError, OSError) as e:
        logger.error("Failed to create KeyVault client: %s", e)
        raise RuntimeError(f"Unable to connect to Key Vault: {e}") from e

    # Fetch only required values
    failed_items = []
    for item_name in values_to_fetch:
        env_name = item_name.replace('-', '_')
        try:
            item_value = kv_client.get_secret(item_name).value
            os.environ[env_name] = item_value
        except (ValueError, OSError) as e:
            logger.error("Could not fetch value '%s': %s", item_name, e)
            failed_items.append(item_name)
    
    # Raise exception if any required values failed to load
    if failed_items:
        raise RuntimeError(f"Failed to load required values from Key Vault: {failed_items}")

    logger.info("Loaded values from Key Vault into environment variables.")