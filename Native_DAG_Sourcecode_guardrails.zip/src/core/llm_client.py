"""
Generic LLM Client — replaces promptflow Azure OpenAI connection.
Supports Azure OpenAI (primary), OpenAI, Anthropic.
"""
import os
import json
import urllib.request
import urllib.error
import time
import logging
from dataclasses import dataclass, field
from typing import Iterator, Optional, Dict, Any, List
from enum import Enum

logger = logging.getLogger(__name__)


class LLMProvider(Enum):
    OPENAI       = "openai"
    AZURE_OPENAI = "azure_openai"
    ANTHROPIC    = "anthropic"


@dataclass
class LLMConfig:
    provider:    str   = "azure_openai"
    model:       str   = "gpt-4o"
    api_key:     str   = ""
    endpoint:    str   = ""
    api_version: str   = "2024-02-15-preview"
    deployment:  str   = ""
    temperature: float = 1.0   # mirrors original flow.dag.yaml: temperature: 1
    top_p:       float = 1.0   # mirrors original flow.dag.yaml: top_p: 1
    max_tokens:  int   = 2048
    timeout:     int   = 300
    max_retries: int   = 3
    retry_delay: int   = 2


@dataclass
class LLMResponse:
    content:      str
    model:        str
    tokens_used:  Dict[str, int] = field(default_factory=dict)
    finish_reason: str           = ""
    metadata:     Dict[str, Any] = field(default_factory=dict)


class LLMClient:
    """Generic LLM client — replaces promptflow.tools.aoai."""

    def __init__(self, config: LLMConfig):
        self.config = config
        self._validate_config()

    def _validate_config(self):
        if not self.config.api_key:
            raise ValueError("API key is required")
        if self.config.provider == LLMProvider.AZURE_OPENAI.value:
            if not self.config.endpoint:
                raise ValueError("Endpoint is required for Azure OpenAI")
            if not self.config.deployment:
                raise ValueError("Deployment name is required for Azure OpenAI")

    def complete(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        for attempt in range(self.config.max_retries):
            try:
                if self.config.provider == LLMProvider.AZURE_OPENAI.value:
                    return self._azure_openai_complete(messages, **kwargs)
                elif self.config.provider == LLMProvider.OPENAI.value:
                    return self._openai_complete(messages, **kwargs)
                elif self.config.provider == LLMProvider.ANTHROPIC.value:
                    return self._anthropic_complete(messages, **kwargs)
                else:
                    raise ValueError(f"Unsupported provider: {self.config.provider}")
            except Exception as e:
                if attempt < self.config.max_retries - 1:
                    wait_time = self.config.retry_delay * (2 ** attempt)
                    logger.warning("Retry %d/%d after %ds: %s", attempt + 1, self.config.max_retries, wait_time, e)
                    time.sleep(wait_time)
                else:
                    raise

    def _azure_openai_complete(self, messages: List[Dict], **kwargs) -> LLMResponse:
        url = (
            f"{self.config.endpoint.rstrip('/')}/openai/deployments/"
            f"{self.config.deployment}/chat/completions"
            f"?api-version={self.config.api_version}"
        )
        headers = {"Content-Type": "application/json", "api-key": self.config.api_key}
        data    = {
            "messages":    messages,
            "temperature": kwargs.get("temperature", self.config.temperature),
            "top_p":       kwargs.get("top_p",       self.config.top_p),
            "max_tokens":  kwargs.get("max_tokens",  self.config.max_tokens),
        }

        request = urllib.request.Request(
            url, data=json.dumps(data).encode("utf-8"), headers=headers, method="POST"
        )
        try:
            with urllib.request.urlopen(request, timeout=self.config.timeout) as resp:
                result = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                err_json = json.loads(exc.read().decode("utf-8"))
                err_msg  = err_json.get("error", {}).get("message", str(exc))
                err_code = err_json.get("error", {}).get("code", str(exc.code))
            except Exception:
                err_msg  = str(exc)
                err_code = str(exc.code)
            raise RuntimeError(
                f"Azure OpenAI {exc.code} [{err_code}]: {err_msg}\n"
                f"  Endpoint  : {url}\n"
                f"  Deployment: {self.config.deployment}"
            ) from exc

        choice = result["choices"][0]
        return LLMResponse(
            content=choice["message"]["content"],
            model=result.get("model", self.config.model),
            tokens_used={
                "prompt_tokens":     result["usage"]["prompt_tokens"],
                "completion_tokens": result["usage"]["completion_tokens"],
                "total_tokens":      result["usage"]["total_tokens"],
            },
            finish_reason=choice.get("finish_reason", ""),
            metadata=result,
        )

    def _openai_complete(self, messages: List[Dict], **kwargs) -> LLMResponse:
        url     = "https://api.openai.com/v1/chat/completions"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {self.config.api_key}"}
        data    = {
            "model":       self.config.model,
            "messages":    messages,
            "temperature": kwargs.get("temperature", self.config.temperature),
            "top_p":       kwargs.get("top_p",       self.config.top_p),
            "max_tokens":  kwargs.get("max_tokens",  self.config.max_tokens),
        }
        request = urllib.request.Request(url, data=json.dumps(data).encode("utf-8"), headers=headers, method="POST")
        with urllib.request.urlopen(request, timeout=self.config.timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        choice = result["choices"][0]
        return LLMResponse(
            content=choice["message"]["content"],
            model=result["model"],
            tokens_used={
                "prompt_tokens":     result["usage"]["prompt_tokens"],
                "completion_tokens": result["usage"]["completion_tokens"],
                "total_tokens":      result["usage"]["total_tokens"],
            },
            finish_reason=choice.get("finish_reason", ""),
            metadata=result,
        )

    def _anthropic_complete(self, messages: List[Dict], **kwargs) -> LLMResponse:
        url            = "https://api.anthropic.com/v1/messages"
        system_message = next((m["content"] for m in messages if m["role"] == "system"), None)
        conversation   = [m for m in messages if m["role"] != "system"]
        headers        = {"Content-Type": "application/json", "x-api-key": self.config.api_key, "anthropic-version": "2023-06-01"}
        data           = {
            "model":       self.config.model,
            "messages":    conversation,
            "max_tokens":  kwargs.get("max_tokens",  self.config.max_tokens),
            "temperature": kwargs.get("temperature", self.config.temperature),
        }
        if system_message:
            data["system"] = system_message
        request = urllib.request.Request(url, data=json.dumps(data).encode("utf-8"), headers=headers, method="POST")
        with urllib.request.urlopen(request, timeout=self.config.timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        return LLMResponse(
            content=result["content"][0]["text"],
            model=result["model"],
            tokens_used={
                "prompt_tokens":     result["usage"]["input_tokens"],
                "completion_tokens": result["usage"]["output_tokens"],
                "total_tokens":      result["usage"]["input_tokens"] + result["usage"]["output_tokens"],
            },
            finish_reason=result.get("stop_reason", ""),
            metadata=result,
        )


def create_llm_client_from_env() -> LLMClient:
    """Create LLM client from environment variables loaded by Key Vault."""
    # Read flow settings — mirrors original flow.dag.yaml: temperature:1, top_p:1
    try:
        import json as _json, os as _os
        config_path = _os.path.join(_os.path.dirname(__file__), "..", "..", "config.json")
        with open(config_path, "r", encoding="utf-8-sig") as f:
            flow_cfg    = _json.load(f).get("flow", {})
        temperature = float(flow_cfg.get("default_temperature", 1.0))
        top_p       = float(flow_cfg.get("top_p",              1.0))
        max_tokens  = int(flow_cfg.get("max_tokens",           2048))
    except Exception:
        temperature, top_p, max_tokens = 1.0, 1.0, 2048

    provider = os.getenv("LLM_PROVIDER", os.getenv("DEFAULT_LLM_PROVIDER", "azure_openai"))
    if provider == "azure":
        provider = "azure_openai"

    if provider == "azure_openai":
        config = LLMConfig(
            provider=provider,
            api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
            endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
            deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", ""),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
            model=os.getenv("AZURE_OPENAI_DEPLOYMENT", ""),
            temperature=temperature, top_p=top_p, max_tokens=max_tokens,
        )
    elif provider == "openai":
        config = LLMConfig(
            provider=provider,
            api_key=os.getenv("OPENAI_API_KEY", ""),
            model=os.getenv("OPENAI_MODEL", "gpt-4o"),
            temperature=temperature, top_p=top_p, max_tokens=max_tokens,
        )
    elif provider == "anthropic":
        config = LLMConfig(
            provider=provider,
            api_key=os.getenv("ANTHROPIC_API_KEY", ""),
            model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4"),
            temperature=temperature, top_p=top_p, max_tokens=max_tokens,
        )
    else:
        raise ValueError(f"Unsupported provider: {provider}")

    return LLMClient(config)
