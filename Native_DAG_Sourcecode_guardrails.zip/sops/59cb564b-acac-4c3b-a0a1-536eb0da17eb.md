# Password Reset and Account Lockout Resolution Standard Operating Procedure

## 1. Overview
This SOP outlines the procedure for resolving password reset requests and account lockout issues commonly encountered in IT support scenarios. These issues typically arise when users forget their passwords or enter incorrect login credentials, resulting in account lockouts due to system security protocols. Efficiently addressing these issues ensures uninterrupted user access to their accounts while maintaining security standards.

## 2. Procedure
Clear step-by-step instructions:

#### Step 1: Verify Identity
1. Ensure the user verifies their identity through access to their registered email or phone number for confirmation codes.
2. Follow organizational procedures for identity verification such as security questions or a security token.

#### Step 2: Password Reset Process
1. **Access the Self-Service Portal**:
   - Navigate to the self-service portal URL for password reset initiation.
   
2. **Initiate Password Reset**:
   - Locate and access the password reset section.
   - Enter the user's registered email or username.
   - Complete any Captcha or security challenges.

3. **Receive and Enter Confirmation Code**:
   - Instruct the user to retrieve the confirmation code from email or phone.
   - Enter the code in the portal, ensuring to note any timeout issues.

#### Step 3: Unlock Account
1. **Log into Admin or IT Support Console**:
   - Access the user management system with administrative privileges.

2. **Locate User Account**:
   - Search using the user's username or email.

3. **Unlock Account**:
   - In the user’s profile, navigate to the security section and select "Unlock Account."
   - Document the action in compliance logs, noting the unlock reason.

#### Step 4: Set New Password
1. **Prompt User for New Password**:
   - Direct the user to set a new password, adhering to the organization’s password policy (e.g., mix of characters, numbers, and symbols).

2. **Verification**:
   - Ensure the user receives a confirmation of password change via email or phone.

#### Step 5: Test and Validate Access
1. **Test Login**:
   - Guide the user to log in with the new password and verify access to all account features.

## 3. Verification
To confirm success:
1. Ensure the user successfully logs into their account.
2. Verify correct access to profile and account resources.
3. Confirm that no further lockout occurs on initial login attempts.

## 4. Troubleshooting
Common problems and fixes:

1. **Confirmation Code Issues**: Verify correct email/contact details. If needed, re-trigger the confirmation code.
2. **Security Questions/Token Mismatch**: Assist the user in updating any mismatched security details.
3. **Persistent Lockout**: Investigate automatic lockout policies or settings, and adjust as necessary to prevent erroneous lockouts.

By following this SOP, you will resolve user password reset and account lockout issues effectively while ensuring compliance with security protocols.