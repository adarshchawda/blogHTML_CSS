"""
Compatibility module for backward compatibility with KernelKNNClustering
"""
import os
import uuid
import logging
import numpy as np
from typing import List, Dict, Any, Optional
from .knn_clustering import clustering_engine
from numpy.linalg import norm

# Setup logging
logger = logging.getLogger(__name__)

class KernelKNNClustering:
    """
    Backward compatibility wrapper for the KNNClusteringEngine.
    Provides the same interface as the original KernelKNNClustering class.
    """
    
    def __init__(self, embedding_provider=None, embedding_model=None, api_key=None):
        self.embedding_provider = embedding_provider
        self.embedding_model = embedding_model or "all-MiniLM-L6-v2"
        self.embedding_api_key = api_key
        
        self.similarity_threshold = float(os.environ.get("SIMILARITY_THRESHOLD", "0.75"))
        self.n_neighbors = int(os.environ.get("CLUSTER_K_NEIGHBORS", "3"))
        
        self.clustering_engine = clustering_engine
        
        logger.info(f"Initialized KNN Clustering with model: {self.embedding_model}")
        logger.info(f"Using similarity threshold: {self.similarity_threshold}, n_neighbors: {self.n_neighbors}")
    
    def get_embedding(self, text: str) -> List[float]:
        if not text:
            return []
        embedding = self.clustering_engine.get_embeddings([text])
        if embedding.size > 0:
            return embedding[0].tolist()
        return []

    # -------------------------------------------------------------------------
    # Refactored compute_similarity
    # -------------------------------------------------------------------------
    def compute_similarity(self, embedding1, embedding2) -> float:
        try:
            if isinstance(embedding1, dict) and isinstance(embedding2, dict):
                return self._weighted_dict_similarity(embedding1, embedding2)

            if isinstance(embedding1, dict) and isinstance(embedding2, list):
                return self._dict_list_similarity(embedding1, embedding2)

            if isinstance(embedding1, list) and isinstance(embedding2, dict):
                return self._dict_list_similarity(embedding2, embedding1)

            return self._standard_similarity_wrapper(embedding1, embedding2)

        except Exception as e:
            logger.error(f"Error computing similarity: {str(e)}")
            return 0.0

    # ---------------------- Helper Methods ----------------------
    def _weighted_dict_similarity(self, emb1: Dict, emb2: Dict) -> float:
        from sklearn.metrics.pairwise import cosine_similarity

        f1 = emb1.get("field_embeddings", {})
        f2 = emb2.get("field_embeddings", {})
        weights = emb1.get("weights", {})

        similarity_sum = 0.0
        total_weight = 0.0

        for field, vec1 in f1.items():
            if field not in f2 or field not in weights:
                continue

            vec2 = f2[field]
            if not vec1 or not vec2:
                continue

            min_dim = min(len(vec1), len(vec2))
            v1 = np.array(vec1[:min_dim]).reshape(1, -1)
            v2 = np.array(vec2[:min_dim]).reshape(1, -1)

            sim = cosine_similarity(v1, v2)[0][0]
            similarity_sum += sim * weights[field]
            total_weight += weights[field]

        if total_weight > 0:
            return float(similarity_sum / total_weight)

        return self._standard_similarity_wrapper(
            emb1.get("combined_embedding", []),
            emb2.get("combined_embedding", [])
        )

    def _dict_list_similarity(self, dict_emb: Dict, list_emb: List[float]) -> float:
        return self._standard_similarity_wrapper(
            dict_emb.get("combined_embedding", []),
            list_emb
        )

    def _standard_similarity_wrapper(self, e1, e2) -> float:
        if not isinstance(e1, list) or not isinstance(e2, list):
            return 0.0
        return self._compute_standard_similarity(e1, e2)

    def _compute_standard_similarity(self, embedding1: List[float], embedding2: List[float]) -> float:
        if not embedding1 or not embedding2:
            return 0.0
        
        if len(embedding1) != len(embedding2):
            logger.warning(f"Embedding dimension mismatch: {len(embedding1)} vs {len(embedding2)}")
            min_dim = min(len(embedding1), len(embedding2))
            embedding1 = embedding1[:min_dim]
            embedding2 = embedding2[:min_dim]

        vec1 = np.array(embedding1).reshape(1, -1)
        vec2 = np.array(embedding2).reshape(1, -1)

        sim_score = 1 / (1 + norm(vec1 - vec2))
        return float(sim_score)

    # ---------------------- Clustering Methods ----------------------
    def cluster_tickets(self, tickets: List[Dict[str, Any]]) -> Dict[str, Any]:
        return self.clustering_engine.cluster_tickets(
            tickets=tickets,
            n_clusters=None,
            min_cluster_size=2
        )
        
    def cluster_tickets_with_clusters(self, tickets: List[Dict[str, Any]], clusters: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        if not clusters:
            return self.cluster_tickets(tickets)
        return {
            "matched_clusters": {},
            "new_clusters": self.cluster_tickets(tickets).get("clusters", [])
        }

    def calculate_similarity_matrix(self, ticket_embeddings: List[List[float]]):
        if not ticket_embeddings:
            return np.array([[]])
        
        embedding_array = (
            np.array(ticket_embeddings)
            if not isinstance(ticket_embeddings, np.ndarray)
            else ticket_embeddings
        )
        from sklearn.metrics.pairwise import cosine_similarity
        return cosine_similarity(embedding_array)

    def find_sop_matches(self, tickets) -> Dict[str, Dict[str, Any]]:
        if hasattr(tickets, 'to_dict'):
            tickets_list = tickets.to_dict('records')
        elif isinstance(tickets, list):
            tickets_list = tickets
        else:
            return {}
        return {str(t.get('id', i)): {'matches': [], 'scores': []} for i, t in enumerate(tickets_list)}

    # ---------------------- Incremental Ticket Clustering ----------------------
    def cluster_ticket_incremental(self, ticket: Dict[str, Any], clusters: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        logger.info(f"Processing ticket: {ticket.get('id', 'unknown')}")
        ticket_embedding = self._get_ticket_embedding(ticket)

        def get_embedding_or_placeholder():
            if ticket_embedding and ticket_embedding.get('combined_embedding'):
                return ticket_embedding['combined_embedding']
            return [0.0] * 384

        if ticket_embedding is None or not clusters:
            return self._create_new_cluster(ticket, get_embedding_or_placeholder())

        similarity_scores = []
        for cluster in clusters:
            centroid = cluster.get('centroid')
            if not centroid:
                logger.warning(f"Cluster {cluster.get('id')} has no centroid, skipping")
                continue
            similarity_scores.append({
                'cluster_id': cluster.get('id'),
                'cluster': cluster,
                'similarity': self.compute_similarity(ticket_embedding, centroid)
            })

        similarity_scores.sort(key=lambda x: x['similarity'], reverse=True)
        similarity_threshold = float(os.environ.get('SIMILARITY_THRESHOLD', '0.75'))

        if similarity_scores:
            top_scores = ", ".join([f"{s['cluster_id']}: {s['similarity']:.4f}" for s in similarity_scores[:3]])
            logger.info(f"Top similarity scores for ticket {ticket.get('id', 'unknown')}: {top_scores}")

        if similarity_scores and similarity_scores[0]['similarity'] >= similarity_threshold:
            best_match = similarity_scores[0]
            return {
                "new_clusters": [],
                "matched_clusters": {
                    best_match['cluster_id']: {
                        "cluster": best_match['cluster'],
                        "tickets": [ticket],
                        "similarity": best_match['similarity']
                    }
                },
                "warnings": []
            }

        if similarity_scores:
            logger.info(f"Best similarity {similarity_scores[0]['similarity']:.4f} below threshold {similarity_threshold}. Creating new cluster.")
        else:
            logger.info(f"No similarity scores available. Creating new cluster.")

        return self._create_new_cluster(ticket, get_embedding_or_placeholder())

    # ---------------------- Ticket Embedding ----------------------
    def _get_ticket_embedding(self, ticket: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            weights = {
                'resolution_notes': 0.4,
                'description': 0.3,
                'short_description': 0.3

            }
            fields = ['short_description', 'description', 'resolution_notes']

            def embed_field(field_name: str) -> Optional[List[float]]:
                text = ticket.get(field_name)
                if text:
                    text = str(text).strip()
                    if text:
                        return self.get_embedding(text)
                return None

            field_embeddings = {f: embed_field(f) for f in fields}
            field_embeddings = {k: v for k, v in field_embeddings.items() if v}

            if not field_embeddings:
                logger.warning(f"No text content found for ticket {ticket.get('id', 'unknown')}. Using placeholder.")
                placeholder_text = f"Ticket {ticket.get('id', 'unknown')}"
                combined_embedding = self.get_embedding(placeholder_text)
                return {
                    'field_embeddings': {'placeholder': combined_embedding},
                    'weights': {'placeholder': 1.0},
                    'combined_embedding': combined_embedding
                }

            dims = [len(emb) for emb in field_embeddings.values() if len(emb) > 0]
            dim = max(set(dims), key=dims.count) if dims else 384

            def standardize_emb(emb: List[float]) -> np.ndarray:
                if len(emb) > dim:
                    emb = emb[:dim]
                elif len(emb) < dim:
                    emb = emb + [0.0] * (dim - len(emb))
                return np.array(emb)

            combined_embedding = np.zeros(dim)
            total_weight = 0.0
            for field, emb in field_embeddings.items():
                w = weights.get(field, 0.0)
                combined_embedding += standardize_emb(emb) * w
                total_weight += w
            if total_weight > 0:
                combined_embedding = combined_embedding / total_weight

            return {
                'field_embeddings': field_embeddings,
                'weights': weights,
                'combined_embedding': combined_embedding.tolist()
            }

        except Exception as e:
            logger.error(f"Error generating embedding for ticket {ticket.get('id', 'unknown')}: {str(e)}")
            return None

    # ---------------------- Create New Cluster ----------------------
    def _create_new_cluster(self, ticket: Dict[str, Any], embedding: List[float]) -> Dict[str, Any]:
        new_cluster_id = str(uuid.uuid4())
        new_cluster = {
            "id": new_cluster_id,
            "name": ticket.get('short_description', f"Cluster {new_cluster_id[:8]}"),
            "tickets": [ticket],
            "ticket_ids": [ticket.get('id', str(uuid.uuid4()))],
            "centroid": embedding,
            "embedding_dimension": len(embedding)
        }
        logger.info(f"Created new cluster {new_cluster_id} for ticket {ticket.get('id', 'unknown')}")
        return {
            "new_clusters": [new_cluster],
            "matched_clusters": {},
            "warnings": []
        }

    def _create_new_cluster_with_placeholder(self, ticket: Dict[str, Any]) -> Dict[str, Any]:
        new_cluster_id = str(uuid.uuid4())
        new_cluster = {
            "id": new_cluster_id,
            "name": ticket.get('short_description', f"Cluster {new_cluster_id[:8]}"),
            "tickets": [ticket],
            "ticket_ids": [ticket.get('id', str(uuid.uuid4()))],
            "centroid": [0.0] * 384
        }
        logger.warning(f"Created new cluster with placeholder embedding for ticket {ticket.get('id', 'unknown')}")
        return {
            "new_clusters": [new_cluster],
            "matched_clusters": {},
            "warnings": [f"Could not generate valid embedding for ticket {ticket.get('id', 'unknown')}"]
        }