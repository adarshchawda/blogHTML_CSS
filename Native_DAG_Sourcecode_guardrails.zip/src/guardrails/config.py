# src/guardrails/config.py
# SOURCE: AWS (adapted) — based on pii_masking_integration/config.py
"""
Guardrail configuration: detection thresholds, entity lists, and the
mask-vs-redact policy. All values can be overridden by environment
variables so behaviour can change without a code deploy.
"""
import os
from dataclasses import dataclass, field
from typing import List


@dataclass
class DetectionConfig:
    """What to detect and how confident Presidio must be."""
    score_threshold: float = 0.85
    language: str = "en"
    spacy_model: str = "en_core_web_lg"

    # Presidio built-in entity types
    builtin_entities: List[str] = field(default_factory=lambda: [
        "PERSON", "EMAIL_ADDRESS", "PHONE_NUMBER", "IP_ADDRESS",
        "CREDIT_CARD", "US_SSN", "US_BANK_NUMBER", "URL",
        "AWS_ACCESS_KEY", "AWS_SECRET_KEY",
    ])

    # Custom enterprise entity types (defined in detector.py)
    custom_entities: List[str] = field(default_factory=lambda: [
        "SERVER_NAME", "INCIDENT_ID", "EMPLOYEE_ID", "ASSET_TAG",
        "ACCOUNT_NUMBER",
        # --- NEW for Azure user story ---
        "DATABASE_NAME", "CONNECTION_STRING", "FILE_PATH",
    ])


@dataclass
class MaskingConfig:
    """Placeholder format and the mask-vs-destroy policy."""
    placeholder_prefix: str = "<"
    placeholder_suffix: str = ">"

    # Entities that are PERMANENTLY DESTROYED — never stored, never restored,
    # never sent to Azure OpenAI. This is the most safety-critical list here.
    redact_entities: List[str] = field(default_factory=lambda: [
        "AWS_ACCESS_KEY", "AWS_SECRET_KEY", "CREDIT_CARD", "US_SSN",
        # --- NEW: the credential portion of a connection string ---
        "CONNECTION_STRING",
    ])
    redact_replacement: str = "[REDACTED]"


@dataclass
class GuardrailConfig:
    """Top-level container, with an env-var loader."""
    detection: DetectionConfig = field(default_factory=DetectionConfig)
    masking: MaskingConfig = field(default_factory=MaskingConfig)

    # Feature flags (mirror config.json / env)
    masking_enabled: bool = True
    retention_days: int = 7
    auto_delete_after_remap: bool = True

    @classmethod
    def from_env(cls) -> "GuardrailConfig":
        cfg = cls()
        if os.getenv("PII_SCORE_THRESHOLD"):
            try:
                t = float(os.getenv("PII_SCORE_THRESHOLD"))
                if 0.0 <= t <= 1.0:
                    cfg.detection.score_threshold = t
            except ValueError:
                pass
        if os.getenv("PII_SPACY_MODEL"):
            cfg.detection.spacy_model = os.getenv("PII_SPACY_MODEL")
        if os.getenv("PII_RETENTION_DAYS"):
            try:
                d = int(os.getenv("PII_RETENTION_DAYS"))
                if d >= 0:
                    cfg.retention_days = d
            except ValueError:
                pass
        if os.getenv("PII_MASKING_ENABLED"):
            cfg.masking_enabled = os.getenv("PII_MASKING_ENABLED").lower() == "true"
        return cfg


default_config = GuardrailConfig.from_env()
